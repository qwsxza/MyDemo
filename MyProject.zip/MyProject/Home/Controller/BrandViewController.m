

//
//  BrandViewController.m
//  MyProject
//
//  Created by gp on 15/11/7.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "BrandViewController.h"
#import "BrandCell.h"
#import "BrandCell2.h"
#import "UIColor+AddColor.h"
#import "AFHTTPRequestOperationManager.h"
#import "BrandModel.h"
#import "BrandHomeViewController.h"


@interface BrandViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)NSMutableArray *modelArray;

@end

@implementation BrandViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.titleLabel.text = @"品牌专区";
    self.titleLabel.textColor = [UIColor whiteColor];
    self.titleLabel.font = [UIFont systemFontOfSize:19];
    //tableView
    self.tableView = [[UITableView alloc]initWithFrame:self.backView.frame style:(UITableViewStylePlain)];
    [self.view addSubview:self.tableView];
    self.tableView.backgroundColor = [UIColor huiseColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    //modelarray
    self.modelArray = [NSMutableArray array];

    //加载数据
    [self hundle];
    
    
}
//数据解析
- (void)hundle
{
    [[AFHTTPRequestOperationManager manager]GET:@"http://api.liwushuo.com/v2/brands/editor?limit=20&offset=0" parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSArray *array = responseObject[@"data"][@"brands"];
        for (NSDictionary *dic in array) {
            BrandModel *brand = [[BrandModel alloc]init];
            [brand setValuesForKeysWithDictionary:dic];
            [self.modelArray addObject:brand];
        }
        [self.tableView reloadData];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"品牌推荐%@",error);
    }];

}

//点击事件
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    BrandHomeViewController *brandVC = [[BrandHomeViewController alloc]init];
    BrandModel *brand = self.modelArray[indexPath.row];
    brandVC.brand = brand;
    [self.navigationController pushViewController:brandVC animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat height = [UIScreen mainScreen].bounds.size.width / 60 + 10 + [UIScreen mainScreen].bounds.size.width / 8 + 15 + ([UIScreen mainScreen].bounds.size.width - [UIScreen mainScreen].bounds.size.width / 30 - 23) / 2 + 10;
    return height;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.modelArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row % 2 == 0) {
        static NSString *identifier = @"brand";
        BrandCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell) {
            cell = [[BrandCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:identifier];
        }
        //使背景色透明
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        BrandModel *brand = [[BrandModel alloc]init];
        brand =  self.modelArray[indexPath.row];
        cell.brand = brand;
        
        return cell;
    }
    else{
        BrandCell2 *cell = [tableView dequeueReusableCellWithIdentifier:@"other"];
        if (!cell) {
            cell = [[BrandCell2 alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"other"];
        }
        //**
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;

        BrandModel *brand = [[BrandModel alloc]init];
        brand  = self.modelArray[indexPath.row];
        cell.brand = brand;
        return cell;
    }
}


@end
