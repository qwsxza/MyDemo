//
//  TakeTurnViewController.h
//  MyProject
//
//  Created by gp on 15/11/7.
//  Copyright © 2015年 gp. All rights reserved.
//

//点击轮播图  进入的controller

#import "ViewController.h"

@interface TakeTurnViewController : ViewController

@property (nonatomic,strong) NSString *ID;

@end
