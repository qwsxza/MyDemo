
//
//  TakeTurnViewController.m
//  MyProject
//
//  Created by gp on 15/11/7.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "TakeTurnViewController.h"
#import "PlateView.h"
#import "AFHTTPRequestOperationManager.h"
#import "GiftModel.h"
#import "MJRefresh.h"
#import "GiftDetailViewController.h"

@interface TakeTurnViewController ()

@property (nonatomic,strong)PlateView *plateView;
@property (nonatomic,strong)NSMutableArray *modelArr; //存放解析的数据

@end

@implementation TakeTurnViewController


- (void)viewDidLoad {
    [super viewDidLoad];

    //title 外观
    self.titleLabel.textColor = [UIColor whiteColor];
    self.titleLabel.font = [UIFont systemFontOfSize:18];
    
    
    self.plateView = [[PlateView alloc]initWithFrame:(CGRectMake(0, 0, self.backView.frame.size.width, self.backView.frame.size.height))];
    [self.backView addSubview:self.plateView];
    
    self.modelArr = [NSMutableArray array];

    
    [self hundleByID:self.ID Num:0];
    self.plateView.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self hundleByID:self.ID Num:self.modelArr.count];
    }];
    __weak typeof(self)myself = self;
    [self.plateView setToDetailViewController:^(NSString *Id) {
        GiftDetailViewController *gift = [[GiftDetailViewController alloc]init];
        gift.ID = Id;
        [myself.navigationController pushViewController:gift animated:YES];
    }];
    
}

//轮播图详情加载
- (void)hundleByID:(NSString *)Id Num:(NSInteger)num
{
[[AFHTTPRequestOperationManager manager]GET:[NSString stringWithFormat:@"http://api.liwushuo.com/v2/collections/%@/posts?gender=1&generation=1&limit=20&offset=%ld",Id,(long)num] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
    NSString *title = responseObject[@"data"][@"title"];
    self.titleLabel.text = title;
    NSArray *array = responseObject[@"data"][@"posts"];
    for (NSDictionary *dic in array) {
        GiftModel *gift = [[GiftModel alloc]init];
        [gift setValuesForKeysWithDictionary:dic];
        [self.modelArr addObject:gift];
    }
    if (array.count != 20) {
        self.plateView.tableView.footer = nil;
    }
    self.plateView.array = [NSMutableArray arrayWithArray:self.modelArr];
    [self.plateView.tableView.footer endRefreshing];

} failure:^(AFHTTPRequestOperation *operation, NSError *error) {
    NSLog(@"轮播图详情加载%@",error);
}];

}

@end
