
//
//  GiftViewController.m
//  MyProject
//
//  Created by gp on 15/11/5.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "GiftViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import "TitleModel.h"
#import "JingView.h"
#import "TaketurnModel.h"
#import "GiftModel.h"
#import "PlateView.h"
#import "UIColor+AddColor.h"
#import "TakeTurnViewController.h"
#import "BrandViewController.h"
#import "GiftDetailViewController.h"
#import "MJRefresh.h"
#import "TaobaoController.h"
#import "SearchView.h"
#import "BrandGiftDetailViewController.h"

#define kUIScreenWidth [UIScreen mainScreen].bounds.size.width

@interface GiftViewController ()<UIScrollViewDelegate,SearchViewDelegate>

@property (nonatomic,strong)UIScrollView *scrollButtonV;
@property (nonatomic,strong)NSMutableArray *ButtonArray;  //button数据解析
@property (nonatomic,strong)UIScrollView *mainScrollView;
@property (nonatomic,strong)JingView *jingView;  //精选View
@property (nonatomic,strong)NSMutableArray *taketurnArr;  //轮播图数据解析
@property (nonatomic,strong)NSMutableArray *jingArr;  //精选内容数据解析
@property (nonatomic,strong)NSMutableDictionary *modelDic;  //存放数组的字典(数组中包含每个模块解析数据,便于区分数组)
@property (nonatomic,assign)BOOL isDidLoad;
@property (nonatomic,strong)UILabel *moveLabel;  //***
@property (nonatomic,strong)UIImageView *searchIamgeV;  //搜索
@property (nonatomic,strong)SearchView *searchView;  //搜索界面
@property (nonatomic,assign)BOOL isSearch; //***
@property (nonatomic,assign)BOOL isTakeTurn;  //轮播图加载

@end

@implementation GiftViewController

//searchViewDelegate  执行代理里面的方法
- (void)ChangePlateWithNum:(NSInteger)num
{
    [self.mainScrollView setContentOffset:(CGPointMake(self.mainScrollView.frame.size.width * num, 0)) animated:NO];
    [UIView animateWithDuration:0.4 animations:^{
        CGRect newframe = self.searchView.frame;
        newframe.origin.y = - self.backView.frame.size.height;
        self.searchView.frame = newframe;
        self.searchIamgeV.transform = CGAffineTransformMakeRotation(0);
    } completion:^(BOOL finished) {
        self.isSearch = NO;
        [self.searchView removeFromSuperview];
        [self.view bringSubviewToFront:self.backView];
    }];
}

//搜索按钮
- (void)SearchClick:(UITapGestureRecognizer *)tap
{
    [self.backView addSubview:self.searchView];
    [self.view bringSubviewToFront:self.topView];
    
    if (self.isSearch == NO) {
        [UIView animateWithDuration:0.4 animations:^{
            CGRect newframe =  self.searchView.frame;
            newframe.origin.y =  0;
            self.searchView.frame = newframe;
            self.searchIamgeV.transform = CGAffineTransformMakeRotation(M_PI);
        } completion:^(BOOL finished) {
            self.isSearch = YES;
            [self.view bringSubviewToFront:self.backView]; //不提前会出现buttonScroll里面的标题偏移

        }];
    }else
    {
        //二次点击**
        [UIView animateWithDuration:0.4 animations:^{
            CGRect newframe = self.searchView.frame;
            newframe.origin.y= - self.backView.frame.size.height;
            self.searchView.frame = newframe;
            self.searchIamgeV.transform = CGAffineTransformMakeRotation(0);
        } completion:^(BOOL finished) {
            [self.searchView removeFromSuperview];
            [self.view bringSubviewToFront:self.backView]; // ***
            self.isSearch = NO;
        }];
    }
    
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    //标题
    self.titleLabel.text = @"懒得🐶";
    self.titleLabel.textColor = [UIColor whiteColor];
    self.titleLabel.font = [UIFont systemFontOfSize:20 weight:0];
    
    //搜索图标
    self.searchIamgeV = [[UIImageView alloc]initWithFrame:(CGRectMake(kUIScreenWidth - kUIScreenWidth/15 - 20, self.topView.frame.size.height / 2, kUIScreenWidth / 15, kUIScreenWidth / 15))];
    [self.topView addSubview:self.searchIamgeV];
    self.searchIamgeV.image = [UIImage imageNamed:@"搜索"];
    self.searchIamgeV.userInteractionEnabled = YES;
    UITapGestureRecognizer *imageTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(SearchClick:)];
    [self.searchIamgeV addGestureRecognizer:imageTap];
    //搜索界面
    self.searchView = [[SearchView alloc]initWithFrame:(CGRectMake(0, -self.backView.frame.size.height, kUIScreenWidth, self.backView.frame.size.height))];
    self.searchView.backgroundColor = [UIColor whiteColor];
    self.searchView.delegate = self;
    //点击searchVIew里面的礼物items跳转到详情
    __weak typeof(self)oneSelf = self;
    [self.searchView setToCollectDetailVC:^(NSString *ID) {
        BrandGiftDetailViewController *brand = [[BrandGiftDetailViewController alloc]init];
        brand.ID = ID;
        [oneSelf.navigationController pushViewController:brand animated:YES];
    }];
    __weak typeof(self)me = self;
    [self.searchView setToTableDetailVC:^(NSString *Id) {
        GiftDetailViewController *gift = [[GiftDetailViewController alloc]init];
        gift.ID = Id;
        [me.navigationController pushViewController:gift animated:YES];
    }];

    
    //接收通知 美好小物 好店推荐
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(toHappySmall:) name:@"toHappySmallVC" object:nil];
    [[NSNotificationCenter defaultCenter]addObserverForName:@"toBrandVC" object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification * _Nonnull note) {
        BrandViewController *brandVC = [[BrandViewController alloc]init];
        [self.navigationController pushViewController:brandVC animated:YES];
    }];
    [[NSNotificationCenter defaultCenter]addObserverForName:@"toTaobaoVC" object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification * _Nonnull note) {
        TaobaoController *taobaoVC = [[TaobaoController alloc]init];
        [self.navigationController pushViewController:taobaoVC animated:YES];
    }];
    


    //创建buttonScrollView
    self.scrollButtonV = [[UIScrollView alloc]initWithFrame:(CGRectMake(10, 0, self.view.bounds.size.width - 30, kUIScreenWidth / 10))];
    self.scrollButtonV.showsHorizontalScrollIndicator = NO;
//    self.scrollButtonV.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    [self.backView addSubview:self.scrollButtonV];
    self.scrollButtonV.backgroundColor = [UIColor whiteColor];
    
    //buttonScroll下面的细线
    UILabel *label = [[UILabel alloc]initWithFrame:(CGRectMake(0, self.scrollButtonV.frame.size.height - 0.5, kUIScreenWidth, 0.5))];
    label.backgroundColor = [UIColor grayColor];
    [self.backView addSubview:label];
    
    //创建主界面的UIScrollView
    self.mainScrollView = [[UIScrollView alloc]initWithFrame:(CGRectMake(0, kUIScreenWidth / 10, self.view.bounds.size.width, self.backView.frame.size.height - kUIScreenWidth / 10))];
    [self.backView addSubview:self.mainScrollView];
    self.mainScrollView.backgroundColor = [UIColor tiankonglan];
//    self.mainScrollView.contentSize = CGSizeMake(7 * self.mainScrollView.frame.size.width, 0);
    self.mainScrollView.pagingEnabled = YES;
    //*******
    self.mainScrollView.delegate = self;
    
    //创建mainScrollView里面的第一个界面 精品View
    CGFloat width = self.mainScrollView.frame.size.width;
    CGFloat height = self.mainScrollView.frame.size.height;
    
    self.jingView = [[JingView alloc]initWithFrame:(CGRectMake(0, 0, width, height))];
    [self.mainScrollView addSubview:self.jingView];
    self.jingArr = [NSMutableArray array];
    
//    弱引用***   轮播图点击通过block完成跳转
    __weak typeof(self)myself = self;
    [self.jingView setToViewController:^(NSString *ID) {
        TakeTurnViewController *taketurnVC = [[TakeTurnViewController alloc]init];
        TaobaoController *taobao = [[TaobaoController alloc]init];
        if (ID) {
        taketurnVC.ID = ID;
        [myself.navigationController pushViewController:taketurnVC animated:YES];
        }else
        {
            [myself.navigationController pushViewController:taobao animated:YES];
        }
    }];
    
    // 单元格点击 block跳转 进入详情页面
    __weak typeof(self)Self = self;
    [self.jingView setToDetailViewController:^(NSString *ID) {
        GiftDetailViewController *giftDetailVC = [[GiftDetailViewController alloc]init];
        giftDetailVC.ID = ID;
        [Self.navigationController pushViewController:giftDetailVC animated:YES];
    }];
    
    //精选内容接续
    [self hundleWithID:@"100" Num:0 View:(PlateView *)self.jingView Array:self.jingArr];
    
    //精选内容上拉刷新 下拉加载
    self.jingView.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self refreshWithID:@"100" Num:0 View:(PlateView *)self.jingView Array:self.jingArr];
        [self hundle];
        [self hundle1];
        [self.jingView.tableView.header endRefreshing]; //[self hundle]内无ending
    }];
    self.jingView.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self hundleWithID:@"100" Num:self.jingArr.count View:(PlateView *)self.jingView Array:self.jingArr];
    }];
    
    //字典初始化
    self.modelDic = [NSMutableDictionary dictionary];
    
    //button文字  id 解析
    [self hundle];
    //轮播图信息解析
    [self hundle1];
    
    //?????
//    [self.view bringSubviewToFront:self.topView];

}


//上拉刷新下拉加载
- (void)headerRefreshingfooterLoadingWithTableView:(UITableView *)tableView PlateView:(PlateView *)plateView Array:(NSMutableArray *)array ID:(NSString *)Id
{
    //上拉刷新
    tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self refreshWithID:Id Num:0 View:plateView Array:array];
    }];
    //下拉加载  (根据数组数量加载)
//    __block int num = 20;
    tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self hundleWithID:Id Num:array.count View:plateView Array:array];
//        num += 20;
    }];
}

//执行通知里面的方法
- (void)toHappySmall:(NSNotification *)note
{
    TakeTurnViewController *happysmallVC = [[TakeTurnViewController alloc]init];
    happysmallVC.ID = @"22";
    [self.navigationController pushViewController:happysmallVC animated:YES];
//    [[NSNotificationCenter defaultCenter]removeObserver:self];  如果移除 就只执行一次
}
//***
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat width = scrollView.frame.size.width;
    CGPoint offset = scrollView.contentOffset;
    NSInteger i = offset.x / width;
    
    for (UIView *view in self.scrollButtonV.subviews) {
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)view;
            [button setTitleColor:[UIColor blackColor] forState:(UIControlStateNormal)];
        }
    }
    UIButton *currentButton = (UIButton *)[self.scrollButtonV viewWithTag:1000 + i];
    [currentButton setTitleColor:[UIColor jinjuse] forState:(UIControlStateNormal)];

    //movelabel动画
    [UIView animateWithDuration:0.2 animations:^{
        CGRect newframe =  self.moveLabel.frame;
        newframe.origin.x = currentButton.frame.origin.x + currentButton.frame.size.width / 4;
        self.moveLabel.frame = newframe;
    }];

    CGFloat scrollButtonWidth = self.scrollButtonV.frame.size.width;
    if (i > 3) {
        [self.scrollButtonV setContentOffset:(CGPointMake(0.4 * scrollButtonWidth, 0)) animated:YES];
    }
    if (i > 4) {
        [self.scrollButtonV setContentOffset:(CGPointMake((self.ButtonArray.count/ 4.5 - 1)*scrollButtonWidth, 0)) animated:YES];
    }
    if (i < 3) {
        [self.scrollButtonV setContentOffset:CGPointZero animated:YES];
    }
    //****
    TitleModel *title = [[TitleModel alloc]init];
    title = self.ButtonArray[i];
    PlateView *plateView = (PlateView *)[self.mainScrollView viewWithTag:4000 + i];
 
    //取出model字典里面的array
    NSMutableArray *arr = [self.modelDic objectForKey:[NSString stringWithFormat:@"%ld",(long)i]];
    if (arr.count == 0) {
    [self hundleWithID:title.Id Num:0 View:plateView Array:arr];
    }
    [self headerRefreshingfooterLoadingWithTableView:plateView.tableView PlateView:plateView Array:arr ID:title.Id];
    
    
}

//模块刷新
- (void)refreshWithID:(NSString *)Id Num:(NSInteger)num View:(PlateView *)view Array:(NSMutableArray *)array
{
    array = [NSMutableArray array];
    [[AFHTTPRequestOperationManager manager]GET:[NSString stringWithFormat:@"http://api.liwushuo.com/v2/channels/%@/items?ad=1&gender=1&generation=1&limit=20&offset=%ld",Id,(long)num] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSArray *rootArr = responseObject[@"data"][@"items"];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
            for (NSDictionary *dic in rootArr) {
                GiftModel *gift = [[GiftModel alloc]init];
                [gift setValuesForKeysWithDictionary:dic];
                [array addObject:gift];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                
                view.array = [NSMutableArray arrayWithArray:array];
                [view.tableView.header endRefreshing];
            });
        });
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"模块刷新%@",error);
    }];
}

//模块加载
- (void)hundleWithID:(NSString *)Id Num:(NSInteger)num View:(PlateView *)view Array:(NSMutableArray *)array
{
[[AFHTTPRequestOperationManager manager]GET:[NSString stringWithFormat:@"http://api.liwushuo.com/v2/channels/%@/items?ad=1&gender=1&generation=1&limit=20&offset=%ld",Id,(long)num] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
    NSArray *rootArr = responseObject[@"data"][@"items"];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        for (NSDictionary *dic in rootArr) {
            GiftModel *gift = [[GiftModel alloc]init];
            [gift setValuesForKeysWithDictionary:dic];
            [array addObject:gift];
        }
        //关闭下拉加载
        if (rootArr.count != 20) {
            view.tableView.footer = nil;
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            view.array = [NSMutableArray arrayWithArray:array];
            [view.tableView.footer endRefreshing];
        });
    });
    
} failure:^(AFHTTPRequestOperation *operation, NSError *error) {
    NSLog(@"模块加载%@",error);
}];

}
//模块创建
- (void)set_upPlateView
{
    CGFloat width = self.mainScrollView.frame.size.width;
    for (int i = 1; i < self.ButtonArray.count; i++) {
        PlateView *plateView = [[PlateView alloc]initWithFrame:(CGRectMake(width * i, 0, width, self.mainScrollView.frame.size.height))];
        plateView.tag = 4000 + i;
        //block 跳到详情**
        [plateView setToDetailViewController:^(NSString *ID) {
            GiftDetailViewController *gift = [[GiftDetailViewController alloc]init];
            gift.ID = ID;
            [self.navigationController pushViewController:gift animated:YES];
        }];
        
        [self.mainScrollView addSubview:plateView];
        NSMutableArray *array = [NSMutableArray array];
        NSString *I = [NSString stringWithFormat:@"%d",i];
        //modelDic字典
        [self.modelDic setObject:array forKey:I];
    }
}

//button创建
- (void)set_upButton
{
        CGFloat width = self.scrollButtonV.frame.size.width;
        CGFloat buttonWidth = self.scrollButtonV.frame.size.width / 4.5;
        for (int i = 0; i < self.ButtonArray.count; i++) {
            UIButton *button = [UIButton buttonWithType:(UIButtonTypeSystem)];
            button.frame = CGRectMake(i * buttonWidth, 0, width / 4.5, self.scrollButtonV.frame.size.height);
            [button setTitleColor:[UIColor blackColor] forState:(UIControlStateNormal)];
            button.titleLabel.font = [UIFont systemFontOfSize:15];
            button.tag = 1000 + i;   //*****
            TitleModel *title = [[TitleModel alloc]init];
            title = self.ButtonArray[i];
            [button setTitle:title.name forState:(UIControlStateNormal)];
            //字体粗细改变 value从-1.0 ~ 1.0
            button.titleLabel.font = [UIFont systemFontOfSize:15 weight:-1.0];
            [self.scrollButtonV addSubview:button];
            //模块Button点击
            [button addTarget:self action:@selector(switchView:) forControlEvents:(UIControlEventTouchUpInside)];
        }
    //精选button默认选中
    UIButton *button = (UIButton *)[self.scrollButtonV viewWithTag:1000];
    [button setTitleColor:[UIColor jinjuse] forState:(UIControlStateNormal)];
    //***创建移动label
    self.moveLabel = [[UILabel alloc]initWithFrame:(CGRectMake(button.frame.size.width / 4, button.frame.size.height - 2, button.frame.size.width / 2, 2))];
    self.moveLabel.backgroundColor = [UIColor jinjuse];
    [self.scrollButtonV addSubview:self.moveLabel];
}

//波纹 动画
- (void)SetCubeAnimation
{
    CATransition *transition = [CATransition animation];
    transition.type = @"RippleEffect";
    transition.subtype = kCATransitionFromRight;
    transition.duration = 0.8;
    [self.mainScrollView.layer addAnimation:transition forKey:@"波纹效果"];
}

//点击button切换模块
- (void)switchView:(UIButton *)button
{
    CGFloat width =  self.mainScrollView.frame.size.width;
    [self.mainScrollView setContentOffset:(CGPointMake((button.tag - 1000) * width, 0)) animated:NO];
    [self SetCubeAnimation];
}

//轮播图信息解析
- (void)hundle1
{
    self.taketurnArr = [NSMutableArray array];
    [[AFHTTPRequestOperationManager manager]GET:@"http://api.liwushuo.com/v2/banners?channel=androd" parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSArray *array = responseObject[@"data"][@"banners"];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
            for (NSDictionary *dic in array) {
                TaketurnModel *take = [[TaketurnModel alloc]init];
                [take setValuesForKeysWithDictionary:dic];
                [self.taketurnArr addObject:take];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                self.jingView.taketurnArr = [NSMutableArray arrayWithArray:self.taketurnArr];
                NSLog(@"%ld", (unsigned long)self.taketurnArr.count);
            });
        });
    
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"轮播图解析%@",error);
    }];
    
}

//button文字 id  数目 解析
- (void)hundle
{
    self.ButtonArray = [NSMutableArray array];
[[AFHTTPRequestOperationManager manager] GET:@"http://api.liwushuo.com/v2/channels/preset?gender=1&generation=1" parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
    NSArray *array = responseObject[@"data"][@"channels"];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        for (NSDictionary *dic in array) {
            TitleModel *title = [[TitleModel alloc]init];
            [title setValuesForKeysWithDictionary:dic];
            [self.ButtonArray addObject:title];
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            self.searchView.array = self.ButtonArray;
            self.scrollButtonV.contentSize = CGSizeMake(self.ButtonArray.count / 4.5 * self.scrollButtonV.frame.size.width, 0);
            self.mainScrollView.contentSize = CGSizeMake(self.ButtonArray.count * self.mainScrollView.frame.size.width, 0);
            //设置BOOL值 只加载一次
            if (self.isDidLoad == NO) {
                //创建UiscrollView上面的button  mainScrollView上的plateView
                [self set_upPlateView];
                [self set_upButton];
                self.isDidLoad = YES;
            }
        });
    });
    
} failure:^(AFHTTPRequestOperation *operation, NSError *error) {
    NSLog(@"button文字解析%@",error);
}];
    

}


@end
