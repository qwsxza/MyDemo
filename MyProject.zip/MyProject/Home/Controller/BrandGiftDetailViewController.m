



//
//  BrandGiftDetailViewController.m
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "BrandGiftDetailViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import "BGDetailModel.h"
#import "UIImageView+WebCache.h"
#import "LiuLanCell.h"  // 浏览图cell
#import "BGDetailCell2.h" //信息价格 介绍
#import "BGDetailCell3.h"  //图文介绍内容
#import "ButtonView2.h"
#import "UIColor+AddColor.h"
#import "DiscussCell.h"
#import "DiscussModel.h"
#import "UserModel.h"
#import "MJRefresh.h"

#define kUIScreenWidth [UIScreen mainScreen].bounds.size.width
#define kUIScreenHeight [UIScreen mainScreen].bounds.size.height
@interface BrandGiftDetailViewController ()<UITableViewDataSource,UITableViewDelegate,UIWebViewDelegate>

@property (nonatomic,strong)BGDetailModel *gift;
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)ButtonView2 *buttonView2;
@property (nonatomic,strong)UIButton *button;
@property (nonatomic,assign)BOOL isLoadCell;  //加载评论cell 还是 图文介绍cell
@property (nonatomic,strong)NSMutableArray *discussArray;  //评论数组
@property (nonatomic,assign)CGFloat webHeight;


@end

@implementation BrandGiftDetailViewController

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    NSString *height = [webView stringByEvaluatingJavaScriptFromString:@"document.body.offsetHeight;"];
        CGFloat webViewHeight = [height floatValue] + 15;
        self.webHeight = webViewHeight;

    [self.tableView reloadData];
}


- (void)viewDidLoad {
    [super viewDidLoad];

    //标题
    self.titleLabel.text = @"礼物详情";
    self.titleLabel.textColor = [UIColor whiteColor];
    self.titleLabel.font = [UIFont systemFontOfSize:18 weight:-1.0];
    
    //tableView
    self.tableView = [[UITableView alloc]initWithFrame:self.backView.frame style:(UITableViewStylePlain)];
    [self.view addSubview:self.tableView];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = [UIColor whiteColor];
    
    //图文介绍,评论 buttonView
    self.buttonView2 = [[ButtonView2 alloc]initWithFrame:(CGRectMake(0, 0, kUIScreenWidth, kUIScreenWidth * 40 / 375))];
    self.buttonView2.backgroundColor = [UIColor whiteColor];
    
    
    //点击button触发BOOL isLoadCell的变化
    __weak typeof(self)myself = self;
    [self.buttonView2 setDecisionCell:^(NSInteger tag) {
        myself.isLoadCell = tag - 5000;
        //评论数据
        if (myself.isLoadCell == YES) {
            //创建数组 储存评论
            myself.discussArray = [NSMutableArray array];
            //解析初始评论
            [myself hundleByNum:myself.discussArray.count];
        }else {
            //**
        [myself.tableView reloadData];
        }
    }];
    
    //解析品牌内部礼物详情
    [self hundle];
    
}
//一共两个区  第一个个区 两个cell
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 1) {
        return kUIScreenWidth * 40 / 375;
    }
       return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 1) {
        return self.buttonView2;
    }
       return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0 && indexPath.row == 0) {
        return kUIScreenHeight / 1.7;
    }
    if (indexPath.section == 0 && indexPath.row == 1) {
        CGFloat height = [self getHeightWithString:self.gift.Description Width:kUIScreenWidth - 20 Font:13];
        return height + 25 + kUIScreenWidth * 40 / 375 + 10;
    }else{
    if (self.isLoadCell == YES) {
            CGFloat sumheight = 0;
          for (int i = 0; i < self.discussArray.count; i++) {
            DiscussModel *discuss =  self.discussArray[i];
            //评论cell中content高度
            CGFloat height = [self getHeightWithString:discuss.content Width:kUIScreenWidth - kUIScreenWidth / 10 - 25 Font:14];
            sumheight += height;
        }
            //设置评论内容最小高度
        if ((kUIScreenWidth * 20 / 375 + 30 ) * self.discussArray.count + sumheight < self.backView.frame.size.height - kUIScreenWidth * 40 / 375) {
          return self.backView.frame.size.height - kUIScreenWidth * 40 / 375;
       }
          return (kUIScreenWidth * 20 / 375 + 30 ) * self.discussArray.count + sumheight;

    }else{
        //webView加载完毕 会卡顿  只能设置死值
            return self.webHeight;
        }
    }
    
}
//***
- (CGFloat)getHeightWithString:(NSString *)str Width:(CGFloat)width Font:(NSInteger)font
{
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:NSFontAttributeName,[UIFont systemFontOfSize:font], nil];
//    NSDictionary *dic = @{NSFontAttributeName:[UIFont systemFontOfSize:font]};
    CGRect rect = [str boundingRectWithSize:CGSizeMake(width, 1000) options:(NSStringDrawingUsesLineFragmentOrigin) attributes:dic context:nil];
    return rect.size.height;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 2;
    }
        return 1;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
        return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
//**
    if (indexPath.section == 0 && indexPath.row == 0) {
    LiuLanCell *cell = [tableView dequeueReusableCellWithIdentifier:@"liulan"];
    if (!cell) {
        cell = [[LiuLanCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"liulan"];
    }
        cell.gift = self.gift;
    return cell;
}
//***
    else if (indexPath.section == 0 && indexPath.row == 1){
    BGDetailCell2 *cell = [tableView dequeueReusableCellWithIdentifier:@"bgdetail"];
    if (!cell) {
         cell = [[BGDetailCell2 alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"bgdetail"];
    }
        cell.gift = self.gift;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
//****
    else{
        if (self.isLoadCell == NO) {
        BGDetailCell3 *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        if (!cell) {
            cell = [[BGDetailCell3 alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"cell"];
        }
            cell.backgroundColor = [UIColor whiteColor];
            cell.web.delegate = self;
            cell.gift = self.gift;
        return cell;
        }
        else{
            DiscussCell *cell = [tableView dequeueReusableCellWithIdentifier:@"other"];
            if (!cell) {
                cell = [[DiscussCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"other"];
            }
            cell.array = self.discussArray;
        return cell;
        }
    }
}

//解析评论
- (void)hundleByNum:(NSInteger)num
{
    [[AFHTTPRequestOperationManager manager]GET:[NSString stringWithFormat:@"http://api.liwushuo.com/v2/items/%@/comments?limit=20&offset=%ld",self.ID,num] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSArray *rootArr = responseObject[@"data"][@"comments"];
        for (NSDictionary *dic in rootArr) {
            DiscussModel *discuss = [[DiscussModel alloc]init];
            [discuss setValuesForKeysWithDictionary:dic];
            [self.discussArray addObject:discuss];
        }
        //评论数据下拉加载
            if (rootArr.count == 20) {
                self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
                    [self hundleByNum:self.discussArray.count];
                }];
            }else
            {
                self.tableView.footer = nil;
            }
        
        [self.tableView.footer endRefreshing];
        [self.tableView reloadData];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"评论解析失败%@",error);
    }];
    
}


//解析
- (void)hundle
{
[[AFHTTPRequestOperationManager manager]GET:[NSString stringWithFormat:@"http://api.liwushuo.com/v2/items/%@",self.ID]parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
    NSDictionary *dic = responseObject[@"data"];
    self.gift = [[BGDetailModel alloc]init];
    [self.gift setValuesForKeysWithDictionary:dic];
    //
    self.buttonView2.number = [NSString stringWithFormat:@"%@",self.gift.comments_count];
    [self.tableView reloadData];
} failure:^(AFHTTPRequestOperation *operation, NSError *error) {
    NSLog(@"品牌内部礼物详情%@",error);
}];

}

@end
