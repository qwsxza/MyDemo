

//
//  TaobaoController.m
//  MyProject
//
//  Created by gp on 15/11/11.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "TaobaoController.h"

@interface TaobaoController ()<UIWebViewDelegate>

@property (nonatomic,strong)UIWebView *web;

@end

@implementation TaobaoController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.titleLabel.text = @"淘宝首页";
    self.titleLabel.textColor = [UIColor whiteColor];
    self.titleLabel.font = [UIFont systemFontOfSize:18 weight:0];
    //
    UIAlertView *view = [[UIAlertView alloc]initWithTitle:@"欢迎进入淘宝首页" message:@"暂无法购物,敬请谅解,加载需等待..." delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [view show];
    //web
    self.web = [[UIWebView alloc]initWithFrame:(CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.frame.size.height))];
    [self.backView addSubview:self.web];
    NSString *str = @"http://s.click.taobao.com/t?e=m%3D2%26s%3D%2Fuh%2FFV6YiSYcQipKwQzePOeEDrYVVa64yK8Cckff7TVRAdhuF14FMQc2XZifCXRTt4hWD5k2kjOtgmtnxDX9deVMA5qBABUs5mPg1WiM1P5OS0OzHKBZzW1e2y4p13L5DtfSvsP0QR9y2g1RwuM4flVfhbFvZeICvRn9s5lIr3k%3D";
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc]initWithURL:[NSURL URLWithString:[str stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] cachePolicy:(NSURLRequestUseProtocolCachePolicy) timeoutInterval:20];
    [self.web loadRequest:request];
    
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error
{
    NSLog(@"淘宝解析%@",error);

}

@end
