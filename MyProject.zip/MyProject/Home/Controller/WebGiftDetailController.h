//
//  WebGiftDetailController.h
//  MyProject
//
//  Created by gp on 15/11/11.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "ViewController.h"

@interface WebGiftDetailController : ViewController

@property (nonatomic,strong) NSString *html;


@end
