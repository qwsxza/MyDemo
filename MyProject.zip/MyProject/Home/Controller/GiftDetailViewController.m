

//
//  GiftDetailViewController.m
//  MyProject
//
//  Created by gp on 15/11/7.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "GiftDetailViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import "GiftDetailModel.h"
#import "UIImageView+WebCache.h"
#import "GiftDetailCell.h"
#import "WebGiftDetailController.h"

@interface GiftDetailViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong)UIImageView *imageV;
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)UILabel *label;

@end

@implementation GiftDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.titleLabel.text = @"攻略详情";
    self.titleLabel.textColor = [UIColor whiteColor];
    
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame style:(UITableViewStyleGrouped)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.contentInset = UIEdgeInsetsMake(250, 0, 0, 0);
    [self.view addSubview:self.tableView];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
//    self.tableView.backgroundColor = [UIColor grayColor];
    
    self.imageV = [[UIImageView alloc]initWithFrame:(CGRectMake(0, 0, self.view.bounds.size.width, 250))];
    [self.backView addSubview:self.imageV];
    //保持内容的比例不会失真
    self.imageV.contentMode = UIViewContentModeScaleAspectFill;
    [[self.topView superview] bringSubviewToFront:self.topView];
    
    self.label = [[UILabel alloc]init];
    self.label.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.1];
    [self.backView addSubview:self.label];
    self.label.textColor = [UIColor whiteColor];
    self.label.textAlignment = NSTextAlignmentCenter;
    self.label.font = [UIFont systemFontOfSize:18];

    
    //加载数据
    [self hundle];
}

//图片大小问题

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
//    _imageV.backgroundColor = [UIColor clearColor];
    _imageV.hidden = YES;

}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    _imageV.hidden = NO;
}
//加载数据
- (void)hundle
{
    [[AFHTTPRequestOperationManager manager]GET:[NSString stringWithFormat:@"http://api.liwushuo.com/v2/posts/%@",self.ID] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary *dic = responseObject[@"data"];
        GiftDetailModel *gift = [[GiftDetailModel alloc]init];
        [gift setValuesForKeysWithDictionary:dic];
        self.gift = gift;
        [self.imageV sd_setImageWithURL:[NSURL URLWithString:gift.cover_image_url]];
        if (gift.title.length > 19) {
            self.label.font = [UIFont systemFontOfSize:15];
        }
        self.label.text = gift.title;
        
        [self.tableView reloadData];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"页面详情解析%@",error);
    }];
    
}

//视图正在移动
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    
    CGFloat y = scrollView.contentOffset.y;
//    NSLog(@"%f",-(y+250));
    if (-y/250 >=1) {
//        self.imageV.transform = CGAffineTransformMakeScale(-y/250, -y/250);
        CGRect frame = self.imageV.frame;
        frame.size.height = -y;
        self.imageV.frame = frame;

    }
    if (-(y+250)<0) {
        CGRect newframe = self.imageV.frame;
        newframe.origin.y = - (y + 250) - 5;
        self.imageV.frame = newframe;
    }
    
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return self.label;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dic = @{NSFontAttributeName:[UIFont systemFontOfSize:16]};
   CGRect rect = [self.gift.share_msg boundingRectWithSize:(CGSizeMake(self.tableView.bounds.size.width - 20, 1000)) options:(NSStringDrawingUsesLineFragmentOrigin) attributes:dic context:nil];
    return rect.size.height + 50;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"cell";
    GiftDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[GiftDetailCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:identifier];
    }
//    cell.backgroundColor = [UIColor greenColor];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.giftDetail = self.gift;
    //blck
    [cell setEnterDetail:^(NSString *html) {
        WebGiftDetailController *web = [[WebGiftDetailController alloc]init];
        web.html = html;
        [self.navigationController pushViewController:web animated:YES];
    }];
    return cell;
}


@end
