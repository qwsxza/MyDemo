//
//  GiftDetailViewController.h
//  MyProject
//
//  Created by gp on 15/11/7.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "ViewController.h"
@class GiftDetailModel;
@interface GiftDetailViewController : ViewController

@property (nonatomic,strong) NSString *ID;
@property (nonatomic,strong) GiftDetailModel *gift;


@end
