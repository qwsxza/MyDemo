





//
//  WebGiftDetailController.m
//  MyProject
//
//  Created by gp on 15/11/11.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "WebGiftDetailController.h"

@interface WebGiftDetailController ()

@property (nonatomic,strong)UIWebView *web;

@end

@implementation WebGiftDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.web = [[UIWebView alloc]initWithFrame:(CGRectMake(0, 0, self.backView.frame.size.width, self.backView.frame.size.height))];
    [self.backView addSubview:self.web];
    //设置webView的背景色  要先关闭opaque这个值
//    self.web.opaque = NO;
//    self.web.backgroundColor = [UIColor blackColor];
    
    NSString *str = self.html;
    [self.web scalesPageToFit];
    [self.web loadHTMLString:str baseURL:nil];
    
}



@end
