

//
//  BrandHomeViewController.m
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "BrandHomeViewController.h"
#import "ImageViewCell.h"
#import "AFHTTPRequestOperationManager.h"
#import "BrandModel.h"
#import "AllGiftModel.h"
#import "AllGiftCell.h"
#import "UIColor+AddColor.h"
#import "BrandGiftDetailViewController.h"
#import "BrandIntroCell.h"
#define kUIScreenWidth [UIScreen mainScreen].bounds.size.width
#define kUIScreenHeight [UIScreen mainScreen].bounds.size.height

@interface BrandHomeViewController ()<UITableViewDataSource,UITableViewDelegate,UIWebViewDelegate>

@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)NSMutableArray *modelArray;
@property (nonatomic,strong)UISegmentedControl *seg;
@property (nonatomic,strong)BrandModel *brand2;
@property (nonatomic,assign)BOOL isLoadCell;
@property (nonatomic,assign)CGFloat webHeight;


@end

@implementation BrandHomeViewController

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    NSString *height = [webView stringByEvaluatingJavaScriptFromString:@"document.body.offsetHeight;"];
    CGFloat webViewHeight = [height floatValue] + 15;
    self.webHeight = webViewHeight;
    [self.tableView reloadData];
    

}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.titleLabel.text = @"品牌主页";
    self.titleLabel.textColor = [UIColor whiteColor];
    self.titleLabel.font = [UIFont systemFontOfSize:19];
    
    self.tableView = [[UITableView alloc]initWithFrame:self.backView.frame style:(UITableViewStylePlain)];
    [self.view addSubview:self.tableView];
//    self.tableView.backgroundColor = [UIColor yellowColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    //modelarray
    self.modelArray = [NSMutableArray array];
    
    //UISegmentControl
    self.seg = [[UISegmentedControl alloc]initWithItems:@[@"全部礼物",@"品牌介绍"]];
    self.seg.tintColor = [UIColor blackColor];
    self.seg.selectedSegmentIndex = 0;
    [self.seg addTarget:self action:@selector(changeValue:) forControlEvents:(UIControlEventValueChanged)];
//    self.seg.momentary = YES;  //点击后恢复原样
    
    //加载全部礼物
    [self hundle];
    
}
//改变seg
- (void)changeValue:(UISegmentedControl *)sege
{
    self.isLoadCell = sege.selectedSegmentIndex;
    if (self.isLoadCell == YES) {
        //加载品牌介绍
        [self hundle1];  //内部有[self.tableView reloadData]
    }else{
        [self.tableView reloadData];
    }
}

//加载品牌介绍
- (void)hundle1
{
[[AFHTTPRequestOperationManager manager]GET:[NSString stringWithFormat:@"http://api.liwushuo.com/v2/brands/%@",self.brand.Id] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
    NSDictionary * dic = responseObject[@"data"];
    self.brand2 = [[BrandModel alloc]init];
    [self.brand2 setValuesForKeysWithDictionary:dic];
    [self.tableView reloadData];
} failure:^(AFHTTPRequestOperation *operation, NSError *error) {
    NSLog(@"加载品牌介绍%@",error);
}];

}

//加载全部礼物数据
- (void)hundle
{
[[AFHTTPRequestOperationManager manager]GET:[NSString stringWithFormat:@"http://api.liwushuo.com/v2/brands/%@/items?limit=20&offset=0",self.brand.Id] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
    NSArray *array = responseObject[@"data"][@"items"];
    for (NSDictionary *dic in array) {
        AllGiftModel *gift = [[AllGiftModel alloc]init];
        [gift setValuesForKeysWithDictionary:dic];
        [self.modelArray addObject:gift];
    }
    [self.tableView reloadData];
} failure:^(AFHTTPRequestOperation *operation, NSError *error) {
    NSLog(@"品牌首页加载%@",error);
}];

}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
   return 2;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 1) {
        return 30 * kUIScreenWidth / 375;
    }else
        return 0;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 1) {
        return self.seg;
    }else
        return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return kUIScreenHeight / 3.8;
    }else
    {
        if (self.isLoadCell == NO) {
            //判断数组奇偶性
            if (self.modelArray.count % 2 == 0) {
                return (kUIScreenWidth * 16 / 25 + 2)*self.modelArray.count / 2;
            }else
            {
                return (kUIScreenWidth * 16 / 25 + 2)*(self.modelArray.count + 1)/ 2;
            }

        }else
        {
            //加载webView
            return self.webHeight;
        }
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
    ImageViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"imageV"];
    if (!cell) {
        cell = [[ImageViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"imageV"];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone ;
    cell.brand = self.brand;
    return cell;
    }else
    {
        if (self.isLoadCell == NO) {
            AllGiftCell *cell = [tableView dequeueReusableCellWithIdentifier:@"allgift"];
            if (!cell) {
                cell = [[AllGiftCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"allgift"];
            }
            cell.backgroundColor = [UIColor huiseColor];
            cell.array = self.modelArray;
            [cell setToDetailViewController:^(NSString *ID) {
                BrandGiftDetailViewController *brandDVC = [[BrandGiftDetailViewController alloc]init];
                brandDVC.ID = ID;
                [self.navigationController pushViewController:brandDVC animated:YES];
            }];
            return cell;
        }else
        {
            BrandIntroCell *cell = [tableView dequeueReusableCellWithIdentifier:@"introcell"];
            if (!cell) {
                cell = [[BrandIntroCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"introcell"];
            }
            cell.web.delegate = self;
            cell.brand = self.brand2;
            return cell;
        }
    }
}


@end
