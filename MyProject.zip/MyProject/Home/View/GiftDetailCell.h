//
//  GiftDetailCell.h
//  MyProject
//
//  Created by gp on 15/11/10.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <UIKit/UIKit.h>
@class GiftDetailModel;
@interface GiftDetailCell : UITableViewCell

@property (nonatomic,strong) GiftDetailModel *giftDetail;
@property (nonatomic,strong) void(^enterDetail)(NSString *html);



@end
