

//
//  JingView.m
//  MyProject
//
//  Created by gp on 15/11/5.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "JingView.h"
#import "TaketurnCell.h"
#import "JingCell.h"
#import "GiftModel.h"
#import "UIColor+AddColor.h"

#define kUIScreenWidth [UIScreen mainScreen].bounds.size.width
#define kUIScreenHeight [UIScreen mainScreen].bounds.size.height

@interface JingView ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong)UIButton *returnTopB;   //回到顶部button

@end

@implementation JingView

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.tableView = [[UITableView alloc]initWithFrame:(CGRectMake(0, 0, frame.size.width, frame.size.height)) style:(UITableViewStylePlain)];
        [self addSubview:self.tableView];
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.tableView.backgroundColor = [UIColor huiseColor];
        
        self.returnTopB = [[UIButton alloc]initWithFrame:(CGRectMake(self.bounds.size.width - 70, self.bounds.size.height - 100, 50, 50))];
        [self.returnTopB setBackgroundImage:[UIImage imageNamed:@"回到顶部"] forState:(UIControlStateNormal)];
        [self.returnTopB addTarget:self action:@selector(returnTop:) forControlEvents:(UIControlEventTouchUpInside)];
        [self addSubview:self.returnTopB];
        self.returnTopB.hidden = YES;
    }
    return self;
}
//
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat height = scrollView.frame.size.height;
    CGPoint offset = scrollView.contentOffset;
    NSInteger i = offset.y / height;
    if (i > 1 ) {
        self.returnTopB.hidden = NO;
    }else
    {
        self.returnTopB.hidden = YES;
    }
}

//
- (void)returnTop:(UIButton *)button
{
    [self.tableView setContentOffset:CGPointZero animated:YES];

}

//点击单元格 跳转
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row != 0) {
        GiftModel *gift = self.array[indexPath.row - 1];
        self.toDetailViewController(gift.Id);
    }
}

//单元格高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        return 0.56 * kUIScreenWidth;
    }
        return 0.48 * kUIScreenWidth;
    
}
//轮播图数组
-(void)setTaketurnArr:(NSMutableArray *)taketurnArr
{
    _taketurnArr = taketurnArr;
        [self.tableView reloadData];
    
}
//产品展示的数组
- (void)setArray:(NSMutableArray *)array
{
    _array = array;
    
    [self.tableView reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.array.count + 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        static NSString *identifier = @"taketurn";
        TaketurnCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell == nil) {
            cell = [[TaketurnCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:identifier];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.array = self.taketurnArr;
            [cell setImageVClick:^(NSString *ID) {
                self.toViewController(ID);
            }];
        return cell;
    }else
    {
    static NSString *identifier = @"gift";
    JingCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[JingCell alloc]initWithStyle:(UITableViewCellStyleValue1) reuseIdentifier:identifier];
    }
        cell.backgroundColor = [UIColor huiseColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        GiftModel *gift = self.array[indexPath.row - 1];
        cell.gift = gift;
    return cell;
}
    }

@end
