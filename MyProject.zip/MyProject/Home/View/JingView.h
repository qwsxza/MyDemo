//
//  JingView.h
//  MyProject
//
//  Created by gp on 15/11/5.
//  Copyright © 2015年 gp. All rights reserved.
//

//精选页面

#import <UIKit/UIKit.h>

@interface JingView : UIView

@property (nonatomic,strong) NSMutableArray *taketurnArr;
@property (nonatomic,strong) NSMutableArray *array;
@property (nonatomic,copy) void(^toViewController)(NSString *ID);
@property (nonatomic,strong) void(^toDetailViewController)(NSString *ID);
@property (nonatomic,strong)UITableView *tableView;




@end
