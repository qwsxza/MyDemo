
//
//  GiftItemCell.m
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "GiftItemCell.h"
#import "UIImageView+WebCache.h"
#import "AllGiftModel.h"

@interface GiftItemCell ()

@property (nonatomic,strong)UIImageView *imageV;
@property (nonatomic,strong)UILabel *name;
@property (nonatomic,strong)UILabel *price;
@property (nonatomic,strong)UIImageView *aixinV;
@property (nonatomic,strong)UILabel *favorite;

@end

@implementation GiftItemCell

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.imageV = [[UIImageView alloc]init];
        [self.contentView addSubview:self.imageV];
        
        self.name = [[UILabel alloc]init];
        [self.contentView addSubview:self.name];
        
        self.price = [[UILabel alloc]init];
        [self.contentView addSubview:self.price];
        
        self.aixinV = [[UIImageView alloc]init];
        [self.contentView addSubview:self.aixinV];
        
        self.favorite = [[UILabel alloc]init];
        [self.contentView addSubview:self.favorite];
    }
    return self;
}

-(void)setGift:(AllGiftModel *)gift
{
    _gift = gift;
    [self.imageV sd_setImageWithURL:[NSURL URLWithString:_gift.cover_image_url]];
    self.name.text = _gift.name;
    self.price.text = [NSString stringWithFormat:@"￥%@",_gift.price];
    self.favorite.text = [NSString stringWithFormat:@"%@",_gift.favorites_count];
}

-(void)layoutSubviews
{
    [super layoutSubviews];
    self.imageV.frame = CGRectMake(0, 0, self.contentView.frame.size.width, self.contentView.frame.size.width);
    
    self.name.frame = CGRectMake(5, self.imageV.frame.origin.y + self.imageV.frame.size.height , self.contentView.frame.size.width - 10, [UIScreen mainScreen].bounds.size.width / 10);
    self.name.font = [UIFont systemFontOfSize:13 weight:-1.0];
    self.name.numberOfLines = 0;
    
    self.price.frame = CGRectMake(7, self.name.frame.origin.y + self.name.frame.size.height, (self.contentView.frame.size.width - 14)/2,[UIScreen mainScreen].bounds.size.width / 25);
    self.price.font = [UIFont systemFontOfSize:12 weight:0];
    self.price.textColor = [UIColor redColor];
    
    self.favorite.frame = CGRectMake(self.contentView.frame.size.width - 7 - [UIScreen mainScreen].bounds.size.width / 10, self.price.frame.origin.y, [UIScreen mainScreen].bounds.size.width / 10, [UIScreen mainScreen].bounds.size.width / 25);
    self.favorite.font = [UIFont systemFontOfSize:11 weight:0];
    self.aixinV.frame = CGRectMake(self.contentView.frame.size.width - [UIScreen mainScreen].bounds.size.width / 10 - [UIScreen mainScreen].bounds.size.width / 25 - 7, self.price.frame.origin.y, [UIScreen mainScreen].bounds.size.width / 25, [UIScreen mainScreen].bounds.size.width / 25);
    self.aixinV.image = [UIImage imageNamed:@"爱心"];
}










@end
