//
//  TaketurnCell.m
//  MyProject
//
//  Created by gp on 15/11/6.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "TaketurnCell.h"
#import "UIImageView+WebCache.h"
#import "TaketurnModel.h"
#import "UIColor+AddColor.h"

#define kUIScreenWidth [UIScreen mainScreen].bounds.size.width
#define kUIScreenHeight [UIScreen mainScreen].bounds.size.height
@interface TaketurnCell ()<UIScrollViewDelegate>

@property (nonatomic,strong)UIScrollView *scrollView;  //轮播图
@property (nonatomic,strong)UIPageControl *page;  //
@property (nonatomic,assign)BOOL isSuccess;  //为了在layoutsubView只加载一次
@property (nonatomic,assign)BOOL isLoad;

@end

@implementation TaketurnCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.scrollView = [[UIScrollView alloc]init];
        [self.contentView addSubview:self.scrollView];
//        self.scrollView.backgroundColor = [UIColor yellowColor];
        self.scrollView.pagingEnabled = YES;
        self.scrollView.delegate = self;
        self.scrollView.showsVerticalScrollIndicator = NO;
        self.scrollView.showsHorizontalScrollIndicator = YES;
        
        self.page = [[UIPageControl alloc]init];
        [self.contentView addSubview:self.page];
        
        //自动播放
        [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(autoPlay:) userInfo:nil repeats:YES];
    }
    return self;
}
-(void)setArray:(NSMutableArray *)array
{
    _array = array;
    //轮播图
    if (self.isSuccess == NO && array.count != 0) {
        CGFloat width = self.scrollView.frame.size.width;
        for (int i = 0; i < _array.count + 1; i++) {
            UIImageView *imageV = [[UIImageView alloc]initWithFrame:(CGRectMake(i * width, 0, width, 150))];
            //图片比例不失真***
            //        imageV.contentMode = UIViewContentModeScaleAspectFill;
            UIButton *button = [UIButton buttonWithType:(UIButtonTypeSystem)];
            button.frame = imageV.frame;
            button.tag = 2000 + i;
            [button addTarget:self action:@selector(imageViewClick:) forControlEvents:(UIControlEventTouchUpInside)];
            [self.scrollView addSubview:button];
            
            if (i == _array.count) {
                TaketurnModel *take = _array[0];
                [imageV sd_setImageWithURL:[NSURL URLWithString:take.image_url]];
                [self.scrollView addSubview:imageV];
            }else{
                TaketurnModel *take = _array[i];
                [imageV sd_setImageWithURL:[NSURL URLWithString:take.image_url]];
                [self.scrollView addSubview:imageV];
            }
        }    //4个button创建**
        self.isSuccess = YES;
    }
    
}
-(void)layoutSubviews
{
    [super layoutSubviews];
    self.scrollView.frame = CGRectMake(0, 0, self.contentView.frame.size.width, self.contentView.frame.size.height / 3 * 2);
    self.scrollView.contentSize = CGSizeMake((self.array.count + 1) * self.contentView.frame.size.width, 0);
//    self.scrollView.backgroundColor = [UIColor redColor];
    
    self.page.frame = CGRectMake(self.contentView.frame.size.width / 3, self.scrollView.frame.size.height - kUIScreenWidth / 75 * 4, self.contentView.frame.size.width / 3, kUIScreenWidth / 75 * 4);
    self.page.numberOfPages = self.array.count;
//    self.page.backgroundColor = [UIColor blackColor];
    

    if (self.isLoad == NO) {
    NSArray *arr = @[@"美好小物",@"店长推荐",@"每日淘宝",@"天天刮奖"];
    NSArray *colorArr = @[[UIColor wetAsphaltColor],[UIColor hongse2],[UIColor tiankonglan],[UIColor jinjuse]];
    
    for (int i = 0; i < 4; i++) {
        UIButton *button = [UIButton buttonWithType:(UIButtonTypeCustom)];
        CGFloat buttonWidth = (self.scrollView.frame.size.width - 100) / 4;
        CGFloat buttonHeight = self.contentView.frame.size.height / 3;
        button.frame = CGRectMake(20 + i* (20 + buttonWidth) , self.scrollView.frame.size.height, buttonWidth, buttonHeight);
        UIImageView *imageV = [[UIImageView alloc]initWithFrame:(CGRectMake(button.frame.size.width / 4, button.frame.size.height / 10, button.frame.size.width / 2, button.frame.size.width / 2))];
        [button addSubview:imageV];
        imageV.image = [UIImage imageNamed:arr[i]];
        
        UILabel *label = [[UILabel alloc]initWithFrame:(CGRectMake(0, imageV.frame.origin.y + imageV.frame.size.height, button.frame.size.width, button.frame.size.height - imageV.frame.size.height - imageV.frame.origin.y))];
        [button addSubview:label];
        label.text = arr[i];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont systemFontOfSize:12];
        label.textColor = colorArr[i];
        
        [self.contentView addSubview:button];
        [button addTarget:self action:@selector(buttonClick:) forControlEvents:(UIControlEventTouchUpInside)];
        button.tag = i + 3000;
        
    }
        self.isLoad = YES;
  }
}

//轮播图View点击
- (void)imageViewClick:(UIButton *)button
{
    NSInteger i = button.tag - 2000;
    if (i == self.array.count) {
        TaketurnModel *take = self.array[0];
        self.imageVClick(take.target_id);
    }
    else{
        TaketurnModel *take = self.array[i];
        self.imageVClick(take.target_id);
    }

}
//好点推荐等button点击
- (void)buttonClick:(UIButton *)button
{
    if (button.tag == 3000) {
        [[NSNotificationCenter defaultCenter]postNotificationName:@"toHappySmallVC" object:nil];
    }
    if (button.tag == 3001) {
        [[NSNotificationCenter defaultCenter]postNotificationName:@"toBrandVC" object:nil userInfo:nil];
    }
    if (button.tag == 3002) {
        [[NSNotificationCenter defaultCenter]postNotificationName:@"toTaobaoVC" object:nil];
    }
}

//scrollView滚动代理
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    
    CGFloat width = scrollView.frame.size.width;
    CGPoint offset = scrollView.contentOffset;
    if (offset.x / width > self.array.count) {
        [scrollView setContentOffset:CGPointZero animated:NO];
    }
    if (offset.x < 0) {
//        [self SetCubeAnimation];
        [scrollView setContentOffset:(CGPointMake(width * self.array.count, 0)) animated:NO];
    }
    else{
//        [self SetCubeAnimation];
    }
    if (offset.x / width > self.array.count - 1) {
        self.page.currentPage = 0;
    }else
    {
    self.page.currentPage = offset.x / width;
    }
}

//立方体 动画
- (void)SetCubeAnimation
{
    CATransition *transition = [CATransition animation];
    transition.type = @"cube";
    transition.subtype = kCATransitionFromRight;
    transition.duration = 0.8;
    [self.scrollView.layer addAnimation:transition forKey:@"立方体效果"];
    
}
//自动播放
- (void)autoPlay:(NSTimer *)timer
{
    CGFloat width = self.scrollView.frame.size.width;
    CGPoint offset = self.scrollView.contentOffset;
    if (offset.x / width == self.array.count) {
        [self.scrollView setContentOffset:CGPointZero animated:NO];
        [self.scrollView setContentOffset:(CGPointMake(width, 0)) animated:NO];
        [self SetCubeAnimation];
    }else
    {
        [self.scrollView setContentOffset:(CGPointMake(width + offset.x, 0)) animated:NO];
        [self SetCubeAnimation];
    }
    

}




















@end
