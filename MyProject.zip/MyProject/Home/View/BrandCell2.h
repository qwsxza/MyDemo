//
//  BrandCell2.h
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BrandModel;

@interface BrandCell2 : UITableViewCell

@property (nonatomic,strong) BrandModel *brand;

@end
