//
//  AllGiftCell.h
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AllGiftCell : UITableViewCell

@property (nonatomic,strong) NSMutableArray *array;
@property (nonatomic,strong) void (^toDetailViewController)(NSString *ID);


@end
