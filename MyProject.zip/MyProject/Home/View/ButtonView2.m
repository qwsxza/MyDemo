



//
//  ButtonView.m
//  MyProject
//
//  Created by gp on 15/11/13.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "ButtonView2.h"
#import "UIColor+AddColor.h"
#define kUIScreenWidth [UIScreen mainScreen].bounds.size.width
#define kUIScreenHeight [UIScreen mainScreen].bounds.size.height

@interface ButtonView2 ()

@property (nonatomic,strong)UIButton *introButton;
@property (nonatomic,strong)UIButton *discuButton;
@property (nonatomic,strong)UILabel *redLabel;

@end

@implementation ButtonView2

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.introButton = [UIButton buttonWithType:(UIButtonTypeSystem)];
        self.introButton.frame = CGRectMake(0, 0, frame.size.width / 2, frame.size.height);
        [self addSubview:self.introButton];
        [self.introButton setTitle:@"图文介绍" forState:(UIControlStateNormal)];
        [self.introButton setTitleColor:[UIColor blackColor] forState:(UIControlStateNormal)];
        self.introButton.titleLabel.font = [UIFont systemFontOfSize:13 weight:-1.0];
        self.introButton.layer.borderColor = [[UIColor huiseColor]CGColor];
        self.introButton.layer.borderWidth = 0.5;
        self.introButton.tag = 5000;
        
        self.discuButton = [UIButton buttonWithType:(UIButtonTypeSystem)];
        self.discuButton.frame = CGRectMake(frame.size.width / 2, 0, frame.size.width / 2, frame.size.height);
        [self addSubview:self.discuButton];
        
//        NSString *str = [NSString stringWithFormat:@"评论(%@)",self.number];
//        [self.discuButton setTitle:str forState:(UIControlStateNormal)];
        
        [self.discuButton setTitleColor:[UIColor blackColor] forState:(UIControlStateNormal)];
        self.discuButton.titleLabel.font = [UIFont systemFontOfSize:13 weight:-1.0];
        self.discuButton.layer.borderColor = [[UIColor huiseColor]CGColor];
        self.discuButton.layer.borderWidth = 0.5;
        self.discuButton.tag = 5001;
        
        //redLabel
        self.redLabel = [[UILabel alloc]initWithFrame:(CGRectMake(0, frame.size.height - 2, frame.size.width / 2, 2))];
        [self addSubview:self.redLabel];
        self.redLabel.backgroundColor = [UIColor jinjuse];
        
        [self.discuButton addTarget:self action:@selector(clickButton:) forControlEvents:(UIControlEventTouchUpInside)];
        [self.introButton addTarget:self action:@selector(clickButton:) forControlEvents:(UIControlEventTouchUpInside)];
    }
    return self;
}

-(void)setNumber:(NSString *)number {
    _number = number;
    NSString *str = [NSString stringWithFormat:@"评论(%@)",self.number];
    [self.discuButton setTitle:str forState:(UIControlStateNormal)];

}
// redlabel移动  ***
- (void)clickButton:(UIButton *)button {
    if (button == self.discuButton) {
//        NSLog(@"%ld",button.tag);
        self.decisionCell(button.tag);
        [UIView animateWithDuration:0.2 animations:^{
            CGRect newframe = self.redLabel.frame;
            newframe.origin.x = kUIScreenWidth / 2;
            self.redLabel.frame = newframe;
        } completion:^(BOOL finished) {
            
        }];
    }else
    {
//        NSLog(@"%ld",button.tag);
        self.decisionCell(button.tag);
    [UIView animateWithDuration:0.2 animations:^{
        CGRect frame = self.redLabel.frame;
        frame.origin.x = 0;
        self.redLabel.frame = frame;
    } completion:^(BOOL finished) {
        
    }];
    }
}

@end
