



//
//  SearchView.m
//  MyProject
//
//  Created by gp on 15/11/14.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "SearchView.h"
#import "TitleModel.h"
#import "AFHTTPRequestOperationManager.h"
#import "AllGiftModel.h"
#import "GiftItemCell.h"
#import "UIColor+AddColor.h"
#import "JingCell.h"
#import "GiftModel.h"
#import "MJRefresh.h"

#define kUIScreenWidth [UIScreen mainScreen].bounds.size.width
#define kUIScreenHeight [UIScreen mainScreen].bounds.size.height

@interface SearchView ()<UISearchBarDelegate,UICollectionViewDataSource,UICollectionViewDelegate,UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong)UILabel *switchLabel;
@property (nonatomic,strong)UIButton *deleteButton;
@property (nonatomic,strong)UISearchBar *searchBar;
@property (nonatomic,assign)BOOL isonlyone;
@property (nonatomic,strong)NSMutableArray *itemsArray; //礼物数组
@property (nonatomic,strong)NSMutableArray *cellArray; //攻略数组
@property (nonatomic,strong)UICollectionView *collectionView;
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)UIButton *giftButton;
@property (nonatomic,strong)UIButton *gongButton;
@property (nonatomic,strong)UILabel *movelabel;
@property (nonatomic,assign)BOOL isCreatButton;
@property (nonatomic,strong)UIButton *returnTopB;
@property (nonatomic,strong)NSString *isWhichView;

@end

@implementation SearchView

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //切换频道label
        self.switchLabel = [[UILabel alloc]initWithFrame:(CGRectMake(10, 10, kUIScreenWidth / 6, 20 * kUIScreenWidth / 375))];
        [self addSubview:self.switchLabel];
        self.switchLabel.text = @"切换频道";
        self.switchLabel.textColor = [UIColor grayColor];
        self.switchLabel.font = [UIFont systemFontOfSize:13 weight:0];
    
        //searchBar
        self.searchBar = [[UISearchBar alloc]initWithFrame:(CGRectMake(kUIScreenWidth - kUIScreenWidth / 2 - 20, 10, kUIScreenWidth / 2, 20* kUIScreenWidth / 375))];
        [self addSubview:self.searchBar];
        self.searchBar.placeholder = @"搜索";
        self.searchBar.delegate = self;
        
        //分割线
        UILabel *label = [[UILabel alloc]initWithFrame:(CGRectMake(0, kUIScreenWidth / 10 - 0.5, kUIScreenWidth, 0.5))];
        label.backgroundColor = [UIColor grayColor];
        [self addSubview:label];
        
        //选项button 礼物与功略
        self.giftButton = [UIButton buttonWithType:(UIButtonTypeSystem)];
        self.giftButton.frame = CGRectMake(0, kUIScreenWidth / 10, kUIScreenWidth / 2, kUIScreenWidth / 10);
        [self.giftButton setTitle:@"礼物" forState:(UIControlStateNormal)];
        self.giftButton.backgroundColor = [UIColor whiteColor];
        self.giftButton.titleLabel.font = [UIFont systemFontOfSize:14 weight:-1.0];
        [self.giftButton setTitleColor:[UIColor blackColor] forState:(UIControlStateNormal)];
        self.giftButton.layer.borderColor = [[UIColor grayColor]CGColor];
        self.giftButton.layer.borderWidth = 0.3;
        [self.giftButton addTarget:self action:@selector(Switch:) forControlEvents:(UIControlEventTouchUpInside)];
        self.giftButton.tag = 8000;
        
        self.gongButton = [UIButton buttonWithType:(UIButtonTypeSystem)];
        self.gongButton.frame = CGRectMake(kUIScreenWidth / 2, kUIScreenWidth / 10, kUIScreenWidth / 2, kUIScreenWidth / 10);
        [self.gongButton setTitle:@"攻略" forState:(UIControlStateNormal)];
        self.gongButton.backgroundColor = [UIColor whiteColor];
        self.gongButton.titleLabel.font = [UIFont systemFontOfSize:14 weight:-1.0];
        [self.gongButton setTitleColor:[UIColor blackColor] forState:(UIControlStateNormal)];
        self.gongButton.layer.borderColor = [[UIColor grayColor]CGColor];
        self.gongButton.layer.borderWidth = 0.3;
        [self.gongButton addTarget:self action:@selector(Switch:) forControlEvents:(UIControlEventTouchUpInside)];
        self.gongButton.tag = 8001;
        
        
        //moveLabel
        self.movelabel = [[UILabel alloc]initWithFrame:(CGRectMake(0, kUIScreenWidth / 10 + kUIScreenWidth / 10 - 2, kUIScreenWidth / 2, 2))];
        self.movelabel.backgroundColor = [UIColor jinjuse];
        
        //uicollectionView
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
        layout.itemSize = CGSizeMake((kUIScreenWidth - kUIScreenWidth / 30 - 6) / 2, (kUIScreenWidth - kUIScreenWidth / 30 - 6) / 2 + kUIScreenWidth * 7 / 50 + 5);
        layout.minimumInteritemSpacing = 6;
        layout.minimumLineSpacing = kUIScreenWidth / 60;
        self.collectionView = [[UICollectionView alloc]initWithFrame:(CGRectMake(kUIScreenWidth / 60,  kUIScreenWidth / 10 + kUIScreenWidth / 10, kUIScreenWidth - kUIScreenWidth / 30,self.bounds.size.height - kUIScreenWidth / 10 - kUIScreenWidth / 10 - 5)) collectionViewLayout:layout];
        self.collectionView.delegate = self;
        self.collectionView.dataSource = self;
        self.collectionView.backgroundColor = [UIColor huiseColor];
        [self.collectionView registerClass:[GiftItemCell class] forCellWithReuseIdentifier:@"searchItem"];
        
        //uitableView
        self.tableView = [[UITableView alloc]initWithFrame:(CGRectMake(5, kUIScreenWidth / 10 + kUIScreenWidth / 10, kUIScreenWidth - 10, self.bounds.size.height - kUIScreenWidth / 10 - kUIScreenWidth / 10)) style:(UITableViewStylePlain)];
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        self.tableView.rowHeight = 0.48 * kUIScreenWidth;
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.tableView.backgroundColor = [UIColor huiseColor];
        
        //返回顶部button
        self.returnTopB = [[UIButton alloc]initWithFrame:(CGRectMake(self.bounds.size.width - 70, self.bounds.size.height - 100, 50, 50))];
        [self.returnTopB setBackgroundImage:[UIImage imageNamed:@"回到顶部"] forState:(UIControlStateNormal)];
        [self.returnTopB addTarget:self action:@selector(returnTop:) forControlEvents:(UIControlEventTouchUpInside)];
        [self addSubview:self.returnTopB];
        self.returnTopB.hidden = YES;
}
    return self;
}
//滑动 出现returnTopButton
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat height = scrollView.frame.size.height;
    CGPoint offset = scrollView.contentOffset;
    NSInteger i = offset.y / height;
    if (i > 1 ) {
        self.returnTopB.hidden = NO;
        [self addSubview:self.returnTopB];
    }else
    {
        self.returnTopB.hidden = YES;
    }
}

//返回顶部button  判断是在哪一个页面  滚动那个页面
- (void)returnTop:(UIButton *)button
{
    if ([self.isWhichView isEqualToString: @"礼物"]) {
        [self.collectionView setContentOffset:CGPointZero animated:YES];
    }else if ([self.isWhichView isEqualToString: @"攻略"])
    {
    [self.tableView setContentOffset:CGPointZero animated:YES];
    }else
    {
        [self.collectionView setContentOffset:CGPointZero animated:YES];
    }
    
}

//点击单元格触发方法
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    GiftModel *gift = self.cellArray[indexPath.row];
    self.toTableDetailVC(gift.Id);
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    AllGiftModel *gift = [[AllGiftModel alloc]init];
    gift = self.itemsArray[indexPath.item];
    self.toCollectDetailVC(gift.ID);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.cellArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"jing";
    JingCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[JingCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:identifier];
    }
    GiftModel *gift = self.cellArray[indexPath.row];
    cell.gift = gift;
    return cell;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.itemsArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    GiftItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"searchItem" forIndexPath:indexPath];
    cell.backgroundColor = [UIColor whiteColor];
    AllGiftModel *gift = self.itemsArray[indexPath.row];
    cell.gift = gift;
    return cell;
}

//礼物数据加载
- (void)hundleItemWithNum:(NSInteger)num
{
    NSString *str = [NSString stringWithFormat:@"http://api.liwushuo.com/v1/search/item?keyword=%@&limit=20&offset=%ld&sort=",self.searchBar.text,num];
    
    NSString *url = [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    [[AFHTTPRequestOperationManager manager]GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSArray *array = responseObject[@"data"][@"items"];
        for (NSDictionary *dic in array) {
            AllGiftModel *gift = [[AllGiftModel alloc]init];
            [gift setValuesForKeysWithDictionary:dic];
            [self.itemsArray addObject:gift];
        }
        if (array.count == 20) {
            self.collectionView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
                [self hundleItemWithNum:self.itemsArray.count];
            }];
        }else
        {
            self.collectionView.footer = nil;
        }
        [self.collectionView reloadData];
        [self.collectionView.footer endRefreshing];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"搜索加载数据item%@",error);
    }];
}

//攻略数据加载
- (void)hundleCellWithNum:(NSInteger )num
{
    NSString *str = [NSString stringWithFormat:@"http://api.liwushuo.com/v1/search/post?keyword=%@&limit=20&offset=%ld&sort=",self.searchBar.text,num];
    NSString *url = [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    [[AFHTTPRequestOperationManager manager]GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSArray *array = responseObject[@"data"][@"posts"];
        for (NSDictionary *dic in array) {
            GiftModel *gift = [[GiftModel alloc]init];
            [gift setValuesForKeysWithDictionary:dic];
            [self.cellArray addObject:gift];
        }
        if (array.count == 20) {
            //添加一次 就存在了
            self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
                [self hundleCellWithNum:self.cellArray.count];
            }];
        }else
        {
            self.tableView.footer = nil;
        }
        [self.tableView reloadData];
        [self.tableView.footer endRefreshing];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"搜索加载cell数据%@",error);
    }];

}
//礼物, 攻略button点击
- (void)Switch:(UIButton *)button
{
    NSInteger i = button.tag - 8000;
    if (i == 1) {
        self.isWhichView = @"攻略";
        [self bringSubviewToFront:self.tableView];
        [UIView animateWithDuration:0.3 animations:^{
            CGRect newframe = self.movelabel.frame;
            newframe.origin.x = kUIScreenWidth / 2;
            self.movelabel.frame = newframe;
        } completion:^(BOOL finished) {
            
        }];
    }else
    {
        self.isWhichView = @"礼物";
        [self bringSubviewToFront:self.collectionView];
        [UIView animateWithDuration:0.3 animations:^{
            CGRect newframe = self.movelabel.frame;
            newframe.origin.x = 0;
            self.movelabel.frame = newframe;
        } completion:^(BOOL finished) {
        }];
    }
}
//searchbar输入值变化
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    self.cellArray = [NSMutableArray array];
    self.itemsArray = [NSMutableArray array];
    if (self.isCreatButton == NO) {
        [self addSubview:self.gongButton];
        [self addSubview:self.giftButton];
        [self addSubview:self.movelabel];
        [self addSubview:self.tableView];
        [self addSubview:self.collectionView];

        self.isCreatButton = YES;
    }
    if ([searchText isEqualToString:@""]) {
        self.collectionView.hidden = YES;
        self.tableView.hidden = YES;
        self.gongButton.hidden = YES;
        self.giftButton.hidden = YES;
        self.movelabel.hidden = YES;
    }else {
        self.collectionView.hidden = NO;
        self.tableView.hidden = NO;
        self.gongButton.hidden = NO;
        self.giftButton.hidden = NO;
        self.movelabel.hidden = NO;
    [self hundleItemWithNum:0];
    [self hundleCellWithNum:0];
    }

}
//外部解析button 的数组 传进来
-(void)setArray:(NSMutableArray *)array
{
        _array = array;
    if (self.isonlyone == NO) {
        CGFloat buttonWidth = (kUIScreenWidth - 50)/4;
        CGFloat buttonX = 10 ;
        CGFloat buttonY = kUIScreenWidth / 15  + kUIScreenWidth / 10;
        CGFloat buttonHeight = kUIScreenWidth / 15;
        CGFloat spacing = kUIScreenWidth / 15;
        for (int i = 0; i < self.array.count; i++) {
            UIButton *button = [UIButton buttonWithType:(UIButtonTypeSystem)];
            [button addTarget:self action:@selector(buttonClick:) forControlEvents:(UIControlEventTouchUpInside)];
            [self addSubview:button];
            button.layer.cornerRadius = 3;
            button.layer.masksToBounds = YES;
            button.layer.borderColor = [[UIColor grayColor]CGColor];
            button.layer.borderWidth = 1;
            button.tag = i + 7000;
            TitleModel *title = array[i];
            [button setTitle:title.name forState:(UIControlStateNormal)];
            [button setTitleColor:[UIColor blackColor] forState:(UIControlStateNormal)];
            button.titleLabel.font = [UIFont systemFontOfSize:12 weight:0];
            if (i == 0) {
                button.frame = CGRectMake(buttonX, buttonY, buttonWidth, buttonHeight);
            }else{
                if (i < 4) {
                    button.frame = CGRectMake(buttonX + (buttonX + buttonWidth) * i, buttonY, buttonWidth, buttonHeight);
                }else
                {
                    if (i == 4) {
                        button.frame = CGRectMake(buttonX, buttonY + spacing +buttonHeight, buttonWidth, buttonHeight);
                    }else
                    {
                        button.frame = CGRectMake(buttonX + (buttonX + buttonWidth) * (i - 4), spacing + buttonHeight + buttonY, buttonWidth, buttonHeight);
                    }
                }
            }
        }self.isonlyone = YES;
    }
}
//精品等button的点击
- (void)buttonClick:(UIButton *)button
{
    NSInteger num = button.tag - 7000;
    if (self.delegate && [self.delegate respondsToSelector:@selector(ChangePlateWithNum:)]) {
        [self.delegate ChangePlateWithNum:num];
    }
}




@end
