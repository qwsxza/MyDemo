




//
//  DiscussCell.m
//  MyProject
//
//  Created by gp on 15/11/13.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "EveryDiscussCell.h"
#import "DiscussModel.h"
#import "UIImageView+WebCache.h"
#import "UserModel.h"
#import "UIColor+AddColor.h"

#define kUIScreenWidth [UIScreen mainScreen].bounds.size.width
#define kUIScreenHeight [UIScreen mainScreen].bounds.size.height

@interface EveryDiscussCell ()

@property (nonatomic,strong)UIImageView *imageV;
@property (nonatomic,strong)UILabel *nickname;
@property (nonatomic,strong)UILabel *content;
@property (nonatomic,strong)UILabel *dateLabel;

@end

@implementation EveryDiscussCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.imageV = [[UIImageView alloc]init];
        [self.contentView addSubview:self.imageV];
        
        self.nickname = [[UILabel alloc]init];
        [self.contentView addSubview:self.nickname];
        self.content = [[UILabel alloc]init];
        [self.contentView addSubview:self.content];
        self.dateLabel = [[UILabel alloc]init];
        [self.contentView addSubview:self.dateLabel];
    }
    return self;
}

- (void)setDiscuss:(DiscussModel *)discuss
{
    _discuss = discuss;
    [self.imageV sd_setImageWithURL:[NSURL URLWithString:_discuss.user.avatar_url] placeholderImage:[UIImage imageNamed:@"用户"]];
    self.content.text = _discuss.content;
    [self.content sizeToFit];
    self.content.numberOfLines = 0;
    self.nickname.text = _discuss.user.nickname;
    //时间戳转时间
    NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:@"MM-dd H:mm"];
    NSDate *confromTimesp = [NSDate dateWithTimeIntervalSince1970:[_discuss.created_at longLongValue]];
    NSString *dateString = [formatter stringFromDate:confromTimesp];
    self.dateLabel.text = dateString;
    
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    self.imageV.frame = CGRectMake(10, 10, self.contentView.frame.size.width / 10, self.contentView.frame.size.width / 10);
    self.imageV.layer.masksToBounds = YES;
    self.imageV.layer.cornerRadius = self.imageV.frame.size.width / 2;
//    self.imageV.backgroundColor = [UIColor yellowColor];
    
    self.nickname.frame = CGRectMake(self.imageV.frame.size.width + self.imageV.frame.origin.x + 5, self.imageV.frame.origin.y, self.contentView.frame.size.width / 2, 20 * kUIScreenWidth / 375);
//    self.nickname.backgroundColor = [UIColor greenColor];
    self.nickname.font = [UIFont systemFontOfSize:12 weight:0];
    
    
    self.content.frame = CGRectMake(self.nickname.frame.origin.x, self.nickname.frame.size.height + self.nickname.frame.origin.y + 5 , kUIScreenWidth - 25 - kUIScreenWidth / 10, 1000);
    self.content.font = [UIFont systemFontOfSize:14 weight:0];
    self.content.textColor = [UIColor shenhuiseColor];
    [self.content sizeToFit];
    self.content.numberOfLines = 0;
//    self.content.backgroundColor =[UIColor redColor];
    
    self.dateLabel.frame = CGRectMake(self.contentView.frame.size.width - 10 - self.contentView.frame.size.width / 4, 10, self.contentView.frame.size.width / 4, 10);
    self.dateLabel.textAlignment = NSTextAlignmentRight;
//    self.dateLabel.textColor = [UIColor grayColor];
    self.dateLabel.font = [UIFont systemFontOfSize:10];
    
    
}
@end
