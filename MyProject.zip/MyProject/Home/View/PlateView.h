//
//  DoubleView.h
//  MyProject
//
//  Created by gp on 15/11/6.
//  Copyright © 2015年 gp. All rights reserved.
//

//模块View

#import <UIKit/UIKit.h>

@interface PlateView : UIView

@property (nonatomic,strong) NSMutableArray *array;

@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)void(^toDetailViewController)(NSString *ID);


@end
