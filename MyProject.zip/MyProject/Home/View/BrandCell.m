


//
//  BrandCell.m
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "BrandCell.h"
#import "UIImageView+WebCache.h"
#import "BrandModel.h"
#import "UIColor+AddColor.h"
#define kLeft 10
#define kRight 10
#define kTop 10
#define kSpacing 3
#define kBigWidth (self.backImage.frame.size.width - kLeft - kRight - kSpacing)/2
#define kSmallWidth (kBigWidth - kSpacing) / 2
#define kBackImageLeft [UIScreen mainScreen].bounds.size.width / 60
#define kBackImageTop [UIScreen mainScreen].bounds.size.width / 60
#define kImageLogoWidth [UIScreen mainScreen].bounds.size.width / 8

@interface BrandCell ()

@property (nonatomic,strong)UIImageView *backImage;
@property (nonatomic,strong)UIImageView *imageLogo;
@property (nonatomic,strong)UILabel *name;
@property (nonatomic,strong)UILabel *desLabel;
@property (nonatomic,strong)UILabel *titleLabel;
@property (nonatomic,strong)UIImageView *imageBig;
@property (nonatomic,strong)UIImageView *imageSmall1;
@property (nonatomic,strong)UIImageView *imageSmall2;
@property (nonatomic,strong)UIImageView *imageSmall3;
@property (nonatomic,strong)UIImageView *imageSmall4;

@end

@implementation BrandCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backImage = [[UIImageView alloc]init];
        [self.contentView addSubview:self.backImage];
        self.backImage.image = [UIImage imageNamed:@"纯白.jpg"];
        self.backImage.layer.masksToBounds = YES;
        self.backImage.layer.cornerRadius = 3;
        
        self.imageLogo = [[UIImageView alloc]init];
        [self.backImage addSubview:self.imageLogo];
        self.imageLogo.layer.borderWidth = 1;
        self.imageLogo.layer.borderColor = [[UIColor huiseColor]CGColor];
        
        self.name = [[UILabel alloc]init];
        [self.backImage addSubview:self.name];
        self.name.font = [UIFont systemFontOfSize:16 weight:-1.0];

        
        self.desLabel = [[UILabel alloc]init];
        [self.backImage addSubview:self.desLabel];
        self.desLabel.font = [UIFont systemFontOfSize:13 weight:-1.0];
        self.desLabel.textColor = [UIColor grayColor];
        
        self.titleLabel = [[UILabel alloc]init];
        [self.backImage addSubview:self.titleLabel];
        self.titleLabel.textAlignment = NSTextAlignmentRight;
        self.titleLabel.text = @"品牌主页>";
        self.titleLabel.font = [UIFont systemFontOfSize:13 weight:-1.0];
        self.titleLabel.textColor = [UIColor grayColor];
        
        self.imageBig = [[UIImageView alloc]init];
        [self.backImage addSubview:self.imageBig];
        
        self.imageSmall1 = [[UIImageView alloc]init];
        [self.backImage addSubview:self.imageSmall1];
        
        self.imageSmall2 = [[UIImageView alloc]init];
        [self.backImage addSubview:self.imageSmall2];
        
        self.imageSmall3 = [[UIImageView alloc]init];
        [self.backImage addSubview:self.imageSmall3];
        
        self.imageSmall4 = [[UIImageView alloc]init];
        [self.backImage addSubview:self.imageSmall4];
        
    }
    return self;
}

-(void)setBrand:(BrandModel *)brand
{
    _brand = brand;
    
    [self.imageLogo sd_setImageWithURL:[NSURL URLWithString:_brand.icon_url]];
    self.name.text = _brand.name;
    self.desLabel.text = _brand.desc;
    [self.imageBig sd_setImageWithURL:[NSURL URLWithString:_brand.image_urls[0]]];
    [self.imageSmall1 sd_setImageWithURL:[NSURL URLWithString:_brand.image_urls[1]]];
    [self.imageSmall2 sd_setImageWithURL:[NSURL URLWithString:_brand.image_urls[2]]];
    [self.imageSmall3 sd_setImageWithURL:[NSURL URLWithString:_brand.image_urls[3]]];
    [self.imageSmall4 sd_setImageWithURL:[NSURL URLWithString:_brand.image_urls[4]]];
    
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    self.backImage.frame = CGRectMake(kBackImageLeft, kBackImageTop, self.contentView.frame.size.width - 2 * kBackImageLeft, self.contentView.frame.size.height - kBackImageTop);
    
    self.imageLogo.frame = CGRectMake(kLeft, kTop, kImageLogoWidth, kImageLogoWidth);

    self.name.frame = CGRectMake(self.imageLogo.frame.origin.x + self.imageLogo.frame.size.width + 5, self.imageLogo.frame.origin.y, self.backImage.frame.size.width / 2, self.imageLogo.frame.size.height / 2);

    self.desLabel.frame = CGRectMake(self.name.frame.origin.x, self.name.frame.origin.y + self.name.frame.size.height, self.name.frame.size.width, self.name.frame.size.height);

    self.titleLabel.frame = CGRectMake(self.backImage.frame.size.width - kRight - 80, kTop + kImageLogoWidth / 2 - 10, 80, 20);
    
    self.imageSmall1.frame = CGRectMake(kLeft, self.imageLogo.frame.origin.y + self.imageLogo.frame.size.height + 15, kSmallWidth, kSmallWidth);
//    self.imageSmall1.backgroundColor = [UIColor grayColor];
    
    self.imageSmall2.frame = CGRectMake(self.imageSmall1.frame.origin.x + self.imageSmall1.frame.size.width + kSpacing, self.imageSmall1.frame.origin.y, kSmallWidth, kSmallWidth);
//    self.imageSmall2.backgroundColor = [UIColor grayColor];
    
    self.imageSmall3.frame = CGRectMake(kLeft, self.imageSmall1.frame.origin.y + self.imageSmall1.frame.size.height + kSpacing, kSmallWidth, kSmallWidth);
//    self.imageSmall3.backgroundColor = [UIColor grayColor];
    
    self.imageSmall4.frame = CGRectMake(self.imageSmall2.frame.origin.x, self.imageSmall2.frame.origin.y + self.imageSmall2.frame.size.height + kSpacing, kSmallWidth, kSmallWidth);
//    self.imageSmall4.backgroundColor = [UIColor grayColor];

    self.imageBig.frame = CGRectMake(self.imageSmall2.frame.origin.x + self.imageSmall2.frame.size.width + kSpacing, self.imageSmall1.frame.origin.y, kBigWidth, kBigWidth);
//    self.imageBig.backgroundColor = [UIColor blackColor];

}


@end
