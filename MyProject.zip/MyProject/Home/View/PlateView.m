
//
//  DoubleView.m
//  MyProject
//
//  Created by gp on 15/11/6.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "PlateView.h"
#import "JingCell.h"
#import "GiftModel.h"
#import "UIColor+AddColor.h"


#define kUIScreenWidth [UIScreen mainScreen].bounds.size.width
#define kUIScreenHeight [UIScreen mainScreen].bounds.size.height

@interface PlateView ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong)UIButton *returnTopB;   //回到顶部button

@end

@implementation PlateView

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.tableView = [[UITableView alloc]initWithFrame:(CGRectMake(0, 0, frame.size.width, frame.size.height)) style:(UITableViewStylePlain)];
        [self addSubview:self.tableView];
        
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        self.tableView.rowHeight = 0.48 * kUIScreenWidth;
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.tableView.backgroundColor = [UIColor huiseColor];
        
        //返回顶部button
        self.returnTopB = [[UIButton alloc]initWithFrame:(CGRectMake(self.bounds.size.width - 70, self.bounds.size.height - 100, 50, 50))];
        [self.returnTopB setBackgroundImage:[UIImage imageNamed:@"回到顶部"] forState:(UIControlStateNormal)];
        [self.returnTopB addTarget:self action:@selector(returnTop:) forControlEvents:(UIControlEventTouchUpInside)];
        [self addSubview:self.returnTopB];
        self.returnTopB.hidden = YES;
    }
    return self;
}

//
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat height = scrollView.frame.size.height;
    CGPoint offset = scrollView.contentOffset;
    NSInteger i = offset.y / height;
    if (i > 1 ) {
        self.returnTopB.hidden = NO;
    }else
    {
        self.returnTopB.hidden = YES;
    }
}

//返回顶部button
- (void)returnTop:(UIButton *)button
{
    [self.tableView setContentOffset:CGPointZero animated:YES];
    
    
}
//点击单元格 跳转
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
        GiftModel *gift = self.array[indexPath.row];
        self.toDetailViewController(gift.Id);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.array.count;
}

- (void)setArray:(NSMutableArray *)array
{
    _array = array;
    [self.tableView reloadData];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"doubel";
    JingCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[JingCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:identifier];
    }
    cell.backgroundColor = [UIColor huiseColor];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    GiftModel *gift = self.array[indexPath.row];
    cell.gift = gift;
    return cell;
}
@end
