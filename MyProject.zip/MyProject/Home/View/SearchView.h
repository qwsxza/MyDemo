//
//  SearchView.h
//  MyProject
//
//  Created by gp on 15/11/14.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SearchViewDelegate <NSObject>

- (void)ChangePlateWithNum:(NSInteger)num;

@end

@interface SearchView : UIView

@property (nonatomic,strong) NSMutableArray *array;
@property (nonatomic,strong) id<SearchViewDelegate>delegate;
@property (nonatomic,strong) void (^toTableDetailVC)(NSString *ID);
@property (nonatomic,strong) void (^toCollectDetailVC)(NSString *ID);


@end
