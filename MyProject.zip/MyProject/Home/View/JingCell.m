
//
//  JingCell.m
//  MyProject
//
//  Created by gp on 15/11/6.
//  Copyright © 2015年 gp. All rights reserved.
//


//物品展示的cell
#import "JingCell.h"
#import "UIImageView+WebCache.h"
#import "GiftModel.h"
#import "UIColor+AddColor.h"

#define kUIScreenWidth [UIScreen mainScreen].bounds.size.width
#define kUIScreenHeight [UIScreen mainScreen].bounds.size.height

@interface JingCell ()

@property (nonatomic,strong)UIImageView *imageV;  //图片
@property (nonatomic,strong)UILabel *titleLabel;  //标题
@property (nonatomic,strong)UILabel *dateLabel;  //时间
@property (nonatomic,strong)UILabel *backLabel;  //
@property (nonatomic,strong)UILabel *numLabel; //数目
@property (nonatomic,strong)UIImageView *aixinV; //爱心

@end

@implementation JingCell

//刷新tableView  次方法不走
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.imageV = [[UIImageView alloc]init];
        [self.contentView addSubview:self.imageV];
        
        self.titleLabel = [[UILabel alloc]init];
        [self.contentView addSubview:self.titleLabel];
        
        self.dateLabel = [[UILabel alloc]init];
        [self.imageV addSubview:self.dateLabel];
        
        self.backLabel = [[UILabel alloc]init];
        [self.imageV addSubview:self.backLabel];
        
        self.numLabel = [[UILabel alloc]init];
        [self.backLabel addSubview:self.numLabel];
        
        self.aixinV = [[UIImageView alloc]init];
        [self.backLabel addSubview:self.aixinV];
    }
    return self;
}

-(void)layoutSubviews
{
    [super layoutSubviews];
    self.imageV.frame = CGRectMake(5, 5, self.contentView.frame.size.width - 10,self.contentView.frame.size.height - 7.5);
//    self.imageV.backgroundColor = [UIColor redColor];
    self.titleLabel.frame = CGRectMake(10, self.imageV.frame.size.height - 20, self.imageV.frame.size.width - 20,kUIScreenWidth * 4 / 75);
    self.titleLabel.textColor = [UIColor whiteColor];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.1];
    self.titleLabel.layer.masksToBounds = YES;
    self.titleLabel.layer.cornerRadius = 10;
    
    self.dateLabel.frame = CGRectMake(5, 0, 200, kUIScreenWidth * 4 / 75);
    self.dateLabel.textColor = [UIColor whiteColor];
    self.dateLabel.font = [UIFont systemFontOfSize:15];

    self.backLabel.frame = CGRectMake(self.imageV.frame.size.width - 5 - 65, 5, 65 , 25);
    self.backLabel.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
    self.backLabel.layer.masksToBounds = YES;
    self.backLabel.layer.cornerRadius = 12;
    
    self.aixinV.frame = CGRectMake(5, 5, 15, 15);
    self.aixinV.image = [UIImage imageNamed:@"爱心"];
    
    self.numLabel.frame = CGRectMake(25, 5, 40, 15);
//    self.numLabel.backgroundColor = [UIColor redColor];
    self.numLabel.font = [UIFont systemFontOfSize:11];
    self.numLabel.textColor = [UIColor whiteColor];
    
}
-(void)setGift:(GiftModel *)gift
{
    _gift = gift;
    [self.imageV sd_setImageWithURL:[NSURL URLWithString:_gift.cover_image_url]];
    self.titleLabel.text = _gift.title;
    if (_gift.title.length < 17) {
        self.titleLabel.font = [UIFont systemFontOfSize:18];
    }else
    {
        self.titleLabel.font = [UIFont systemFontOfSize:15];
    }
    
    //时间戳转时间
    NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:@"MM月dd日"];
    NSDate *confromTimesp = [NSDate dateWithTimeIntervalSince1970:[_gift.created_at longLongValue]];
    NSString *dateString = [formatter stringFromDate:confromTimesp];
    self.dateLabel.text = dateString;
    
    
    self.numLabel.text = [NSString stringWithFormat:@"%@",_gift.likes_count];
    
}
























@end
