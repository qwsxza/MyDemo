
//
//  GiftDetailCell.m
//  MyProject
//
//  Created by gp on 15/11/10.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "GiftDetailCell.h"
#import "GiftDetailModel.h"
#import "UIColor+AddColor.h"

@interface GiftDetailCell ()

@property (nonatomic,strong)UILabel *titleLabel;
@property (nonatomic,strong)UILabel *shareLabel;
@property (nonatomic,strong)UILabel *timeLabel;
@property (nonatomic,strong)UIButton *detailB;

@end

@implementation GiftDetailCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.titleLabel = [[UILabel alloc]init];
        [self.contentView addSubview:self.titleLabel];
        self.titleLabel.textColor = [UIColor shenhuiseColor];
        self.titleLabel.font = [UIFont systemFontOfSize:16];
        
        self.shareLabel = [[UILabel alloc]init];
        [self.contentView addSubview:self.shareLabel];
        self.shareLabel.textColor = [UIColor pomegranateColor];
        self.shareLabel.font = [UIFont systemFontOfSize:15];
        
        self.timeLabel = [[UILabel alloc]init];
        [self.contentView addSubview:self.timeLabel];
        self.timeLabel.textColor = [UIColor jinjuse];
        self.timeLabel.textAlignment = NSTextAlignmentRight;
        self.timeLabel.font = [UIFont systemFontOfSize:15];
        
        //查看详情
        self.detailB = [[UIButton alloc]init];
        [self.contentView addSubview:self.detailB];
        [self.detailB setTitle:@"查看详情" forState:(UIControlStateNormal)];
        //字体大小
        self.detailB.titleLabel.font = [UIFont systemFontOfSize:13];
        [self.detailB setTitleColor:[UIColor orangeColor] forState:(UIControlStateNormal)];
        //设置边框 宽度和颜色
        self.detailB.layer.cornerRadius = 15;
        self.detailB.layer.borderWidth = 2;
        self.detailB.layer.borderColor = [[UIColor orangeColor]CGColor];
        [self.detailB addTarget:self action:@selector(enterDetail:) forControlEvents:(UIControlEventTouchUpInside)];
        
        
    }
    return self;
}

- (void)enterDetail:(UIButton *)button
{
    self.enterDetail(self.giftDetail.content_html);
}

-(void)setGiftDetail:(GiftDetailModel *)giftDetail
{
    _giftDetail = giftDetail;
    self.titleLabel.text = _giftDetail.share_msg;

    
    NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:@"MM月dd日"];
    NSDate *confromTimesp = [NSDate dateWithTimeIntervalSince1970:[_giftDetail.created_at longLongValue]];
    NSString *dateString = [formatter stringFromDate:confromTimesp];
    self.timeLabel.text = dateString;
    
    NSString *number = [NSString stringWithFormat:@"分享人数:%@",_giftDetail.shares_count];
    self.shareLabel.text = number;
    
}

-(void)layoutSubviews
{
    [super layoutSubviews];
    self.titleLabel.frame = CGRectMake(10, 20, self.contentView.frame.size.width - 20, 1000);
    [self.titleLabel sizeToFit];
    self.titleLabel.numberOfLines = 0;
    
    self.shareLabel.frame = CGRectMake(10, self.titleLabel.frame.origin.y + self.titleLabel.frame.size.height + 10, (self.contentView.frame.size.width - 100)/2, 20);
    self.timeLabel.frame = CGRectMake(self.contentView.frame.size.width - 10 - self.shareLabel.frame.size.width, self.shareLabel.frame.origin.y, self.shareLabel.frame.size.width, 20);
    
    self.detailB.frame = CGRectMake(self.contentView.frame.size.width / 2 - 40, self.shareLabel.frame.origin.y - 5, 80, 30);
    
}









@end
