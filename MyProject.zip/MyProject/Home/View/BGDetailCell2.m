
//
//  BGDetailCell2.m
//  MyProject
//
//  Created by gp on 15/11/13.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "BGDetailCell2.h"
#import "BGDetailModel.h"

#define kUIScreenWidth [UIScreen mainScreen].bounds.size.width
#define kUIScreenHeight [UIScreen mainScreen].bounds.size.height

@interface BGDetailCell2 ()

@property (nonatomic,strong)UILabel *name;
@property (nonatomic,strong)UILabel *price;
@property (nonatomic,strong)UILabel *deslabel;

@end

@implementation BGDetailCell2

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.name = [[UILabel alloc]init];
        [self.contentView addSubview:self.name];
        self.name.font = [UIFont systemFontOfSize:16 weight:0];
//        self.name.backgroundColor = [UIColor greenColor];
        self.price = [[UILabel alloc]init];
        [self.contentView addSubview:self.price];
        self.price.font = [UIFont systemFontOfSize:14 weight:0];
        self.price.textColor = [UIColor orangeColor];
//        self.price.backgroundColor = [UIColor redColor];
        self.deslabel = [[UILabel alloc]init];
        [self.contentView addSubview:self.deslabel];
        self.deslabel.font = [UIFont systemFontOfSize:13 weight:0];
        self.deslabel.textColor = [UIColor grayColor];
//        self.deslabel.backgroundColor = [UIColor blackColor];
    }
    return self;
}
-(void)setGift:(BGDetailModel *)gift
{
    _gift = gift;
    self.name.text = _gift.name;
    self.price.text = [NSString stringWithFormat:@"￥%@",_gift.price];
    [_gift.Description stringByReplacingOccurrencesOfString:@"" withString:@" "];
    self.deslabel.text = _gift.Description;
    
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    self.name.frame = CGRectMake(10, 5, kUIScreenWidth - 20, 20 * kUIScreenWidth / 375);
    self.price.frame = CGRectMake(10, self.name.frame.origin.y + self.name.frame.size.height + 5, self.name.frame.size.width, kUIScreenWidth * 15 / 375);
    self.deslabel.frame = CGRectMake(10, self.price.frame.origin.y + self.price.frame.size.height + 5, self.name.frame.size.width, 1000);
    
    self.deslabel.numberOfLines = 0;
    [self.deslabel sizeToFit];
    
}
@end
