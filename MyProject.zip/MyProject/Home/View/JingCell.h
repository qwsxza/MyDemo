//
//  JingCell.h
//  MyProject
//
//  Created by gp on 15/11/6.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <UIKit/UIKit.h>
@class GiftModel;

@interface JingCell : UITableViewCell

@property (nonatomic,strong) GiftModel *gift;


@end
