//
//  DiscussCell.h
//  MyProject
//
//  Created by gp on 15/11/13.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiscussCell : UITableViewCell

@property (nonatomic,strong) NSMutableArray *array;
@property (nonatomic,strong)UITableView *tableView;


@end
