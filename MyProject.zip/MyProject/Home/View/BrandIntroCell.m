//
//  BrandIntroCell.m
//  MyProject
//
//  Created by gp on 15/11/14.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "BrandIntroCell.h"
#import "BrandModel.h"

@interface BrandIntroCell ()


@end

@implementation BrandIntroCell

//品牌介绍Cell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.web = [[UIWebView alloc]init];
        [self.contentView addSubview:self.web];
        self.web.scrollView.scrollEnabled = NO;
    }
    return self;
}
-(void)setBrand:(BrandModel *)brand
{
    _brand = brand;
    [self.web loadHTMLString:_brand.intro_html baseURL:nil];
}

-(void)layoutSubviews
{
    [super layoutSubviews];
    self.web.frame = CGRectMake(0, 0, self.contentView.frame.size.width, self.contentView.frame.size.height);
    
}
@end
