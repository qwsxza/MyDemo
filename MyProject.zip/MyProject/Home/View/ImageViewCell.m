



//
//  ImageViewCell.m
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "ImageViewCell.h"
#import "BrandModel.h"
#import "UIImageView+WebCache.h"
#import "UIColor+AddColor.h"


#define kUISreenWidth [UIScreen mainScreen].bounds.size.width
@interface ImageViewCell ()

@property (nonatomic,strong)UIImageView *imageV;
@property (nonatomic,strong)UIImageView *imageLogo;
@property (nonatomic,strong)UILabel *name;
@property (nonatomic,strong)UILabel *desLabel;
@property (nonatomic,strong)UILabel *dangban;  //挡板
@property (nonatomic,strong)UILabel *dangban2;  //挡板

@end

@implementation ImageViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.imageV = [[UIImageView alloc]init];
        [self.contentView addSubview:self.imageV];
        
        self.dangban = [[UILabel alloc]init];
        self.dangban.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.1];
        [self.contentView addSubview:self.dangban];
        
        self.dangban2 = [[UILabel alloc]init];
        self.dangban2.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:self.dangban2];
        
        self.imageLogo = [[UIImageView alloc]init];
        [self.contentView addSubview:self.imageLogo];
        
        self.name = [[UILabel alloc]init];
        [self.contentView addSubview:self.name];
    
        self.desLabel = [[UILabel alloc]init];
        [self.contentView addSubview:self.desLabel];
    }
    return self;
}

- (void)setBrand:(BrandModel *)brand
{
    _brand = brand;
    [self.imageV sd_setImageWithURL:[NSURL URLWithString:_brand.cover_image_url]];
    [self.imageLogo sd_setImageWithURL:[NSURL URLWithString:_brand.icon_url]];
    self.name.text = _brand.name;
    self.desLabel.text = _brand.desc;
}
-(void)layoutSubviews
{
    [super layoutSubviews];
    self.imageV.frame = CGRectMake(0, 0, kUISreenWidth, self.contentView.frame.size.height);
//    self.imageV.backgroundColor = [UIColor purpleColor];
    self.dangban.frame = self.imageV.frame;  //设置挡板
    
    //设置挡板
    self.dangban2.frame = CGRectMake(kUISreenWidth / 2 - kUISreenWidth *0.08, self.contentView.frame.size.height / 6, kUISreenWidth * 0.16, kUISreenWidth * 0.16);;
    self.dangban2.layer.masksToBounds = YES;
    self.dangban2.layer.cornerRadius = self.dangban2.frame.size.width / 2;
    self.imageLogo.frame = self.dangban2.frame;
    self.imageLogo.layer.masksToBounds = YES;
    self.imageLogo.layer.cornerRadius = self.imageLogo.frame.size.width / 2;
    [self.imageLogo setHighlighted:YES];
//    self.imageLogo.backgroundColor = [UIColor yellowColor];
    
    self.name.frame = CGRectMake(0, self.imageLogo.frame.size.height + self.imageLogo.frame.origin.y + 10, kUISreenWidth, 20);
    self.name.textAlignment = NSTextAlignmentCenter;
    self.name.textColor = [UIColor whiteColor];
    self.name.font = [UIFont systemFontOfSize:16 weight:0];  //weight改变字体粗细 value-1.0~1.0)
//    self.name.backgroundColor = [UIColor greenColor];
    
    self.desLabel.frame = CGRectMake(0, self.name.frame.origin.y + self.name.frame.size.height + 5, kUISreenWidth, 20);
    self.desLabel.textAlignment = NSTextAlignmentCenter;
    self.desLabel.textColor = [UIColor whiteColor];
    self.desLabel.font = [UIFont systemFontOfSize:13 weight:0];
//    self.desLabel.backgroundColor = [UIColor grayColor];
    
    
}
@end
