
//
//  BGDetailCell3.m
//  MyProject
//
//  Created by gp on 15/11/13.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "BGDetailCell3.h"
#import "BGDetailModel.h"

@interface BGDetailCell3 ()<UIWebViewDelegate>

@property (nonatomic,assign)BOOL isSuccess;

@end

@implementation BGDetailCell3

-(void)dealloc
{
    self.web.delegate = nil;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.web = [[UIWebView alloc]init];
        [self.contentView addSubview:self.web];
        self.web.scrollView.scrollEnabled = NO;
        //wenView自适应屏幕
//        self.web.scalesPageToFit = YES;
//        self.web.backgroundColor = [UIColor clearColor];
//        self.web.opaque = NO;
        //**
       // self.web.delegate = self;
    }
    return self;
    
}
//***
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    NSLog(@"webView加载%@",error);
}


-(void)setGift:(BGDetailModel *)gift
{
    _gift = gift;
    if (_gift.detail_html != nil && self.isSuccess == NO) {
    NSString *str1 = [NSString stringWithFormat:@"<head><style>img{width:%fpx !important;}</style></head>%@",self.bounds.size.width,_gift.detail_html];
    [self.web loadHTMLString:str1 baseURL:nil];
//        [self.web loadHTMLString:_gift.detail_html baseURL:nil];
        self.isSuccess = YES;
    }
    
}


- (void)layoutSubviews {
    [super layoutSubviews];
    self.web.frame = CGRectMake(0, 0, self.contentView.frame.size.width, self.contentView.frame.size.height);
    
}
@end
