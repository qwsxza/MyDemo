//
//  BGDetailCell2.h
//  MyProject
//
//  Created by gp on 15/11/13.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BGDetailModel;
@interface BGDetailCell2 : UITableViewCell

@property (nonatomic,strong) BGDetailModel *gift;


@end
