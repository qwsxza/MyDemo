//
//  TaketurnCell.h
//  MyProject
//
//  Created by gp on 15/11/6.
//  Copyright © 2015年 gp. All rights reserved.
//


//轮播图加button的cell

#import <UIKit/UIKit.h>

@interface TaketurnCell : UITableViewCell

@property (nonatomic,strong) NSMutableArray *array;
@property (nonatomic,copy)void (^imageVClick)(NSString *ID);


@end
