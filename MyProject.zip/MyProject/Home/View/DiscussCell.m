//
//  DiscussCell.m
//  MyProject
//
//  Created by gp on 15/11/13.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "DiscussCell.h"
#import "EveryDiscussCell.h"
#import "DiscussModel.h"

#define kUIScreenWidth [UIScreen mainScreen].bounds.size.width
#define kUIScreenHeight [UIScreen mainScreen].bounds.size.height

@interface DiscussCell ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong)UIImageView *imageV;
@property (nonatomic,strong)UILabel *label;

@end

@implementation DiscussCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.tableView = [[UITableView alloc]init];
        [self.contentView addSubview:self.tableView];
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
//        self.tableView.rowHeight = ;
        self.tableView.rowHeight = 200;
        self.tableView.scrollEnabled = NO;
        
        //表尾视图  去除没有被赋值的cell的单元格分割线***
        UIView *myView = [[UIView alloc]init];
        self.tableView.tableFooterView = myView;
        
        //
        self.imageV = [[UIImageView alloc]init];
        self.label = [[UILabel alloc]init];
    }
    return self;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:NSFontAttributeName,[UIFont systemFontOfSize:14], nil];
    DiscussModel *discuss = self.array[indexPath.row];
    CGRect rect = [discuss.content boundingRectWithSize:CGSizeMake(kUIScreenWidth - kUIScreenWidth / 10 - 25, 1000) options:(NSStringDrawingUsesLineFragmentOrigin) attributes:dic context:nil];
    
    return kUIScreenWidth * 20 / 375 + 30 + rect.size.height;
    
}

-(void)setArray:(NSMutableArray *)array
{
    _array = array;
    if (_array.count == 0) {
        self.imageV.image = [UIImage imageNamed:@"暂无评论"];
        [self.contentView addSubview:self.imageV];
        self.label.text = @"目前还没有评论哦";
        self.label.textAlignment = NSTextAlignmentCenter;
        self.label.textColor = [UIColor grayColor];
        self.label.font = [UIFont systemFontOfSize:13 weight:0];
        [self.contentView addSubview:self.label];
    }
    [self.tableView reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.array.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    EveryDiscussCell *cell = [tableView dequeueReusableCellWithIdentifier:@"everyDiscuss"];
    if (!cell) {
        cell = [[EveryDiscussCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"everyDiscuss"];
    }
    DiscussModel *discuss = [[DiscussModel alloc]init];
    discuss = self.array[indexPath.row];
    cell.discuss = discuss;
    return cell;
}
- (void)layoutSubviews
{
    [super layoutSubviews];
    self.tableView.frame = CGRectMake(0, 0, kUIScreenWidth, self.contentView.frame.size.height);
//    self.tableView.backgroundColor = [UIColor redColor];
    self.imageV.frame = CGRectMake(self.contentView.frame.size.width / 2 - kUIScreenWidth / 16, self.contentView.frame.size.height / 2 - kUIScreenWidth / 8, kUIScreenWidth / 8, kUIScreenWidth / 8);
    
    self.label.frame = CGRectMake(0, self.imageV.frame.origin.y + self.imageV.frame.size.height + 10, kUIScreenWidth, kUIScreenWidth * 20 / 375);
}

@end
