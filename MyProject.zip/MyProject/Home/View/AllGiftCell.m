


//
//  AllGiftCell.m
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "AllGiftCell.h"
#import "GiftItemCell.h"
#import "AllGiftModel.h"
#define kUIScreenWidth [UIScreen mainScreen].bounds.size.width
#define kSpacing 6
@interface AllGiftCell ()<UICollectionViewDataSource,UICollectionViewDelegate>

@property (nonatomic,strong)UICollectionView *collectionV;
@property (nonatomic,strong)UICollectionViewFlowLayout *layout;

@end

@implementation AllGiftCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.layout = [[UICollectionViewFlowLayout alloc]init];
        
        self.collectionV = [[UICollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:self.layout];
        [self.contentView addSubview:self.collectionV];
        
        self.collectionV.delegate = self;
        self.collectionV.dataSource = self;
        self.collectionV.backgroundColor = [UIColor clearColor];
        //不能翻转
        self.collectionV.scrollEnabled = NO;
        
        [self.collectionV registerClass:[GiftItemCell class] forCellWithReuseIdentifier:@"item"];
    }
    return self;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    AllGiftModel *gift = self.array[indexPath.item];
    self.toDetailViewController(gift.ID);
}

-(void)setArray:(NSMutableArray *)array
{
    _array = array;
    [self.collectionV reloadData];
}
-(void)layoutSubviews
{
    [super layoutSubviews];
    self.collectionV.frame = CGRectMake(kUIScreenWidth / 60, kUIScreenWidth / 60, kUIScreenWidth - kUIScreenWidth/30 , self.contentView.frame.size.height - kUIScreenWidth/60);
    
    self.layout.itemSize = CGSizeMake((self.collectionV.frame.size.width - kSpacing)/2, (self.collectionV.frame.size.width - kSpacing) / 2 + kUIScreenWidth * 7 / 50 + 5);
    self.layout.minimumLineSpacing = kUIScreenWidth/60;
    self.layout.minimumInteritemSpacing = 3;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.array.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    GiftItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"item" forIndexPath:indexPath];
    cell.backgroundColor = [UIColor whiteColor];
    AllGiftModel *gift = [[AllGiftModel alloc]init];
    gift = self.array[indexPath.row];
    cell.gift = gift;
    return cell;
}

@end
