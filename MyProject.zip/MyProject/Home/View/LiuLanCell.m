


//
//  LiuLanCell.m
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "LiuLanCell.h"
#import "BGDetailModel.h"
#import "UIImageView+WebCache.h"

#define kUIScreenWidth [UIScreen mainScreen].bounds.size.width
#define kUIScreenHeight [UIScreen mainScreen].bounds.size.height

@interface LiuLanCell ()<UIScrollViewDelegate>

@property (nonatomic,strong)UIScrollView *imageScroll;
@property (nonatomic,strong)UIPageControl *page;
@property (nonatomic,strong)UILabel *danbang;

@end

@implementation LiuLanCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.imageScroll = [[UIScrollView alloc]init];
        [self.contentView addSubview:self.imageScroll];
        self.imageScroll.pagingEnabled = YES;
        self.imageScroll.delegate = self;
        self.imageScroll.showsHorizontalScrollIndicator = NO;
        
        self.danbang = [[UILabel alloc]init];
        [self.contentView addSubview:self.danbang];
        
        self.page = [[UIPageControl alloc]init];
        [self.contentView addSubview:self.page];
        
    }
    return self;
}

-(void)setGift:(BGDetailModel *)gift
{
    _gift = gift;
    if (_gift.image_urls.count > 1) {
        self.page.numberOfPages = _gift.image_urls.count;
        [self set_upImageView];
    }else
    {
        UIImageView *imageV = [[UIImageView alloc]initWithFrame:(CGRectMake(0, 0, self.imageScroll.frame.size.width, self.imageScroll.frame.size.height))];
        [imageV sd_setImageWithURL:[NSURL URLWithString:_gift.image_urls[0]]];
        [self.imageScroll addSubview:imageV];
    }
}
//创建浏览图
- (void)set_upImageView
{
    CGFloat width = self.imageScroll.frame.size.width;
    CGFloat height = self.imageScroll.frame.size.height;
    self.imageScroll.contentSize = CGSizeMake((self.gift.image_urls.count + 1)*width, 0);
    for (int i = 0; i < self.gift.image_urls.count + 1; i++) {
        UIImageView *imageV = [[UIImageView alloc]initWithFrame:(CGRectMake(i * width, 0, width, height))];
        if (i == self.gift.image_urls.count) {
            [imageV sd_setImageWithURL:[NSURL URLWithString:self.gift.image_urls[0]]];
        }
        else{
            [imageV sd_setImageWithURL:[NSURL URLWithString:self.gift.image_urls[i]]];
        }
        [self.imageScroll addSubview:imageV];
    }
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat width = self.imageScroll.frame.size.width;
    CGPoint offset = self.imageScroll.contentOffset;
    NSInteger i = offset.x / width;
    if (i == self.gift.image_urls.count) {
        [self.imageScroll setContentOffset:CGPointZero animated:NO];
        self.page.currentPage = 0;
    }else {
    self.page.currentPage = i;
    }
}
-(void)layoutSubviews
{
    [super layoutSubviews];
    self.imageScroll.frame = CGRectMake(0, 0, self.contentView.frame.size.width, self.contentView.frame.size.height);
//    self.imageScroll.backgroundColor = [UIColor redColor];

    self.page.frame = CGRectMake(self.contentView.frame.size.width / 3, self.contentView.frame.size.height - kUIScreenWidth * 40 / 375, self.contentView.frame.size.width / 3, kUIScreenWidth * 40 / 375);
//    self.page.backgroundColor = [UIColor blackColor];
    
    self.danbang.frame = CGRectMake(0, 0, kUIScreenWidth, self.contentView.frame.size.height);
    self.danbang.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.05];

    
    
}

@end
