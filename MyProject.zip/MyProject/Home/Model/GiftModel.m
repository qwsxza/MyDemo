
//
//  GiftModel.m
//  MyProject
//
//  Created by gp on 15/11/6.
//  Copyright © 2015年 . Agpll rights reserved.
//

#import "GiftModel.h"

@implementation GiftModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if ([key isEqualToString:@"id"]) {
        self.Id = value;
    }
    if ([key isEqualToString:@"template"]) {
        self.Template = value;
    }
}

@end
