//
//  BrandModel.h
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BrandModel : NSObject

@property (nonatomic,strong) NSString *cover_image_url;
@property (nonatomic,strong) NSString *created_at;
@property (nonatomic,strong) NSString *desc;
@property (nonatomic,strong) NSString *icon_url;  //小logo
@property (nonatomic,strong) NSString *Id;
@property (nonatomic,strong) NSArray *image_urls;
@property (nonatomic,strong) NSString *intro_html;
@property (nonatomic,strong) NSString *items_count;
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *status;
@property (nonatomic,strong) NSString *updated_at;

@end
