//
//  TitleModel.m
//  MyProject
//
//  Created by gp on 15/11/5.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "TitleModel.h"

@implementation TitleModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if ([key isEqualToString:@"id"]) {
        self.Id = value;
    }
}

@end
