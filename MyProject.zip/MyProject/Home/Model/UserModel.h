//
//  UserModel.h
//  MyProject
//
//  Created by gp on 15/11/13.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserModel : NSObject

@property (nonatomic,strong) NSString *avatar_url;
@property (nonatomic,strong) NSString *guest_uuid;
@property (nonatomic,strong) NSString *can_mobile_login;
@property (nonatomic,strong) NSString *Id;
@property (nonatomic,strong) NSString *nickname;
@property (nonatomic,strong) NSString *role;

-(instancetype)initWithDictionary:(NSDictionary *)dictionary;


@end
