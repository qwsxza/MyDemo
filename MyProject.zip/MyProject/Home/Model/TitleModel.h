//
//  TitleModel.h
//  MyProject
//
//  Created by gp on 15/11/5.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TitleModel : NSObject

@property (nonatomic,strong) NSString *editable;
@property (nonatomic,strong) NSString *Id;
@property (nonatomic,strong) NSString *name;



@end
