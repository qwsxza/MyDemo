

//
//  DiscussModel.m
//  MyProject
//
//  Created by gp on 15/11/13.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "DiscussModel.h"
#import "UserModel.h"

@implementation DiscussModel

-(void)setValue:(id)value forKey:(NSString *)key
{
    [super setValue:value forKey:key];
    if ([key isEqualToString:@"user"]) {
        self.user = [[UserModel alloc] initWithDictionary:value];
    }
    
}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
