
//
//  BrandModel.m
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "BrandModel.h"

@implementation BrandModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if ([key isEqualToString:@"id"]) {
        self.Id = value;
    }
}
-(void)setNilValueForKey:(NSString *)key {}
@end
