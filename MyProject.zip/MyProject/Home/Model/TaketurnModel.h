//
//  TaketurnModel.h
//  MyProject
//
//  Created by gp on 15/11/6.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TaketurnModel : NSObject

@property (nonatomic,strong) NSString *channel;
@property (nonatomic,strong) NSString *Id;
@property (nonatomic,strong) NSString *image_url;
@property (nonatomic,strong) NSString *order;
@property (nonatomic,strong) NSString *status;
@property (nonatomic,strong) NSString *target;
@property (nonatomic,strong) NSString *target_id;
@property (nonatomic,strong) NSString *target_url;
@property (nonatomic,strong) NSString *type;


@end
