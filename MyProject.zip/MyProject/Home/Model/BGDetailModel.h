//
//  BGDetailModel.h
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BGDetailModel : NSObject

@property (nonatomic,strong) NSString *brand_id;
@property (nonatomic,strong) NSString *brand_order;
@property (nonatomic,strong) NSString *category_id;
@property (nonatomic,strong) NSString *comments_count;
@property (nonatomic,strong) NSString *cover_image_url;
@property (nonatomic,strong) NSString *created_at;
@property (nonatomic,strong) NSString *Description;
@property (nonatomic,strong) NSString *detail_html;
@property (nonatomic,strong) NSString *editor_id;
@property (nonatomic,strong) NSString *favorited;
@property (nonatomic,strong) NSString *favorites_count;
@property (nonatomic,strong) NSString *ID;
@property (nonatomic,strong) NSArray *image_urls;
@property (nonatomic,strong) NSString *liked;
@property (nonatomic,strong) NSString *likes_count;
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSArray *post_ids;
@property (nonatomic,strong) NSString *price;
@property (nonatomic,strong) NSString *purchase_id;
@property (nonatomic,strong) NSString *purchase_status;
@property (nonatomic,strong) NSString *purchase_type;
@property (nonatomic,strong) NSString *purchase_url;
@property (nonatomic,strong) NSString *shares_count;
@property (nonatomic,strong) NSString *source;
@property (nonatomic,strong) NSString *subcategory_id;
@property (nonatomic,strong) NSString *updated_at;
@property (nonatomic,strong) NSString *url;

@end
