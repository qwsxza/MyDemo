


//
//  GiftDetailModel.m
//  MyProject
//
//  Created by gp on 15/11/7.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "GiftDetailModel.h"

@implementation GiftDetailModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if ([key isEqualToString:@"id"]) {
        self.ID = value;
    }
    if ([key isEqualToString:@"template"]) {
        self.Template = value;
    }
}

@end
