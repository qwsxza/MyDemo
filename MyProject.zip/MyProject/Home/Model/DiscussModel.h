//
//  DiscussModel.h
//  MyProject
//
//  Created by gp on 15/11/13.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <Foundation/Foundation.h>
@class UserModel;

@interface DiscussModel : NSObject

@property (nonatomic,strong) NSString *content;
@property (nonatomic,strong) NSString *created_at;
@property (nonatomic,strong) NSString *item_id;
@property (nonatomic,strong) NSString *reply_to_id;
@property (nonatomic,strong) NSString *show;
@property (nonatomic,strong) NSString *status;
@property (nonatomic,strong) UserModel *user;



@end
