//
//  CategoryCell.m
//  MyProject
//
//  Created by M-coppco on 15/11/6.
//  Copyright © 2015年 . All rights reserved.
//

#import "CategoryTCell.h"
#import "CategoryCCell.h"  //集合视图cell
#import "Channel.h"  //model


@interface CategoryTCell ()<UICollectionViewDelegate, UICollectionViewDataSource>
@property (nonatomic, strong)UICollectionView *collectionView;  //集合视图
@property (nonatomic, strong)UICollectionViewFlowLayout *layout;  //布局样式
@end

@implementation CategoryTCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        //布局对象样式
        _layout = [[UICollectionViewFlowLayout alloc]init];
        
        
        self.collectionView = [[UICollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:_layout];
        
        self.collectionView.delegate = self;
        self.collectionView.dataSource = self;
        
        //注册单元格
        [self.collectionView registerClass:[CategoryCCell class] forCellWithReuseIdentifier:@"CategoryCCell"];
        [self.contentView addSubview:self.collectionView];
        self.collectionView.backgroundColor = [UIColor whiteColor];
        
        self.collectionView.scrollEnabled = NO;//设置集合视图不能滑动
        //设置单元格不能被选中
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return  self;
}
-(void)layoutSubviews {
    [super layoutSubviews];
    _layout.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
    _layout.itemSize = CGSizeMake(self.contentView.frame.size.width / 5, self.contentView.frame.size.width / 5 + 30);
    self.collectionView.frame = self.contentView.bounds;
}
#pragma mark UICollectionViewDategory
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.modelArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    CategoryCCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"CategoryCCell" forIndexPath:indexPath];
    cell.channel = self.modelArray[indexPath.item];
    
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    Channel *channel = self.modelArray[indexPath.item];
    self.changeBlock(channel.channelId, channel.name);
}
- (void)awakeFromNib {
    // Initialization code
}
#pragma mark model数组setter方法
-(void)setModelArray:(NSMutableArray *)modelArray {
    _modelArray = modelArray;
    [self.collectionView reloadData];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
