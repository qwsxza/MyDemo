//
//  MoreDayCell.h
//  MyProject
//
//  Created by M-coppco on 15/11/14.
//  Copyright © 2015年 . All rights reserved.
//

#import <UIKit/UIKit.h>
@class FutureWeather;
@interface MoreDayCell : UITableViewCell
@property (nonatomic, strong)FutureWeather *futureWeather;
@end
