//
//  ZhiShuCell.h
//  MyProject
//
//  Created by M-coppco on 15/11/14.
//  Copyright © 2015年 . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZhiShuCell : UITableViewCell
@property (nonatomic, strong)NSMutableArray *zhiShuArray;  //指数数组
@end
