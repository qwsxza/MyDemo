//
//  SubjectCell.m
//  MyProject
//
//  Created by M-coppco on 15/11/5.
//  Copyright © 2015年 All rights reserved.
//

#import "SubjectCell.h"
#import "UIButton+WebCache.h"  //异步图片
#import "UIImageView+WebCache.h"
#import "UIColor+AddColor.h"
#import "Subject.h"  //model
#define KLeft 10
#define KTop 10

@interface SubjectCell ()<UIScrollViewDelegate>
@property (nonatomic, strong)UIScrollView *scrollView;
@property (nonatomic, strong)UIPageControl *page;

@property (nonatomic, strong)NSTimer *timer;
@end

@implementation SubjectCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
 
        self.scrollView = [[UIScrollView alloc]init];
        self.scrollView.pagingEnabled = YES;
        self.scrollView.delegate = self;
        
        self.scrollView.showsHorizontalScrollIndicator = NO;
        [self.contentView addSubview:self.scrollView];
        
        self.page = [[UIPageControl alloc]init];
        
        self.page.currentPageIndicatorTintColor = [UIColor redColor];//当前选中颜色
        self.page.pageIndicatorTintColor = [UIColor yellowColor];//填充色
        [self.contentView addSubview:self.page];
        self.scrollView.backgroundColor = [UIColor jinjuse];

        //设置单元格不能被选中
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
    }
    return self;
}

-(void)layoutSubviews {
    [super layoutSubviews];

    self.scrollView.frame = self.contentView.bounds;
    self.page.frame = CGRectMake(0, self.contentView.frame.size.height / 6 * 5, self.contentView.frame.size.width, 20);
    
}
#pragma mark setter方法
-(void)setSubjectArray:(NSMutableArray *)subjectArray {
    _subjectArray = subjectArray;
    
    self.page.numberOfPages = subjectArray.count;
    self.page.currentPage = 0;
    self.scrollView.contentSize = CGSizeMake(self.scrollView.frame.size.width * (subjectArray.count + 1), 0);
    self.scrollView.contentOffset = CGPointMake(self.scrollView.frame.size.width, 0);

   self.scrollView.backgroundColor = [UIColor clearColor];
    if (subjectArray.count != 0) {
        for (int i = 0; i <= subjectArray.count; i++) {
            Subject *subject = i == 0 ? subjectArray[subjectArray.count - 1] : subjectArray[i - 1];
            
            UIImageView *imageV = [[UIImageView alloc] initWithFrame:CGRectMake(KLeft + self.scrollView.frame.size.width * i, KTop, self.contentView.bounds.size.width - 2 * KLeft, self.contentView.bounds.size.height - 2 * KTop)];
            imageV.layer.masksToBounds = YES;
            imageV.layer.cornerRadius = 20;
            [imageV sd_setImageWithURL:[NSURL URLWithString:subject.banner_image_url] placeholderImage:nil];
            [self.scrollView addSubview:imageV];
            
            UIButton *button = [UIButton buttonWithType:(UIButtonTypeCustom)];
            button.frame = imageV.frame;
            button.tag = i + 9000;
            button.backgroundColor = [UIColor clearColor];
            [button addTarget:self action:@selector(click:) forControlEvents:(UIControlEventTouchUpInside)];
            [self.scrollView addSubview:button];
          
        }
        //定时器
        
        [self addTimer];
    }
}
#pragma mark - 定时器处理
- (void)addTimer
{
    [self removeCurrentTimeTimer];

    self.timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(autoToPlay:) userInfo:nil repeats:YES];
}

- (void)removeCurrentTimeTimer
{
    [self.timer invalidate];
    self.timer = nil;
}
#pragma mark 设置scrollView动画效果
- (void)setScrollViewAnimated {
    CATransition *transition = [CATransition animation];
    transition.type = @"cube";
    transition.subtype = kCATransitionFromTop;
    transition.duration = 1;
    [self.scrollView.layer addAnimation:transition forKey:@"立方体效果"];
}
#pragma mark timer方法
- (void)autoToPlay:(NSTimer *)timer {
    CGFloat contentX = self.scrollView.contentOffset.x;
    CGFloat width = self.scrollView.frame.size.width;
    NSInteger i = self.subjectArray.count;
    if (contentX == width * i) {
        [self setScrollViewAnimated];
        [self.scrollView setContentOffset:CGPointZero animated:NO];
        [self.scrollView setContentOffset:CGPointMake(width, 0) animated:NO];
    } else {
        [self setScrollViewAnimated];
        [self.scrollView setContentOffset:CGPointMake(contentX + width, 0) animated:NO];
    }
}
#pragma mark button点击方法
- (void)click:(UIButton *)button {
    Subject *subject = button.tag - 9000 == 0 ? self.subjectArray[self.subjectArray.count - 1] : self.subjectArray[button.tag - 9000 - 1];
  self.changeBlock(subject.subjectId, subject.title);
}
- (void)awakeFromNib {
    // Initialization code
}
#pragma mark UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    CGFloat width = self.scrollView.frame.size.width;
    CGFloat contentX = scrollView.contentOffset.x;
    
    //添加判断 如果滚到最右边
    if (contentX > width * self.subjectArray.count) {
        //重新设置偏移量
        [scrollView setContentOffset:(CGPointZero) animated:NO];
    }
    if (contentX < 0 ) {
        [scrollView setContentOffset:CGPointMake(width * self.subjectArray.count, 0) animated:NO];
    }
    
    //设置page的当前页面
    if (contentX / width == 0) {
        self.page.currentPage = self.page.numberOfPages - 1;
    } else {
        self.page.currentPage = contentX / width - 1;
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
