//
//  CategoryCCell.m
//  MyProject
//
//  Created by M-coppco on 15/11/6.
//  Copyright © 2015年 . All rights reserved.
//

#import "CategoryCCell.h"
#import "Channel.h"  
#import "SubCategory.h"
#import "UIImageView+WebCache.h"
#import "UIColor+AddColor.h"

@interface CategoryCCell ()
@property (nonatomic, strong)UIImageView *imageV;
@property (nonatomic, strong)UILabel *nameL;
@end

@implementation CategoryCCell

-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.imageV  = [[UIImageView alloc]init];
        self.nameL = [[UILabel alloc] init];
        
        
        self.nameL.textColor = [UIColor jinjuse];
        self.nameL.font = [UIFont systemFontOfSize:15 weight:1];
        self.nameL.textAlignment = NSTextAlignmentCenter;
        self.nameL.numberOfLines = 0;
        
        [self.contentView addSubview:self.imageV];
        [self.contentView addSubview:self.nameL];
        
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

-(void)layoutSubviews {
    [super layoutSubviews];
    self.imageV.frame = CGRectMake(0, 0, self.contentView.frame.size.width, self.contentView.frame.size.width);
    
    self.nameL.frame = CGRectMake(0, self.imageV.frame.size.height, self.contentView.frame.size.width, self.contentView.frame.size.height - self.imageV.frame.size.height);
}

#pragma mark model的setter方法
-(void)setChannel:(Channel *)channel {
    _channel = channel;
    [self.imageV sd_setImageWithURL:[NSURL URLWithString:channel.icon_url] placeholderImage:nil];
    self.nameL.text = channel.name;
}
-(void)setSubCategory:(SubCategory *)subCategory {
    _subCategory = subCategory;
    [self.imageV sd_setImageWithURL:[NSURL URLWithString:subCategory.icon_url] placeholderImage:nil];
    self.nameL.text = subCategory.name;
    
}
@end
