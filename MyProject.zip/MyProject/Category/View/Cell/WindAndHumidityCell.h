//
//  WindAndHumidityCell.h
//  MyProject
//
//  Created by M-coppco on 15/11/16.
//  Copyright © 2015年 . All rights reserved.
//

#import <UIKit/UIKit.h>
@class WindAndHumidity;
@interface WindAndHumidityCell : UITableViewCell
@property (nonatomic, strong)WindAndHumidity *windAndHumidity;  //model
@end
