//
//  LeftCell.m
//  MyProject
//
//  Created by M-coppco on 15/11/7.
//  Copyright © 2015年 . All rights reserved.
//

#import "RightCell.h"
#import "CategoryCCell.h"
#import "SubCategory.h"
#import "HotViewController.h"  //跳转
#import "CategoryListController.h"  //主页面

@interface RightCell ()<UICollectionViewDelegate, UICollectionViewDataSource>
@property (nonatomic, strong)UICollectionViewFlowLayout *layout;
@property (nonatomic, strong)UICollectionView *collectionView;
@end

@implementation RightCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        //布局对象样式
        _layout = [[UICollectionViewFlowLayout alloc]init];
        
        
        self.collectionView = [[UICollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:_layout];
        
        self.collectionView.delegate = self;
        self.collectionView.dataSource = self;
        
        //注册单元格
        [self.collectionView registerClass:[CategoryCCell class] forCellWithReuseIdentifier:@"CategoryCCell1"];
        [self.contentView addSubview:self.collectionView];
    
        self.collectionView.backgroundColor = [UIColor whiteColor];
        self.collectionView.scrollEnabled = NO;//设置集合视图不能滑动
      
        //设置单元格不能被选中
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    return self;
}
-(void)layoutSubviews {
    [super layoutSubviews];
    self.layout.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
    self.layout.itemSize = CGSizeMake(self.contentView.frame.size.width / 3.8, self.contentView.frame.size.width / 3.8 + 30);
    self.collectionView.frame = self.contentView.bounds;
}
- (void)awakeFromNib {
    // Initialization code
}
#pragma mark UICollectionViewDategory
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.modelArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    CategoryCCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"CategoryCCell1" forIndexPath:indexPath];
    cell.subCategory = self.modelArray[indexPath.item];
    return cell;
}
-(void)setModelArray:(NSMutableArray *)modelArray {
    if (_modelArray != modelArray) {
        _modelArray = modelArray;
        
        [self.collectionView reloadData];
    }
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    HotViewController *hotVC = [[HotViewController alloc] init];
    hotVC.subCategory = self.modelArray[indexPath.item];
    UIViewController *VC = [self viewController];
    [VC.navigationController pushViewController:hotVC animated:YES];
    
}

#pragma mark 在view中获取到controller
- (UIViewController*)viewController
{
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController*)nextResponder;
        }
    }
    return nil;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
