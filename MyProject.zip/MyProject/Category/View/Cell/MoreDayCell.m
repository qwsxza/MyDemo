//
//  MoreDayCell.m
//  MyProject
//
//  Created by M-coppco on 15/11/14.
//  Copyright © 2015年 . All rights reserved.
//

#import "MoreDayCell.h"
#import "FutureWeather.h"  //model
#import "UIImageView+WebCache.h"

#define kLeft 10
#define kTop 5
#define KH 10
#define kWidth self.contentView.bounds.size.width / 5
#define kHeight self.contentView.bounds.size.height / 2
@interface MoreDayCell ()
@property (nonatomic, strong)UILabel *dateName;
@property (nonatomic, strong)UILabel *weekName;
@property (nonatomic, strong)UILabel *statesName;
@property (nonatomic, strong)UIImageView *weatherImageV;
@property (nonatomic, strong)UILabel *degreesL;
@property (nonatomic, strong)UILabel *windL;
@property (nonatomic, strong)UILabel *windNumL;
@property (nonatomic, strong)UIImageView *windImageV;

//@property (nonatomic, strong)NSTimer *timer;
@end

@implementation MoreDayCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.dateName = [[UILabel alloc] init];
        self.weekName = [[UILabel alloc] init];
        self.weatherImageV = [[UIImageView alloc] init];
        self.statesName = [[UILabel alloc] init];
        self.degreesL = [[UILabel alloc] init];
        self.windL = [[UILabel alloc] init];
        self.windNumL = [[UILabel alloc] init];
        self.windImageV = [[UIImageView alloc] init];
        self.windImageV.image = [UIImage imageNamed:@"FS"];
        self.windImageV.contentMode = UIViewContentModeScaleAspectFill;
        
        self.dateName.textAlignment = NSTextAlignmentCenter;
        self.weekName.textAlignment = NSTextAlignmentCenter;
        self.statesName.textAlignment = NSTextAlignmentCenter;
        self.degreesL.textAlignment = NSTextAlignmentCenter;
        self.windL.textAlignment = NSTextAlignmentCenter;
        self.windNumL.textAlignment = NSTextAlignmentCenter;
        
        self.dateName.textColor = [UIColor whiteColor];
        self.weekName.textColor = [UIColor whiteColor];
        self.statesName.textColor = [UIColor whiteColor];
        self.degreesL.textColor = [UIColor whiteColor];
        self.windL.textColor = [UIColor whiteColor];
        self.windNumL.textColor = [UIColor whiteColor];
        
        if ([UIScreen mainScreen].bounds.size.width == 320) {
            self.degreesL.font = [UIFont systemFontOfSize:13 weight:1];
        } else if ([UIScreen mainScreen].bounds.size.width == 375) {
            self.degreesL.font = [UIFont systemFontOfSize:14 weight:1];
        } else if ([UIScreen mainScreen].bounds.size.width == 414) {
            self.degreesL.font = [UIFont systemFontOfSize:16 weight:1];
        }
        
        [self.contentView addSubview:self.dateName];
        [self.contentView addSubview:self.weekName];
        [self.contentView addSubview:self.weatherImageV];
        [self.contentView addSubview:self.statesName];
        [self.contentView addSubview:self.degreesL];
        [self.contentView addSubview:self.windL];
        [self.contentView addSubview:self.windNumL];
        
        //self.timer = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(zhuan:) userInfo:nil repeats:YES];
        
//        [self zhuan:nil];
        
        [self.contentView addSubview:self.windImageV];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}

-(void)layoutSubviews {
    [super layoutSubviews];
    //第一列
    self.dateName.frame = CGRectMake(0, 0, kWidth, kHeight);
    self.weekName.frame = CGRectMake(0, kHeight, kWidth, kHeight);
    
    //第二列图标
    self.weatherImageV.frame = CGRectMake(kWidth + kWidth * 0.1, kWidth * 0.1, kWidth * 0.8, kWidth * 0.8);
    
    //第三列
    self.statesName.frame = CGRectMake(kWidth * 2, 0, kWidth, kHeight);
    self.degreesL.frame = CGRectMake(kWidth * 2, kHeight, kWidth, kHeight);
    //第四列
    self.windImageV.frame = CGRectMake(kWidth * 3 + kWidth * 0.2, kWidth * 0.2, kWidth * 0.6, kWidth * 0.6);
    
    //第五列
    self.windL.frame = CGRectMake(kWidth * 4, 0, kWidth, kHeight);
    self.windNumL.frame = CGRectMake(kWidth * 4, kHeight, kWidth, kHeight);
    
}
-(void)setFutureWeather:(FutureWeather *)futureWeather {
    _futureWeather = futureWeather;
    
    //给内部空间赋值
    self.dateName.text = [futureWeather.date substringFromIndex:5];
    self.weekName.text = futureWeather.dateName;
    self.statesName.text = futureWeather.name;

    self.degreesL.text = [NSString stringWithFormat:@"%@/%@°C", futureWeather.low, futureWeather.height];
    self.windL.text = futureWeather.direction;
    self.windNumL.text = futureWeather.grade;
    

    //把汉字转换为拼音  去掉中间的空格 再用到截取字符串
    NSString *mImageUrl = [NSString stringWithFormat:@"http://bcs.91.com/rbpiczy/weather/weatherIcon/%@.png", [[[[self backPinYin:self.futureWeather.name] componentsSeparatedByString:@"dao"] lastObject] stringByReplacingOccurrencesOfString:@" " withString:@""]];
    [self.weatherImageV sd_setImageWithURL:[NSURL URLWithString:mImageUrl] placeholderImage:nil];
    
    self.weatherImageV.contentMode = UIViewContentModeScaleAspectFill;
}
- (void)zhuan:(NSTimer *)timer {
    [UIView animateWithDuration:0.01 animations:^{
        self.windImageV.transform = CGAffineTransformRotate(self.windImageV.transform, 0.05);
        
    } completion:^(BOOL finished) {
        [self zhuan:nil];
    }];
}
- (void)awakeFromNib {
    // Initialization code
}
#pragma mark 判断是否有中文
-(BOOL)IsChinese:(NSString *)str {
    for(int i=0; i< [str length];i++){
        int a = [str characterAtIndex:i];
        if( a > 0x4e00 && a < 0x9fff){  //ox4e00 - 0x9fff 这是Unicode 汉字的编码范围
            return YES;
        }
    }
    return NO;
}

#pragma mark  返回中文姓名的拼音的首字母
- (NSString *)backPinYin:(NSString *)string{
    
    //这里应该少了个安全判断  就是 如果输入的字符串就是 NSString 类型的咋办=.= 万一这是给外国人用的呢 特么的名字是字母啊
    
    if ([string characterAtIndex:0] > 0x4e00 && [string characterAtIndex:0] < 0x9fff) {
        //转化成特定格式
        CFStringRef strRef = (__bridge CFStringRef)string; //这里的__bridge 没提示 只能硬敲
        //转化成汉字
        CFMutableStringRef newString = CFStringCreateMutableCopy(NULL, 0, strRef);
        //转化成带声调的拼音
        CFStringTransform(newString, NULL, kCFStringTransformMandarinLatin, NO);
        //去掉声调的拼音
        CFStringTransform(newString, NULL, kCFStringTransformStripDiacritics, NO);
        
        //将拼音转化成NSString类型的字符串
        string = (__bridge NSString *)newString;
    }
    
    //NSString *firstChar = [[string uppercaseString] substringToIndex:1];
    return string;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
