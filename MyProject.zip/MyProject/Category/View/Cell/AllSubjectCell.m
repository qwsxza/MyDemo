//
//  AllSubjectCell.m
//  MyProject
//
//  Created by M-coppco on 15/11/7.
//  Copyright © 2015年 All rights reserved.
//

#import "AllSubjectCell.h"
#import "UIImageView+WebCache.h"
#import "Subject.h"
#define KLeft 10
#define KTop 10

@interface AllSubjectCell ()
@property (nonatomic, strong)UIImageView *imageV;
@property (nonatomic, strong)UILabel *shortName;
@property (nonatomic, strong)UILabel *midLine;
@property (nonatomic, strong)UILabel *longName;
@end

@implementation AllSubjectCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.imageV = [[UIImageView alloc] init];
        self.shortName = [[UILabel alloc] init];
        self.midLine = [[UILabel alloc] init];
        self.longName = [[UILabel alloc] init];
        
        self.imageV.layer.cornerRadius = 20;
        self.imageV.layer.masksToBounds = YES;
        
        self.shortName.textAlignment = NSTextAlignmentCenter;
        self.shortName.font = [UIFont systemFontOfSize:22 weight:1];
        self.longName.textAlignment = NSTextAlignmentCenter;
        self.midLine.textAlignment = NSTextAlignmentCenter;
        

        self.shortName.textColor = [UIColor whiteColor];
        self.midLine.textColor = [UIColor whiteColor];
        self.longName.textColor = [UIColor whiteColor];
        
        [self.contentView addSubview:self.imageV];
        [self.contentView addSubview:self.shortName];
        [self.contentView addSubview:self.midLine];
        [self.contentView addSubview:self.longName];
    }
    return self;
}

-(void)layoutSubviews {
    [super layoutSubviews];
    self.imageV.frame = CGRectMake(KLeft, KTop, self.contentView.bounds.size.width - 2 * KLeft, self.contentView.bounds.size.height - 2 * KTop);
    self.shortName.frame = CGRectMake(self.imageV.frame.origin.x, self.imageV.frame.size.height / 3, self.imageV.frame.size.width, 30);
    self.midLine.frame =CGRectMake(self.shortName.frame.origin.x, self.shortName.frame.size.height + self.shortName.frame.origin.y, self.shortName.frame.size.width, 5);
    self.longName.frame = CGRectMake(self.midLine.frame.origin.x, self.midLine.frame.size.height + self.midLine.frame.origin.y, self.midLine.frame.size.width, 20);
}
-(void)setSubject:(Subject *)subject {
    _subject = subject;
    
    [self.imageV sd_setImageWithURL:[NSURL URLWithString:subject.cover_image_url] placeholderImage:nil];
    self.shortName.text = subject.title;
    self.longName.text = subject.subtitle;
    self.midLine.text = @"-----------";
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
