//
//  RightCell.m
//  MyProject
//
//  Created by M-coppco on 15/11/7.
//  Copyright © 2015年 . All rights reserved.
//

#import "LeftCell.h"

@interface LeftCell ()


@end

@implementation LeftCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _leftLabel = [[UILabel alloc]init];
        
        _titleLabel = [[UILabel alloc] init];
        
        self.leftLabel.backgroundColor = [UIColor clearColor];
        self.titleLabel.textColor = [UIColor blackColor];
        self.backgroundColor = [UIColor whiteColor];
        [self.contentView addSubview:self.leftLabel];
        [self.contentView addSubview:self.titleLabel];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}
-(void)layoutSubviews {
    self.leftLabel.frame = CGRectMake(0, 0, 5, self.contentView.frame.size.height);
    self.titleLabel.frame = CGRectMake(0, 0, self.contentView.frame.size.width, self.frame.size.height);
    self.leftLabel.layer.cornerRadius = 3;
    self.leftLabel.layer.masksToBounds = YES;
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
}
-(void)setTitle:(NSString *)title {
    _title = title;
    self.titleLabel.text = title;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
