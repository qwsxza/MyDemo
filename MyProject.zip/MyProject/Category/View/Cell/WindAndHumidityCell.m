//
//  WindAndHumidityCell.m
//  MyProject
//
//  Created by M-coppco on 15/11/16.
//  Copyright © 2015年 . All rights reserved.
//

#import "WindAndHumidityCell.h"
#import "WindAndHumidity.h"
@interface WindAndHumidityCell ()
@property (nonatomic, strong)UIImageView *windImageV;
@property (nonatomic, strong)UILabel *windL;

@property (nonatomic, strong)UIImageView *humidityImageV;
@property (nonatomic, strong)UILabel *humidityL;
@end

@implementation WindAndHumidityCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.windImageV = [[UIImageView alloc] init];
        self.windL = [[UILabel alloc] init];
        
        self.humidityImageV = [[UIImageView alloc] init];
        self.humidityL = [[UILabel alloc] init];
        
    
        self.windL.textColor = [UIColor whiteColor];
        self.windL.textAlignment = NSTextAlignmentCenter;
        self.humidityL.textColor = [UIColor whiteColor];
        self.humidityL.textAlignment = NSTextAlignmentCenter;
        

        self.windImageV.image = [UIImage imageNamed:@"fengche"];
        self.humidityImageV.image = [UIImage imageNamed:@"shidu"];
        self.windImageV.contentMode = UIViewContentModeScaleAspectFill;
        self.humidityImageV.contentMode = UIViewContentModeScaleAspectFill;
        
        
        [self.contentView addSubview:self.windImageV];
        [self.contentView addSubview:self.windL];
        [self.contentView addSubview:self.humidityL];
        [self.contentView addSubview:self.humidityImageV];
        
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}
-(void)layoutSubviews {
    [super layoutSubviews];
    self.windImageV.frame = CGRectMake(self.contentView.frame.size.height * 0.175, self.contentView.frame.size.height * 0.175, self.contentView.frame.size.height * 0.7, self.contentView.frame.size.height * 0.7);
    self.windL.frame = CGRectMake(self.windImageV.frame.size.width, self.windImageV.frame.size.height / 2 - 15, self.contentView.frame.size.width / 2 - self.windImageV.frame.size.width, 30);
    self.humidityImageV.frame = CGRectMake(self.contentView.frame.size.width / 2 + self.contentView.frame.size.height * 0.175, self.contentView.frame.size.height * 0.175, self.contentView.frame.size.height * 0.7, self.contentView.frame.size.height * 0.7);
    self.humidityL.frame = CGRectMake(self.humidityImageV.frame.size.width + self.humidityImageV.frame.origin.x, self.windImageV.frame.size.height / 2 - 15, self.windL.frame.size.width, self.windL.frame.size.height);
}

-(void)setWindAndHumidity:(WindAndHumidity *)windAndHumidity {
    _windAndHumidity = windAndHumidity;
    
    self.windL.text = windAndHumidity.wind;
    self.humidityL.text = windAndHumidity.humidity;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
