//
//  RightCell.h
//  MyProject
//
//  Created by M-coppco on 15/11/7.
//  Copyright © 2015年 . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftCell : UITableViewCell
@property (nonatomic, strong, readonly)UILabel *leftLabel;
@property (nonatomic, strong, readonly)UILabel *titleLabel;
@property (nonatomic, copy)NSString *title;

@end
