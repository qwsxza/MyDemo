//
//  WeatherTopCell.h
//  MyProject
//
//  Created by M-coppco on 15/11/13.
//  Copyright © 2015年 . All rights reserved.
//

#import <UIKit/UIKit.h>
@class WeatherTop;
@interface WeatherTopCell : UITableViewCell
@property (nonatomic, strong)WeatherTop *weatherTop;
@end
