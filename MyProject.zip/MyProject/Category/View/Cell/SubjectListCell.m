//
//  SubjectListCell.m
//  MyProject
//
//  Created by M-coppco on 15/11/6.
//  Copyright © 2015年 . All rights reserved.
//

#import "SubjectListCell.h"
#import "UIImageView+WebCache.h"  //网络
#import "SubjectList.h"  //model



#define KLeft 10
#define KTop 10
#define KRandom arc4random() % 256 / 255.0

@interface SubjectListCell ()
@property (nonatomic, strong)UIImageView *bigImageView;
@property (nonatomic, strong)UILabel *titleLabel;
@property (nonatomic, strong)UIView *backView;
@property (nonatomic, strong)UIImageView *smallImageView;
@property (nonatomic, strong)UILabel *countLabel;
@property (nonatomic, strong)UILabel *timeLabel;
@end

@implementation SubjectListCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.bigImageView = [[UIImageView alloc]init];
        self.titleLabel = [[UILabel alloc]init];
        
        self.backView = [[UIView alloc] init];
        self.smallImageView = [[UIImageView alloc] init];
        self.countLabel = [[UILabel alloc]init];
        self.timeLabel = [[UILabel alloc] init];
        
        self.backView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
        self.bigImageView.layer.cornerRadius = 20;
        self.bigImageView.layer.masksToBounds = YES;

        //self.titleLabel.textColor = [UIColor colorWithRed:0.3 green:0.9 blue:0.4 alpha:1];
       
        
  
        self.titleLabel.textColor = [UIColor whiteColor];
        self.titleLabel.font = [UIFont systemFontOfSize:22 weight:1];
        self.titleLabel.numberOfLines = 0;
        
        self.timeLabel.textAlignment = NSTextAlignmentRight;
        
        self.countLabel.textColor = [UIColor whiteColor];
        self.timeLabel.textColor = [UIColor whiteColor];

        
        [self.bigImageView addSubview:self.titleLabel];
        
        [self.backView addSubview:self.smallImageView];
        [self.backView addSubview:self.countLabel];
        
        [self.bigImageView addSubview:self.backView];
        
        [self.bigImageView addSubview:self.timeLabel];
        [self.contentView addSubview:self.bigImageView];
        
        //设置单元格不能被选中
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}
-(void)layoutSubviews {
    [super layoutSubviews];
    self.bigImageView.frame = CGRectMake(KLeft, KTop, self.contentView.bounds.size.width - 2 * KLeft, self.contentView.bounds.size.height - 2 * KTop);
    self.backView.frame = CGRectMake(self.bigImageView.frame.size.width / 4 * 3 - KLeft, self.bigImageView.frame.size.height / 7 * 5, self.bigImageView.frame.size.width / 4, self.bigImageView.frame.size.height / 7);
    
    self.titleLabel.frame = CGRectMake(KLeft, KTop, self.bigImageView.frame.size.width - 2 * KLeft, self.bigImageView.frame.size.height / 8);
    [self.titleLabel sizeToFit];
    self.smallImageView.frame = CGRectMake(0, 0, self.backView.frame.size.width / 4, self.backView.frame.size.height);
    self.countLabel.frame = CGRectMake(self.smallImageView.frame.size.width, 0, self.backView.frame.size.width - self.smallImageView.frame.size.width, self.backView.frame.size.height);
    
    self.timeLabel.frame = CGRectMake(KLeft, self.bigImageView.frame.size.height / 7 * 6, self.bigImageView.frame.size.width - 2 * KLeft, self.bigImageView.frame.size.height / 7);
    self.smallImageView.image = [UIImage imageNamed:@"xin"];
}
-(void)setSubjectList:(SubjectList *)subjectList {
    _subjectList = subjectList;
    
    //给内部控件赋值
    [self.bigImageView sd_setImageWithURL:[NSURL URLWithString:subjectList.cover_image_url] placeholderImage:nil];
    self.titleLabel.text = subjectList.title;
    
    //时间戳转时间
    NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:@"yyyy.MM.dd"];
    NSDate *confromTimesp = [NSDate dateWithTimeIntervalSince1970:[subjectList.created_at longLongValue]];
    NSString *dateString = [formatter stringFromDate:confromTimesp];
    
    self.timeLabel.text = dateString;
    self.countLabel.text = subjectList.likes_count;
    
}
- (void)awakeFromNib {
    // Initialization code
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
