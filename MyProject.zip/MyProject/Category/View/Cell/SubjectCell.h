//
//  SubjectCell.h
//  MyProject
//
//  Created by M-coppco on 15/11/5.
//  Copyright © 2015年 . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubjectCell : UITableViewCell
@property (nonatomic, strong)NSMutableArray *subjectArray;  //专题model数组

@property (nonatomic, copy)void (^changeBlock)(NSString *subject, NSString *title); //点击button

@end
