//
//  CategoryCCell.h
//  MyProject
//
//  Created by M-coppco on 15/11/6.
//  Copyright © 2015年 . All rights reserved.
//

#import <UIKit/UIKit.h>
@class Channel;
@class SubCategory;
@interface CategoryCCell : UICollectionViewCell

@property (nonatomic, strong)Channel *channel;


@property (nonatomic, strong)SubCategory *subCategory;
@end
