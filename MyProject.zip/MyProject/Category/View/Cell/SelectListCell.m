//
//  SelectListCell.m
//  MyProject
//
//  Created by M-coppco on 15/11/10.
//  Copyright © 2015年 . All rights reserved.
//

#import "SelectListCell.h"
#import "UIImageView+WebCache.h"

#import "GoodsList.h"  //model
#define kLeft 5
#define kTop 5
@interface SelectListCell ()
@property (nonatomic, strong)UIImageView *imageV;
@property (nonatomic, strong)UILabel *titleL;
@property (nonatomic, strong)UILabel *priceL;
@end

@implementation SelectListCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.imageV = [[UIImageView alloc] init];
        self.titleL = [[UILabel alloc] init];
        self.priceL = [[UILabel alloc] init];
        
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.1];
        self.priceL.textAlignment = NSTextAlignmentCenter;
 
        self.titleL.textAlignment = NSTextAlignmentCenter;
        
        self.titleL.textColor = [UIColor redColor];
        self.titleL.font = [UIFont systemFontOfSize:20 weight:1];
        self.priceL.textColor = [UIColor grayColor];
        self.priceL.font = [UIFont systemFontOfSize:18 weight:1];
        
        
        [self.contentView addSubview:self.imageV];
        [self.contentView addSubview:self.titleL];
        [self.contentView addSubview:self.priceL];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}
-(void)layoutSubviews {
    [super layoutSubviews];
    self.imageV.frame = CGRectMake(kLeft, kTop, self.contentView.frame.size.width / 2, self.contentView.frame.size.width / 2);
    self.imageV.layer.cornerRadius = self.contentView.frame.size.width / 4;
    self.imageV.layer.masksToBounds = YES;
    self.titleL.frame = CGRectMake(self.imageV.frame.size.width + kLeft, self.contentView.frame.size.height /3, self.contentView.frame.size.width - 2 * kLeft - self.imageV.frame.size.width, self.contentView.frame.size.height /3);
    //
    self.titleL.numberOfLines = 0;
    [self.titleL sizeToFit];
    self.priceL.frame = CGRectMake(self.titleL.frame.origin.x, self.titleL.frame.origin.y + self.titleL.frame.size.height, self.titleL.frame.size.width , self.contentView.frame.size.height / 3);
}
#pragma mark setter方法 
-(void)setGoodsList:(GoodsList *)goodsList {
    _goodsList = goodsList;
    
    [self.imageV sd_setImageWithURL:[NSURL URLWithString:goodsList.cover_image_url] placeholderImage:nil];
    self.titleL.text = goodsList.name;
    self.priceL.text = [NSString stringWithFormat:@"￥:%@", goodsList.price];

    
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
