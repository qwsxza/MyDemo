//
//  ZhiShuCell.m
//  MyProject
//
//  Created by M-coppco on 15/11/14.
//  Copyright © 2015年 . All rights reserved.
//

#import "ZhiShuCell.h"
#import "ZhiShuCCell.h"  //集合视图cell


@interface ZhiShuCell ()<UICollectionViewDataSource, UICollectionViewDelegate>
@property (nonatomic, strong)UICollectionView *collectView;
@property (nonatomic, strong)UICollectionViewFlowLayout *layout;
@end

@implementation ZhiShuCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.layout = [[UICollectionViewFlowLayout alloc] init];
        
        self.collectView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:self.layout];
        self.collectView.delegate = self;
        self.collectView.dataSource = self;
    
        //注册单元格
        [self.collectView registerClass:[ZhiShuCCell class] forCellWithReuseIdentifier:@"ZhiShuCCell"];
        self.collectView.scrollEnabled = NO;
        [self.contentView addSubview:self.collectView];
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
        self.collectView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}
-(void)layoutSubviews {
    [super layoutSubviews];
    self.layout.itemSize = CGSizeMake(self.contentView.frame.size.width / 2 - 1, self.contentView.frame.size.width / 5);

    
    self.layout.minimumInteritemSpacing = 1;
    self.layout.minimumLineSpacing = 2;
    self.collectView.frame = self.contentView.bounds;
}
#pragma MARK UICollectionView
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.zhiShuArray.count;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    ZhiShuCCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ZhiShuCCell" forIndexPath:indexPath];
    cell.zhiShuModle = self.zhiShuArray[indexPath.item];
    return cell;
}
-(void)setZhiShuArray:(NSMutableArray *)zhiShuArray {
    _zhiShuArray = zhiShuArray;
    
    [self.collectView reloadData];
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
