//
//  WeatherTipsCell.m
//  MyProject
//
//  Created by M-coppco on 15/11/14.
//  Copyright © 2015年 . All rights reserved.
//

#import "WeatherTipsCell.h"
#define kTop 10
#define kLeft 30
#import "UIImageView+WebCache.h"
#import "WeatherTips.h"
#import "UIColor+AddColor.h"

@interface WeatherTipsCell ()
@property (nonatomic, strong)UIImageView *smallImageV;
@property (nonatomic, strong)UILabel *tipsLabel;
@property (nonatomic, strong)UILabel *timeLabel;
@end

@implementation WeatherTipsCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.smallImageV = [[UIImageView alloc] init];
        self.tipsLabel = [[UILabel alloc] init];
        self.timeLabel = [[UILabel alloc] init];
        
        self.tipsLabel.textColor = [UIColor whiteColor];
        self.timeLabel.textColor = [UIColor whiteColor];
        self.timeLabel.font = [UIFont systemFontOfSize:15 weight:1];
        
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
        [self.contentView addSubview:self.smallImageV];
        [self.contentView addSubview:self.tipsLabel];
        [self.contentView addSubview:self.timeLabel];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}
-(void)layoutSubviews {
    [super layoutSubviews];
    self.smallImageV.frame = CGRectMake(kLeft, kTop, self.contentView.frame.size.height - 2 * kTop, self.contentView.frame.size.height - 2 * kTop);
    self.tipsLabel.frame = CGRectMake(CGRectGetMaxX(self.smallImageV.frame) + 20, kTop, self.contentView.frame.size.width - CGRectGetMaxX(self.smallImageV.frame) - 30, 20);
    self.tipsLabel.numberOfLines = 0;
    [self.tipsLabel sizeToFit];
    self.timeLabel.frame = CGRectMake(self.tipsLabel.frame.origin.x, CGRectGetMaxY(self.tipsLabel.frame), self.tipsLabel.frame.size.width, 20);
    
}
-(void)setWeatherTips:(WeatherTips *)weatherTips {
    _weatherTips = weatherTips;
    [self.smallImageV sd_setImageWithURL:[NSURL URLWithString:weatherTips.take] placeholderImage:nil];
    
    NSString *string = [weatherTips.raw stringByReplacingOccurrencesOfString:@"{提醒familyName}" withString:@""];
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:[weatherTips.raw stringByReplacingOccurrencesOfString:@"{提醒familyName}" withString:@""]];
    NSRange range = [string rangeOfString:self.weatherTips.keyword];

    [str addAttribute:NSForegroundColorAttributeName value:[UIColor colorFromHexCode:self.weatherTips.color] range:range];
    //[str addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(6,12)];
    //[str addAttribute:NSForegroundColorAttributeName value:[UIColor greenColor] range:NSMakeRange(19,6)];
    [str addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Arial-BoldItalicMT" size:25] range:range];
    //[str addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"HelveticaNeue-Bold" size:30.0] range:NSMakeRange(6, 12)];
    //[str addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"Courier-BoldOblique" size:30.0] range:NSMakeRange(19, 6)];
    self.tipsLabel.attributedText = str;
    
    self.timeLabel.text = [NSString stringWithFormat:@"%@发布", [[weatherTips.expireAt componentsSeparatedByString:@" "] lastObject]];
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
