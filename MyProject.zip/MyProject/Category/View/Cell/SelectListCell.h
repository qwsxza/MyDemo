//
//  SelectListCell.h
//  MyProject
//
//  Created by M-coppco on 15/11/10.
//  Copyright © 2015年 . All rights reserved.
//

#import <UIKit/UIKit.h>
@class GoodsList;
@interface SelectListCell : UITableViewCell

@property (nonatomic, strong)GoodsList *goodsList;

@end
