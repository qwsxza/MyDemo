//
//  HistoryCityCell.h
//  MyProject
//
//  Created by M-coppco on 15/11/16.
//  Copyright © 2015年 . All rights reserved.
//

#import <UIKit/UIKit.h>
@class City1;
@interface HistoryCityCell : UICollectionViewCell
@property (nonatomic, strong)City1 *city1;
@property (nonatomic, strong)NSIndexPath *index;
@end
