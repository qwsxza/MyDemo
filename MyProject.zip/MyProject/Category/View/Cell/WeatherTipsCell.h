//
//  WeatherTipsCell.h
//  MyProject
//
//  Created by M-coppco on 15/11/14.
//  Copyright © 2015年 . All rights reserved.
//

#import <UIKit/UIKit.h>
@class WeatherTips;
@interface WeatherTipsCell : UITableViewCell
@property (nonatomic, strong)WeatherTips *weatherTips;
@end
