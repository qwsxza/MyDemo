//
//  ZhiShuCCell.m
//  MyProject
//
//  Created by M-coppco on 15/11/14.
//  Copyright © 2015年 . All rights reserved.
//

#import "ZhiShuCCell.h"
#import "ZhishuModel.h"   //model
#import "UIImageView+WebCache.h"
#import "UIColor+AddColor.h"

@interface ZhiShuCCell ()
@property (nonatomic, strong)UIImageView *imageV;
@property (nonatomic, strong)UILabel *titleL;
@property (nonatomic, strong)UILabel *detailL;
@end

@implementation ZhiShuCCell

-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.imageV = [[UIImageView alloc] init];
        self.titleL = [[UILabel alloc] init];
        self.detailL = [[UILabel alloc] init];

        self.titleL.textAlignment = NSTextAlignmentCenter;
        self.detailL.textAlignment = NSTextAlignmentCenter;
        self.titleL.textColor = [UIColor whiteColor];
        self.detailL.textColor = [UIColor whiteColor];
        self.titleL.font = [UIFont systemFontOfSize:15];
        self.detailL.font = [UIFont systemFontOfSize:15 weight:1];
        
        [self.contentView addSubview:self.imageV];
        [self.contentView addSubview:self.titleL];
        [self.contentView addSubview:self.detailL];
        
    }
    return self;
}
-(void)layoutSubviews {
    [super layoutSubviews];
    self.imageV.frame = CGRectMake(self.contentView.frame.size.height * 0.175, 1 + self.contentView.frame.size.height * 0.175, self.contentView.frame.size.height * 0.7, self.contentView.frame.size.height * 0.7);
    
    self.imageV.contentMode = UIViewContentModeScaleAspectFill;
    self.titleL.frame = CGRectMake(CGRectGetMaxX(self.imageV.frame), 0, self.contentView.frame.size.width - self.imageV.frame.size.width, self.contentView.frame.size.height / 2);
    
    self.detailL.frame = CGRectMake(CGRectGetMaxX(self.imageV.frame), self.contentView.frame.size.height / 2, self.titleL.frame.size.width, self.contentView.frame.size.height / 2);
}
-(void)setZhiShuModle:(ZhishuModel *)zhiShuModle {
    _zhiShuModle = zhiShuModle;
    [self.imageV sd_setImageWithURL:[NSURL URLWithString:zhiShuModle.icon] placeholderImage:nil];
    self.titleL.text = zhiShuModle.title;
    if (zhiShuModle.color.length != 0) {
        self.detailL.textColor = [UIColor colorFromHexCode:zhiShuModle.color];
    } else {
        self.detailL.textColor = [UIColor whiteColor];
    }
    self.detailL.text = zhiShuModle.text;
}
@end
