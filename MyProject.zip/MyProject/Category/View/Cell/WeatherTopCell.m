//
//  WeatherTopCell.m
//  MyProject
//
//  Created by M-coppco on 15/11/13.
//  Copyright © 2015年 . All rights reserved.
//

#import "WeatherTopCell.h"
#import "WeatherTop.h" //modol
#import "UIImageView+WebCache.h"
#define kLeft 10
#define kTop 50
#define kWidth 30

@interface WeatherTopCell ()
@property (nonatomic, strong)UIImageView *tianqiImageV;//空气质量
@property (nonatomic, strong)UIImageView *tianqiImageVS;
@property (nonatomic, strong)UILabel *tianqiL;

@property (nonatomic, strong)UIImageView *nowImageV;  //今天的天气图

@property (nonatomic, strong)UIImageView *warningImageV;//警告
@property (nonatomic, strong)UIImageView *warningImageVS;
@property (nonatomic, strong)UILabel *warningL;

@property (nonatomic, strong)UILabel *weatherDegrees;
@property (nonatomic, strong)UILabel *timeL;
@property (nonatomic, strong)UILabel *weatherStates;
@property (nonatomic, strong)UILabel *fabuTime;
@property (nonatomic, strong)UIView *todayView;
@property (nonatomic, strong)UIView *tomorrowView;

@property (nonatomic, strong)UILabel *tTitleLabel;
@property (nonatomic, strong)UILabel *tDegreesLabel;
@property (nonatomic, strong)UILabel *tStatesLabel;
@property (nonatomic, strong)UIImageView *tImageV;

@property (nonatomic, strong)UILabel *mTitleLabel;
@property (nonatomic, strong)UILabel *mDegreesLabel;
@property (nonatomic, strong)UILabel *mStatesLabel;
@property (nonatomic, strong)UIImageView *mImageV;
@end

@implementation WeatherTopCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.tianqiImageV = [[UIImageView alloc] init];
        self.tianqiImageVS = [[UIImageView alloc] init];
        [self.tianqiImageV addSubview:self.tianqiImageVS];
        self.tianqiL = [[UILabel alloc] init];
        
        self.nowImageV = [[UIImageView alloc] init];
        
        self.warningImageV = [[UIImageView alloc] init];
        self.warningImageVS = [[UIImageView alloc] init];
        [self.warningImageV addSubview:self.warningImageVS];
        self.warningL = [[UILabel alloc] init];
        
        self.weatherDegrees = [[UILabel alloc] init];
        self.timeL = [[UILabel alloc] init];
        self.weatherStates = [[UILabel alloc] init];
        self.fabuTime = [[UILabel alloc] init];
        self.todayView = [[UIView alloc] init];
        self.tomorrowView = [[UIView alloc] init];
        
        self.tTitleLabel = [[UILabel alloc] init];
        self.tDegreesLabel = [[UILabel alloc] init];
        self.tStatesLabel = [[UILabel alloc] init];
        self.tImageV = [[UIImageView alloc] init];
        [self.todayView addSubview:self.tStatesLabel];
        [self.todayView addSubview:self.tTitleLabel];
        [self.todayView addSubview:self.tDegreesLabel];
        [self.todayView addSubview:self.tImageV];
        
        self.mTitleLabel = [[UILabel alloc] init];
        self.mDegreesLabel = [[UILabel alloc] init];
        self.mStatesLabel = [[UILabel alloc] init];
        self.mImageV = [[UIImageView alloc] init];
        [self.tomorrowView addSubview:self.mStatesLabel];
        [self.tomorrowView addSubview:self.mTitleLabel];
        [self.tomorrowView addSubview:self.mDegreesLabel];
        [self.tomorrowView addSubview:self.mImageV];
        
    
        
        //这里需要判断手机型号
        if ([UIScreen mainScreen].bounds.size.width == 320) {
            self.weatherDegrees.font = [UIFont systemFontOfSize:55];
        } else {
            self.weatherDegrees.font = [UIFont systemFontOfSize:65];
        }
        
        self.tianqiL.textAlignment = NSTextAlignmentCenter;
        
        self.tianqiL.textColor = [UIColor whiteColor];
        self.tianqiL.font = [UIFont systemFontOfSize:17 weight:1];
        
        self.warningL.textAlignment = NSTextAlignmentCenter;
        
        self.warningL.textColor = [UIColor redColor];
        self.warningL.font = [UIFont systemFontOfSize:17 weight:1];
        
        
        self.weatherDegrees.textColor = [UIColor whiteColor];
        self.weatherStates.textColor = [UIColor whiteColor];
        self.weatherStates.font = [UIFont systemFontOfSize:18 weight:1];
        self.timeL.textColor = [UIColor whiteColor];
        self.fabuTime.textColor = [UIColor whiteColor];
        self.tDegreesLabel.textColor = [UIColor whiteColor];
        self.tTitleLabel.textColor = [UIColor whiteColor];
        self.mDegreesLabel.textColor = [UIColor whiteColor];
        self.mTitleLabel.textColor = [UIColor whiteColor];
        self.tStatesLabel.textColor = [UIColor whiteColor];
        self.mStatesLabel.textColor = [UIColor whiteColor];
        
        self.tianqiL.textAlignment = NSTextAlignmentLeft;
        self.tDegreesLabel.textAlignment = NSTextAlignmentCenter;
        self.tTitleLabel.textAlignment = NSTextAlignmentCenter;
        self.mDegreesLabel.textAlignment = NSTextAlignmentCenter;
        self.mTitleLabel.textAlignment = NSTextAlignmentCenter;
        self.weatherStates.textAlignment = NSTextAlignmentLeft;
        self.timeL.textAlignment = NSTextAlignmentLeft;
        self.fabuTime.textAlignment = NSTextAlignmentCenter;
        self.tStatesLabel.textAlignment = NSTextAlignmentCenter;
        self.mStatesLabel.textAlignment = NSTextAlignmentCenter;
        
        [self.contentView addSubview:self.tianqiImageV];
        [self.contentView addSubview:self.tianqiL];
        
        [self.contentView addSubview:self.warningImageV];
        [self.contentView addSubview:self.warningL];
        [self.contentView addSubview:self.nowImageV];
        [self.contentView addSubview:self.weatherDegrees];
        [self.contentView addSubview:self.timeL];
        [self.contentView addSubview:self.weatherStates];
        [self.contentView addSubview:self.fabuTime];
        [self.contentView addSubview:self.todayView];
        [self.contentView addSubview:self.tomorrowView];
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}

-(void)layoutSubviews {
    [super layoutSubviews];
    //空气质量
    self.tianqiImageV.frame = CGRectMake(kLeft, kTop, kWidth, kWidth);
    self.tianqiImageVS.frame = self.tianqiImageV.bounds;
    CGSize size =  CGSizeMake(1000,self.tianqiImageV.frame.size.height);
    CGRect labelrect= [[NSString stringWithFormat:@"空气质量:%@", self.weatherTop.text] boundingRectWithSize:size options:(NSStringDrawingUsesLineFragmentOrigin) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17 weight:1]} context:nil];
    
    self.tianqiL.frame = CGRectMake(CGRectGetMaxX(self.tianqiImageV.frame), self.tianqiImageV.frame.origin.y, labelrect.size.width, self.tianqiImageV.frame.size.height);
    self.tianqiL.layer.cornerRadius = 10;
    self.tianqiL.layer.masksToBounds = YES;
    
    //警告
    self.warningImageV.frame = CGRectMake(kLeft, self.tianqiImageV.frame.origin.y + 10 + self.tianqiImageV.frame.size.height, kWidth, kWidth);
    self.warningImageVS.frame = self.warningImageV.bounds;
    CGSize size1 =  CGSizeMake(1000,self.warningImageV.frame.size.height);
    CGRect labelrect1= [[NSString stringWithFormat:@"警告:%@", self.weatherTop.warningText] boundingRectWithSize:size1 options:(NSStringDrawingUsesLineFragmentOrigin) attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17 weight:1]} context:nil];
    
    self.warningL.frame = CGRectMake(CGRectGetMaxX(self.warningImageV.frame), self.warningImageV.frame.origin.y, labelrect1.size.width, self.warningImageV.frame.size.height);
    self.warningL.layer.cornerRadius = 10;
    self.warningL.layer.masksToBounds = YES;
    
    //今天天气
    self.todayView.frame = CGRectMake(0, self.contentView.frame.size.height - self.contentView.frame.size.height / 5, self.contentView.frame.size.width / 2, self.contentView.frame.size.height / 5);
    
    self.tTitleLabel.frame = CGRectMake(kLeft, kTop / 3, (self.todayView.frame.size.width - kLeft)/ 2, (self.todayView.frame.size.height - 2 * kTop /3) / 3);
    self.tDegreesLabel.frame = CGRectMake(kLeft, CGRectGetMaxY(self.tTitleLabel.frame), self.tTitleLabel.frame.size.width, self.tTitleLabel.frame.size.height);
    self.tStatesLabel.frame = CGRectMake(kLeft, CGRectGetMaxY(self.tDegreesLabel.frame), self.tTitleLabel.frame.size.width, self.tTitleLabel.frame.size.height);
    self.tImageV.frame = CGRectMake(CGRectGetMaxX(self.tTitleLabel.frame), self.tTitleLabel.frame.origin.y, (self.todayView.frame.size.width - kLeft)/ 2, self.todayView.frame.size.height - 2 * kTop / 3);
    
    
    
    //明日天气
    self.tomorrowView.frame = CGRectMake(self.contentView.frame.size.width / 2, self.todayView.frame.origin.y, self.contentView.frame.size.width / 2, self.todayView.frame.size.height);
    
    self.mTitleLabel.frame = CGRectMake(kLeft, kTop / 3, (self.tomorrowView.frame.size.width - kLeft)/ 2, (self.tomorrowView.frame.size.height - 2 * kTop / 3) / 3);
    self.mDegreesLabel.frame = CGRectMake(kLeft, CGRectGetMaxY(self.mTitleLabel.frame), self.mTitleLabel.frame.size.width, self.mTitleLabel.frame.size.height);
    self.mStatesLabel.frame = CGRectMake(kLeft, CGRectGetMaxY(self.mDegreesLabel.frame), self.mTitleLabel.frame.size.width, self.mTitleLabel.frame.size.height);
    self.mImageV.frame = CGRectMake(CGRectGetMaxX(self.mTitleLabel.frame), self.mTitleLabel.frame.origin.y, (self.tomorrowView.frame.size.width - kLeft)/ 2, self.tomorrowView.frame.size.height - 2 * kTop/ 3);
    
    //温度等
    self.weatherDegrees.frame = CGRectMake(kLeft, self.todayView.frame.origin.y - self.contentView.frame.size.width / 3, self.contentView.frame.size.width / 3, self.contentView.frame.size.width / 3);
    self.timeL.frame = CGRectMake(CGRectGetMaxX(self.weatherDegrees.frame), self.weatherDegrees.frame.origin.y + self.weatherDegrees.frame.size.height / 3, 80, self.weatherDegrees.frame.size.height / 2 / 5 * 2);
    self.weatherStates.frame = CGRectMake(self.timeL.frame.origin.x, CGRectGetMaxY(self.timeL.frame), 80, self.weatherDegrees.frame.size.height / 2 / 5 * 3);
    
    self.fabuTime.frame = CGRectMake(CGRectGetMaxX(self.weatherStates.frame), self.weatherStates.frame.origin.y, self.contentView.frame.size.width - CGRectGetMaxX(self.weatherStates.frame), self.weatherStates.frame.size.height);
    
    //今日
    self.nowImageV.frame = CGRectMake((self.contentView.frame.size.width - (self.todayView.frame.size.width - kLeft)/ 1.5) / 2, (self.contentView.frame.size.height - self.todayView.frame.size.height - 2 * kTop / 2.5) / 2 , (self.todayView.frame.size.width - kLeft)/ 1.5, self.todayView.frame.size.height - 2 * kTop / 2.5);
}
- (void)setTitle {

    	
    
    self.todayView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
    self.tomorrowView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
    self.tianqiL.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.3];
    self.warningL.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.3];
    
    [self.tianqiImageV sd_setImageWithURL:[NSURL URLWithString:self.weatherTop.bgImg] placeholderImage:nil];
    [self.tianqiImageVS sd_setImageWithURL:[NSURL URLWithString:self.weatherTop.logo] placeholderImage:nil];
    self.tianqiL.text = [NSString stringWithFormat:@"空气质量:%@", self.weatherTop.text];
    
    if (self.weatherTop.text.length != 0) {
        self.tianqiImageV.hidden = NO;
        self.tianqiImageVS.hidden = NO;
        self.tianqiL.hidden = NO;
        [self.tianqiImageV sd_setImageWithURL:[NSURL URLWithString:self.weatherTop.bgImg] placeholderImage:nil];
        [self.tianqiImageVS sd_setImageWithURL:[NSURL URLWithString:self.weatherTop.logo] placeholderImage:nil];
        self.tianqiL.text = [NSString stringWithFormat:@"空气质量:%@", self.weatherTop.text];
    } else {
        self.tianqiImageV.hidden = YES;
        self.tianqiImageVS.hidden = YES;
        self.tianqiL.hidden = YES;
    }
    
    if (self.weatherTop.warningText.length != 0) {
        self.warningImageV.hidden = NO;
        self.warningImageVS.hidden = NO;
        self.warningL.hidden = NO;
        [self.warningImageV sd_setImageWithURL:[NSURL URLWithString:self.weatherTop.warningBgImg] placeholderImage:nil];
        [self.warningImageVS sd_setImageWithURL:[NSURL URLWithString:self.weatherTop.warningLogo] placeholderImage:nil];
        self.warningL.text = [NSString stringWithFormat:@"警告:%@", self.weatherTop.warningText];
    } else {
        self.warningImageV.hidden = YES;
        self.warningImageVS.hidden = YES;
        self.warningL.hidden = YES;
    }
    
    self.weatherDegrees.text = [NSString stringWithFormat:@"%@°", self.weatherTop.temp];
    self.timeL.text = self.weatherTop.title;
    self.weatherStates.text = self.weatherTop.degreeText;
    self.fabuTime.text = self.weatherTop.pubdate;
    
    self.tTitleLabel.text = self.weatherTop.tdateName;
    self.tDegreesLabel.text = [NSString stringWithFormat:@"%@/%@°C", self.weatherTop.tlow, self.weatherTop.theight];
    
    self.mTitleLabel.text = self.weatherTop.mdateName;
    self.mDegreesLabel.text = [NSString stringWithFormat:@"%@/%@°C", self.weatherTop.mlow, self.weatherTop.mheight];
    self.tStatesLabel.text = self.weatherTop.tname;
    self.mStatesLabel.text = self.weatherTop.mname;
    
    NSString *tImageUrl = [NSString stringWithFormat:@"http://bcs.91.com/rbpiczy/weather/weatherIcon/%@.png", [[[[self backPinYin:self.weatherTop.tname] componentsSeparatedByString:@"dao"] lastObject] stringByReplacingOccurrencesOfString:@" " withString:@""]];
    [self.tImageV sd_setImageWithURL:[NSURL URLWithString:tImageUrl] placeholderImage:nil];
    [self.nowImageV sd_setImageWithURL:[NSURL URLWithString:tImageUrl] placeholderImage:nil];
    //图片不失真
    self.tImageV.contentMode = UIViewContentModeScaleAspectFill;
    self.nowImageV.contentMode = UIViewContentModeScaleAspectFill;
    //

    //把汉字转换为拼音  去掉中间的空格 再用到截取字符串
    NSString *mImageUrl = [NSString stringWithFormat:@"http://bcs.91.com/rbpiczy/weather/weatherIcon/%@.png", [[[[self backPinYin:self.weatherTop.mname] componentsSeparatedByString:@"dao"] lastObject] stringByReplacingOccurrencesOfString:@" " withString:@""]];
    [self.mImageV sd_setImageWithURL:[NSURL URLWithString:mImageUrl] placeholderImage:nil];
    
    self.mImageV.contentMode = UIViewContentModeScaleAspectFill;
}
-(void)setWeatherTop:(WeatherTop *)weatherTop {
    _weatherTop = weatherTop;
    [self setTitle];
}
- (void)awakeFromNib {
    // Initialization code
}
#pragma mark 判断是否有中文
-(BOOL)IsChinese:(NSString *)str {
    for(int i=0; i< [str length];i++){
        int a = [str characterAtIndex:i];
        if( a > 0x4e00 && a < 0x9fff){  //ox4e00 - 0x9fff 这是Unicode 汉字的编码范围
            return YES;
        }
    }
    return NO;
}

#pragma mark  返回中文姓名的拼音的首字母
- (NSString *)backPinYin:(NSString *)string{
    
    //这里应该少了个安全判断  就是 如果输入的字符串就是 NSString 类型的咋办=.= 万一这是给外国人用的呢 特么的名字是字母啊
    
    if ([string characterAtIndex:0] > 0x4e00 && [string characterAtIndex:0] < 0x9fff) {
        //转化成特定格式
        CFStringRef strRef = (__bridge CFStringRef)string; //这里的__bridge 没提示 只能硬敲
        //转化成汉字
        CFMutableStringRef newString = CFStringCreateMutableCopy(NULL, 0, strRef);
        //转化成带声调的拼音
        CFStringTransform(newString, NULL, kCFStringTransformMandarinLatin, NO);
        //去掉声调的拼音
        CFStringTransform(newString, NULL, kCFStringTransformStripDiacritics, NO);
        
        //将拼音转化成NSString类型的字符串
        string = (__bridge NSString *)newString;
    }
    
    //NSString *firstChar = [[string uppercaseString] substringToIndex:1];
    return string;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
