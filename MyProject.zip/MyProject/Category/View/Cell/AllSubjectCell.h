//
//  AllSubjectCell.h
//  MyProject
//
//  Created by M-coppco on 15/11/7.
//  Copyright © 2015年 
//

#import <UIKit/UIKit.h>
@class Subject;
@interface AllSubjectCell : UITableViewCell

@property (nonatomic, strong)Subject *subject;

@end
