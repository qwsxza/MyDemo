//
//  CategoryCell.h
//  MyProject
//
//  Created by M-coppco on 15/11/6.
//  Copyright © 2015年 . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CategoryTCell : UITableViewCell

@property (nonatomic, strong)NSMutableArray *modelArray;

@property (nonatomic, copy)void (^changeBlock)(NSString *subject, NSString *title); //点击collection

@end
