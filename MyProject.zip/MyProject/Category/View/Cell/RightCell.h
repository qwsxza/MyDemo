//
//  LeftCell.h
//  MyProject
//
//  Created by M-coppco on 15/11/7.
//  Copyright © 2015. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RightCell : UITableViewCell

@property (nonatomic, strong)NSMutableArray *modelArray;
@end
