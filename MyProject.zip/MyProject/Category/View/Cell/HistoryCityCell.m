//
//  HistoryCityCell.m
//  MyProject
//
//  Created by M-coppco on 15/11/16.
//  Copyright © 2015年 . All rights reserved.
//

#import "HistoryCityCell.h"
#import "UIColor+AddColor.h"
#import "City1.h"
#define kWidth (arc4random() % 254 + 1) / 255.0


@interface HistoryCityCell ()
@property (nonatomic, strong)UILabel *tipL;
@property (nonatomic, strong)UILabel *nameL;
@end

@implementation HistoryCityCell

-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.tipL = [[UILabel alloc] init];
        self.nameL = [[UILabel alloc] init];
        
        self.tipL.textColor = [UIColor jinjuse];
        self.nameL.textColor = [UIColor redColor];
        
        self.tipL.textAlignment = NSTextAlignmentCenter;
        self.nameL.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:self.tipL];
        [self.contentView addSubview:self.nameL];
        self.layer.cornerRadius = self.contentView.frame.size.width / 2;
        self.layer.borderWidth = 5;
        self.layer.borderColor = [[UIColor colorWithRed:kWidth green:kWidth blue:kWidth alpha:1] CGColor];
        self.layer.masksToBounds = YES;
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
        
    }
    return self;
}
-(void)layoutSubviews {
    [super layoutSubviews];
    self.nameL.frame = CGRectMake(0, 0, self.contentView.frame.size.width, self.contentView.frame.size.height / 2);
    self.tipL.frame = CGRectMake(0, self.contentView.frame.size.height / 2, self.contentView.frame.size.width, self.contentView.frame.size.height / 2);
}
-(void)setCity1:(City1 *)city1 {
    _city1 = city1;
    self.nameL.text = city1.name;
    self.tipL.text = city1.tip.length == 0 ? city1.name : city1.tip;
    
}
@end
