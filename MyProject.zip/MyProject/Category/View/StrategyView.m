//
//  StrategyView.m
//  MyProject
//
//  Created by M-coppco on 15/11/5.
//  Copyright © 2015年 . All rights reserved.
//

#import "StrategyView.h"
#import "SubjectCell.h"  //专题cell
#import "CategoryTCell.h"  //其他cell
#import "UIColor+AddColor.h"

@interface StrategyView ()<UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong)NSArray *array;
@property (nonatomic, assign)CGFloat contentY;  //用于判断tableView上下滚动
@end

@implementation StrategyView
-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.array = @[@"专题", @"分类", @"对象", @"场合", @"风格"];
        _tableView = [[UITableView alloc]initWithFrame:self.bounds style:(UITableViewStylePlain)];

        _tableView.rowHeight = self.frame.size.height / 2.5;
        self.tableView.dataSource = self;
        self.tableView.delegate = self;
        [self addSubview:self.tableView];
    }
    return self;
}

#pragma mark UIScrollerViewDelegate
//下面两个方法判断scrollerView或者tableView或者collection的滚动方向
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    self.contentY = scrollView.contentOffset.y;
}
- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView{
    //判断tableview上下移动
    if (((UITableView *)scrollView) == self.tableView) {
        //向下拉  y是负值
        if (self.contentY < scrollView.contentOffset.y) {
            self.up();
        } else {
            //上拉
            self.down();
        }
    }
}


#pragma mark UITableViewDataSource和Delegate
//每行高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return self.frame.size.height / 2.5;
    } else {
        CGFloat height = 40 + self.frame.size.width / 5;
        NSInteger i = 0;
        switch (indexPath.section) {
            case 1:
            {
                i = self.categoryArray.count / 4.0 == (int)(self.categoryArray.count / 4.0) ? self.categoryArray.count / 4 : self.categoryArray.count / 4 + 1;
            }
                break;
                
            case 2:
            {
                i = self.objectArray.count / 4.0 == (int)(self.objectArray.count / 4.0) ? self.objectArray.count / 4 : self.objectArray.count / 4 + 1;
            }
                break;
            case 3:
            {
                i = self.occasionArray.count / 4.0 == (int)(self.occasionArray.count / 4.0) ? self.occasionArray.count / 4 : self.occasionArray.count / 4 + 1;
            }
                break;
            case 4:
            {
                i = self.styleArray.count / 4.0 == (int)(self.styleArray.count / 4.0) ? self.styleArray.count / 4 : self.styleArray.count / 4 + 1;
            }
                break;
        }
        return height * i;
    }
}
//点击查看全部button
-(void)clickButton:(UIButton *)button {
    self.allSubject();
}
//-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
//    return self.frame.size.height / 18;
//}
//设置区头
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return self.frame.size.height / 18;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height / 18)];
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, view.frame.size.width - 60, view.frame.size.height)];
    if (section == 0) {
        UIButton *button = [UIButton buttonWithType:(UIButtonTypeSystem)];
        button.frame = CGRectMake(view.frame.size.width / 5 * 4, 0, view.frame.size.width / 5, view.frame.size.height);
        button.tintColor = [UIColor blackColor];
        button.tag = 9100;
        [button addTarget:self action:@selector(clickButton:) forControlEvents:(UIControlEventTouchUpInside)];
        [button setTitle:@"查看全部" forState:(UIControlStateNormal)];
        button.tintColor = [UIColor redColor];
        [view addSubview:button];
    }
    view.backgroundColor = [UIColor silverColor];
    [view addSubview:label];
    label.text = self.array[section];
    label.textColor = [UIColor blackColor];
    //view.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.3];
    return view;
}
//分区数
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 5;
}
//分区行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}
//加载单元格
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath  {

    if (indexPath.section == 0) {
        SubjectCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SubjectCell"];
        if (!cell) {
            cell = [[SubjectCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"SubjectCell"];
        }
        cell.subjectArray = self.subjectArray;
        //block 实现切换页面
        [cell setChangeBlock:^(NSString *subjectId, NSString *title) {
            self.toController(subjectId, title);
        }];
        return cell;
    } else {
        CategoryTCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CategoryTCell"];
        if (!cell) {
            cell = [[CategoryTCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:@"CategoryTCell"];
        }
        //block 实现切换页面
        [cell setChangeBlock:^(NSString *channelId, NSString *title) {
            self.toControllerC(channelId, title);
        }];
        switch (indexPath.section) {
            case 1:
            {
                cell.modelArray = self.categoryArray;
            }
                break;
            case 2:
            {
                cell.modelArray = self.objectArray;
            }
                break;
            case 3:
            {
                cell.modelArray = self.occasionArray;
            }
                break;
            case 4:
            {
                cell.modelArray = self.styleArray;
            }
                break;
        }
        return cell;
    }
}
#pragma mark 几个数组setter方法
//专题
-(void)setSubjectArray:(NSMutableArray *)subjectArray {
    _subjectArray = subjectArray;
    
    [self.tableView reloadData];
}
- (void)setFourArrayWithCategoryArray:(NSMutableArray *)categoryArray objectArray:(NSMutableArray *)objectArray occasionArray:(NSMutableArray *)occasionArray styleArray:(NSMutableArray *)styleArray {
    _categoryArray = categoryArray;
    _objectArray = objectArray;
    _occasionArray = occasionArray;
    _styleArray = styleArray;
    [self.tableView reloadData];
}
////分类
//-(void)setCategoryArray:(NSMutableArray *)categoryArray {
//    _categoryArray = categoryArray;
//    
//    [self.tableView reloadData];
//}
////对象
//-(void)setObjectArray:(NSMutableArray *)objectArray {
//    _objectArray = objectArray;
//    [self.tableView reloadData];
//}
////场合
//-(void)setOccasionArray:(NSMutableArray *)occasionArray {
//    _occasionArray = occasionArray;
//    [self.tableView reloadData];
//}
////风格
//-(void)setStyleArray:(NSMutableArray *)styleArray {
//    _styleArray = styleArray;
//    [self.tableView reloadData];
//}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
