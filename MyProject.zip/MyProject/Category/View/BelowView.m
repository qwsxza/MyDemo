//
//  BelowView.m
//  MyProject
//
//  Created by M-coppco on 15/11/5.
//  Copyright © 2015年 rights reserved.
//

#import "BelowView.h"
#import "UIColor+AddColor.h"

@interface BelowView ()
@property (nonatomic, strong)UIView *view1;
@end

@implementation BelowView
-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        //self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.7];
        _segment = [[UISegmentedControl alloc]initWithItems:@[@"推荐", @"鲸选"]];
        _segment.frame =self.bounds;
        _segment.selectedSegmentIndex = 0;
        _segment.tintColor = [UIColor redColor];
        [self addSubview:_segment];
    }
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
