//
//  SelectListView.h
//  MyProject
//
//  Created by M-coppco on 15/11/10.
//  Copyright © 2015年 . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectListView : UIView
@property (nonatomic, strong)NSMutableArray *selectArray;  //传值
@property (nonatomic, strong)UITableView *tableView;
@end
