//
//  StrategyView.h
//  MyProject
//
//  Created by M-coppco on 15/11/5.
//  Copyright © 2015年 . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StrategyView : UIView
@property (nonatomic, strong, readonly)UITableView *tableView;

- (void)setFourArrayWithCategoryArray:(NSMutableArray *)categoryArray objectArray:(NSMutableArray *)objectArray occasionArray:(NSMutableArray *)occasionArray styleArray:(NSMutableArray *)styleArray;

@property (nonatomic, strong)NSMutableArray *subjectArray;  //专题model数组

@property (nonatomic, strong)NSMutableArray *categoryArray;  //品类
@property (nonatomic, strong)NSMutableArray *objectArray;  //对象
@property (nonatomic, strong)NSMutableArray *occasionArray;  //场合
@property (nonatomic, strong)NSMutableArray *styleArray;  //风格

@property (nonatomic, copy)void (^toController)(NSString *subjectId, NSString *title);  //点击专题cellbutton传值

@property (nonatomic, copy)void (^toControllerC)(NSString *channelId, NSString *title);  //点击专题othercollectionItem传值

@property (nonatomic, copy)void (^up)();  //改变controller中分段上移动
@property (nonatomic, copy)void (^down)();  //改变controller中分段下移动

@property (nonatomic, copy)void (^allSubject)();  //点击查看全部
@end
