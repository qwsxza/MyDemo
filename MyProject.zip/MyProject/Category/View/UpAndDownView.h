//
//  UpAndDownView.h
//  MyProject
//
//  Created by M-coppco on 15/11/11.
//  Copyright © 2015年 . All rights reserved.
//

#import <UIKit/UIKit.h>
@class Filters;
@interface UpAndDownView : UIView
@property (nonatomic, strong)Filters *filters;
@property (nonatomic, assign)NSInteger index;

//string 是为segment赋值标题  flag为了解析数据的id   index为了判断是第几个参数
@property (nonatomic, copy)void (^upAndDown)(NSString *string, NSString *flag, NSString *index);
@property (nonatomic, copy)void (^back)();
@end
