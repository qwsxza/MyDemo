//
//  BelowView.h
//  MyProject
//
//  Created by M-coppco on 15/11/5.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BelowView : UIView
@property (nonatomic, strong, readonly)UISegmentedControl *segment;  //分段控制器
@end
