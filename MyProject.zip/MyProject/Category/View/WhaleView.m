//
//  WhaleView.m
//  MyProject
//
//  Created by M-coppco on 15/11/5.
//  Copyright © 2015年 . All rights reserved.
//

#import "WhaleView.h"
#import "LeftCell.h"  //左侧单元格
#import "RightCell.h"  //右侧单元格
#import "SubCategory.h"
#import "UIColor+AddColor.h"


@interface WhaleView ()<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong)NSArray *categoryArray;

@property (nonatomic, assign)CGFloat contentY;  //用于判断tableView上下滚动

@property (nonatomic, strong)NSIndexPath *index;  //判断之前的下标
@property (nonatomic, strong)NSIndexPath *index1;  //判断之前的下标

@property (nonatomic, strong)NSMutableArray *heightArray;  //高度数组
@property (nonatomic, assign)BOOL isFirst;
@end

@implementation WhaleView

-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.index = [NSIndexPath indexPathForRow:0 inSection:0];
        self.index1 = [NSIndexPath indexPathForRow:0 inSection:0];
        
        self.leftTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width / 4, self.frame.size.height) style:(UITableViewStylePlain)];
        self.leftTableView.delegate = self;
        self.leftTableView.dataSource = self;
        self.leftTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.leftTableView.showsVerticalScrollIndicator = NO;
        [self addSubview:self.leftTableView];
        
        self.rightTableView = [[UITableView alloc] initWithFrame:CGRectMake(self.leftTableView.frame.size.width, 0, self.frame.size.width - self.leftTableView.frame.size.width, self.frame.size.height) style:(UITableViewStylePlain)];
    
        self.rightTableView.delegate = self;
        self.rightTableView.dataSource =self;
        self.rightTableView.showsVerticalScrollIndicator = NO;
    
        
        [self addSubview:self.rightTableView];
        
    }
    return self;
}

//-(void)tableView:(UITableView *)tableView didEndDisplayingHeaderView:(UIView *)view forSection:(NSInteger)section {
//    if ([tableView isEqual:self.rightTableView]) {
//       
//        LeftCell *cell1 = [self.leftTableView cellForRowAtIndexPath:self.index1];
//        cell1.backgroundColor = [UIColor whiteColor];
//        cell1.leftLabel.backgroundColor = [UIColor clearColor];
//        cell1.titleLabel.textColor = [UIColor blackColor];
//        if (self.contentY < tableView.contentOffset.y) {
//            NSLog(@"up");
//            NSIndexPath *index = [NSIndexPath indexPathForRow:section+1 inSection:0];
//            LeftCell *cell = [self.leftTableView cellForRowAtIndexPath:index];
//            cell.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
//            cell.leftLabel.backgroundColor = [UIColor redColor];
//            cell.titleLabel.textColor = [UIColor redColor];
//    
//            LeftCell *cell1 = [self.leftTableView cellForRowAtIndexPath:self.index1];
//            cell1.backgroundColor = [UIColor whiteColor];
//            cell1.leftLabel.backgroundColor = [UIColor clearColor];
//            cell1.titleLabel.textColor = [UIColor blackColor];
////            if (index.section == 14) {
////                self.index1 = [NSIndexPath indexPathForRow:16 inSection:0];
////            } else {
//                self.index1 = index;
////            }
//        } else {
//            //上拉
//            NSLog(@"down");
//            if (section == 16) {
//                
//            } else if(section == 2){
//                NSIndexPath *index = [NSIndexPath indexPathForRow:section-2 inSection:0];
//                LeftCell *cell = [self.leftTableView cellForRowAtIndexPath:index];
//                cell.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
//                cell.leftLabel.backgroundColor = [UIColor redColor];
//                cell.titleLabel.textColor = [UIColor redColor];
//                
//                LeftCell *cell1 = [self.leftTableView cellForRowAtIndexPath:self.index1];
//                cell1.backgroundColor = [UIColor whiteColor];
//                cell1.leftLabel.backgroundColor = [UIColor clearColor];
//                cell1.titleLabel.textColor = [UIColor blackColor];
//                self.index1 = index;
//            } else {
//                NSIndexPath *index = [NSIndexPath indexPathForRow:section-1 inSection:0];
//                LeftCell *cell = [self.leftTableView cellForRowAtIndexPath:index];
//                cell.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
//                cell.leftLabel.backgroundColor = [UIColor redColor];
//                cell.titleLabel.textColor = [UIColor redColor];
//                
//                LeftCell *cell1 = [self.leftTableView cellForRowAtIndexPath:self.index1];
//                cell1.backgroundColor = [UIColor whiteColor];
//                cell1.leftLabel.backgroundColor = [UIColor clearColor];
//                cell1.titleLabel.textColor = [UIColor blackColor];
//                self.index1 = index;
//            }
//                
//        }

//        //改变左侧前面几个下移
//        if (section +1  <= 9 && section + 1 >= 1 && self.contentY > tableView.contentOffset.y) {
//            [self.leftTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:section - 2 inSection:0] atScrollPosition:UITableViewScrollPositionNone animated:YES];
//        }
//        //左侧后几个上移
//        if (section >= 3 && section <= 9 && self.contentY < tableView.contentOffset.y) {
//            
//            [self.leftTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:6 + section  inSection:0] atScrollPosition:UITableViewScrollPositionNone animated:YES];
//        } else if (section >= 10) {
//            [self.leftTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:16  inSection:0] atScrollPosition:UITableViewScrollPositionNone animated:YES];
//        }
//        
//    }
//}
//#pragma mark  观察者方法
//-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context {
//    if (object == self.rightTableView && [keyPath isEqualToString:@"contentOffset"]) {
//        CGPoint point = [change[@"new"] CGPointValue];
//        
//       
//        } else {
//        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
//    }
//    
//}
#pragma mark UITabelView
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([tableView isEqual:self.rightTableView]) {
         CGFloat height = 40 + self.frame.size.width / 4 * 3 / 3.8;
        NSInteger i = ((NSArray *)self.whaleDictionary[self.categoryArray[indexPath.section]]).count;
        NSInteger j = i / 3.0 == (int)(i / 3) ? i / 3 : i / 3 + 1;
        return height * j;
    }
    return self.frame.size.height / 10;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if ([tableView isEqual:self.leftTableView]) {
        return 1;
    }
    return self.whaleDictionary.allKeys.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if ([tableView isEqual:self.leftTableView]) {
        return self.whaleDictionary.allKeys.count;
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([tableView isEqual:self.leftTableView]) {
        LeftCell *cell = [tableView dequeueReusableCellWithIdentifier:@"LeftCell"];
        //解决单元格重用的时候 颜色改变
        if (self.index.row != indexPath.row) {
            cell.leftLabel.backgroundColor = [UIColor clearColor];
            cell.titleLabel.textColor = [UIColor blackColor];
            cell.backgroundColor = [UIColor whiteColor];
        } else {
            cell.leftLabel.backgroundColor = [UIColor redColor];
            cell.titleLabel.textColor = [UIColor redColor];
            cell.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
        }
        if (!cell) {
            cell = [[LeftCell alloc]initWithStyle:(UITableViewCellStyleValue1) reuseIdentifier:@"LeftCell"];
        }
        
        //初值
//        static dispatch_once_t onceToken;
//        dispatch_once(&onceToken, ^{
        if (self.isFirst == NO) {
            cell.leftLabel.backgroundColor = [UIColor redColor];
            cell.titleLabel.textColor = [UIColor redColor];
            cell.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
            self.isFirst = YES;
        }
//        });
        
        cell.title = [self.categoryArray[indexPath.row] substringFromIndex:2];
        return cell;
    } else {
        RightCell *cell = [tableView dequeueReusableCellWithIdentifier:@"RightCell"];
        if (!cell) {
            cell = [[RightCell alloc]initWithStyle:(UITableViewCellStyleValue1) reuseIdentifier:@"RightCell"];
        }
        cell.modelArray = self.whaleDictionary[self.categoryArray[indexPath.section]];
   
        return cell;
    }
}

#pragma mark  dic的setter方法
-(void)setWhaleDictionary:(NSMutableDictionary *)whaleDictionary {
    _whaleDictionary = whaleDictionary;
    
    self.categoryArray = [self.whaleDictionary.allKeys sortedArrayWithOptions:NSSortConcurrent usingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        return [(NSString *)obj1 compare:(NSString *)obj2];
    }];

    [self.leftTableView reloadData];
    [self.rightTableView reloadData];
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if ([tableView isEqual:self.rightTableView]) {
        return self.frame.size.height / 18;
    }
    return 0;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if ([tableView isEqual:self.rightTableView]) {
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height / 18)];
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, view.frame.size.width - 60, view.frame.size.height)];
        view.backgroundColor = [UIColor silverColor];
        [view addSubview:label];
        label.text = [self.categoryArray[section] substringFromIndex:2];
        label.textColor = [UIColor blackColor];
        return view;
    } else {
        return nil;
    }
}
#pragma mark UIScrollerViewDelegate
//下面两个方法判断scrollerView或者tableView或者collection的滚动方向
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    self.contentY = scrollView.contentOffset.y;
}

- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView{
    //判断tableview上下移动
    if (((UITableView *)scrollView) == self.rightTableView) {
        //向下拉  y是负值
        if (self.contentY < scrollView.contentOffset.y) {
            self.up();
            
        } else {
            //上拉
            
            self.down();
        }
    }
}

#pragma mark 滚动视图

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([tableView isEqual:self.leftTableView]) {
        if (self.index.row != indexPath.row) {
            //改变颜色  现在的cell颜色
            LeftCell *cell = [tableView cellForRowAtIndexPath:indexPath];
            cell.leftLabel.backgroundColor = [UIColor redColor];
            cell.titleLabel.textColor = [UIColor redColor];
            cell.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
            
            //之前的cell颜色
            LeftCell *cell1 = [tableView cellForRowAtIndexPath:self.index];
            cell1.leftLabel.backgroundColor = [UIColor clearColor];
            cell1.titleLabel.textColor = [UIColor blackColor];
            cell1.backgroundColor = [UIColor whiteColor];
            
            //scrollView滚动到指定NSIndexPath
            [self setRightTabelViewAnimated];
            [self.rightTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:indexPath.row] atScrollPosition:UITableViewScrollPositionNone animated:NO];
            //取消选中
             [tableView deselectRowAtIndexPath:indexPath animated:YES];
        }
        self.index = indexPath;
        CGFloat height = self.frame.size.height / 10;
        
        //改变左侧前面几个下移
        if (indexPath.row <= 7 && indexPath.row>= 1 && (self.leftTableView.contentOffset.y > height * (indexPath.row - 1))) {
            [self.leftTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:indexPath.row - 1 inSection:0] atScrollPosition:UITableViewScrollPositionNone animated:YES];
        }
    
        //左侧后几个上移
        if (indexPath.row >= 3 && indexPath.row <= 9 && (self.leftTableView.contentOffset.y < height * (indexPath.row - 1))) {
            [self.leftTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:7 + indexPath.row  inSection:0] atScrollPosition:UITableViewScrollPositionNone animated:YES];
        } else if (indexPath.row >= 10) {
            [self.leftTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:16  inSection:0] atScrollPosition:UITableViewScrollPositionNone animated:YES];
        }
    }
}
#pragma mark 设置scrollView动画效果
- (void)setRightTabelViewAnimated {
    CATransition *transition = [CATransition animation];
    transition.type = @"rippleEffect";
    transition.subtype = kCATransitionFromTop;
    transition.duration = 1;
    [self.rightTableView.layer addAnimation:transition forKey:@"水波纹效果"];
}
@end
