//
//  WhaleView.h
//  MyProject
//
//  Created by M-coppco on 15/11/5.
//  Copyright © 2015年 . All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WhaleView : UIView

@property (nonatomic, strong)NSMutableDictionary *whaleDictionary;  //鲸选字典
@property (nonatomic, strong)UITableView *rightTableView;
@property (nonatomic, strong)UITableView *leftTableView;

@property (nonatomic, copy)void (^up)();  //改变controller中分段上移动
@property (nonatomic, copy)void (^down)();  //改变controller中分段下移动
@end
