//
//  SelectListView.m
//  MyProject
//
//  Created by M-coppco on 15/11/10.
//  Copyright © 2015年 . All rights reserved.
//

#import "SelectListView.h"
#import "SelectListCell.h"  //自定义cell

@interface SelectListView ()<UITableViewDataSource, UITableViewDelegate>

@end

@implementation SelectListView
-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, -20, frame.size.width, frame.size.height + 20) style:(UITableViewStylePlain)];
        self.tableView.rowHeight = frame.size.width / 2 + 10;
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self addSubview:self.tableView];
    }
    return self;
}
-(void)setSelectArray:(NSMutableArray *)selectArray {
    _selectArray = selectArray;
    
    [self.tableView reloadData];
}
#pragma mark  UITableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.selectArray.count;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *reuse = @"SelectListCell";
    SelectListCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (!cell) {
        cell = [[SelectListCell alloc] initWithStyle:(UITableViewCellStyleValue1) reuseIdentifier:reuse];
    }
    cell.goodsList = self.selectArray[indexPath.row];
    return cell;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
