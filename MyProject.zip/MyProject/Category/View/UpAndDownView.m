//
//  UpAndDownView.m
//  MyProject
//
//  Created by M-coppco on 15/11/11.
//  Copyright © 2015年 g. All rights reserved.
//

#import "UpAndDownView.h"
#import "Filters.h"  //model
#import "Channels.h"
#import "UIColor+AddColor.h"

#define KLeft 10
#define KTop 10
#define KH 10
#define KV 10
#define KWidth (self.frame.size.width - 2 * KLeft - 2 * KH) / 3
#define KHeighy ((self.frame.size.height - 20) - 2 * KTop - 2 * KV) / 3
@interface UpAndDownView ()
@property (nonatomic, assign)NSInteger one;
@property (nonatomic, assign)NSInteger two;
@property (nonatomic, assign)NSInteger three;
@property (nonatomic, assign)NSInteger four;
@property (nonatomic, strong)UIButton *backButton;
@end

@implementation UpAndDownView
-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.one = -1;
        self.two = -1;
        self.three = -1;
        self.four = -1 ;
        self.index = -1;
        for (int i = 0; i < 9; i++) {
            UIButton *button = [UIButton buttonWithType:(UIButtonTypeSystem)];
            button.frame = CGRectMake(KLeft + (KH + KWidth) * (i % 3), KTop + (KV + KHeighy) * (i / 3), KWidth, KHeighy);
            button.tag = 3400 + i;
            button.tintColor = [UIColor blackColor];
            button.titleLabel.font  = [UIFont systemFontOfSize:16];
            button.layer.cornerRadius = 5;
            button.layer.borderWidth = 1;
            button.layer.borderColor = [[UIColor grayColor] CGColor];
            [button addTarget:self action:@selector(click:) forControlEvents:(UIControlEventTouchUpInside)];
            button.layer.masksToBounds = YES;
            
            [self addSubview:button];
        }
        self.backButton = [UIButton buttonWithType:(UIButtonTypeSystem)];
        self.backButton.frame = CGRectMake(frame.size.width / 5 * 2, KTop + (KV + KHeighy) * 2 + KHeighy, frame.size.width / 5, 30);
        [self.backButton setTitle:@"返回" forState:(UIControlStateNormal)];
        [self.backButton addTarget:self action:@selector(back:) forControlEvents:(UIControlEventTouchUpInside)];
//        self.backButton.layer.borderWidth = 3;
//        self.backButton.layer.borderColor = [[UIColor jinjuse] CGColor];
        [self addSubview:self.backButton];
    }
    return self;
}
#pragma mark setter方法
-(void)setFilters:(Filters *)filters {
    _filters = filters;
    for (int i = 0; i < 9; i++) {
        UIButton *button = [self viewWithTag:3400 + i];
        
        switch (self.index) {
            case 0:
            {
                UIButton *button1 = [self viewWithTag:self.one];
                UIButton *button2 = [self viewWithTag:self.two];
                button2.backgroundColor = [UIColor whiteColor];
                UIButton *button3 = [self viewWithTag:self.three];
                button3.backgroundColor = [UIColor whiteColor];
                UIButton *button4 = [self viewWithTag:self.four];
                button4.backgroundColor = [UIColor whiteColor];
                button1.backgroundColor = [UIColor redColor];
            }
                break;
            case 1:
            {
                UIButton *button1 = [self viewWithTag:self.one];
                button1.backgroundColor = [UIColor whiteColor];
                UIButton *button2 = [self viewWithTag:self.two];
                UIButton *button3 = [self viewWithTag:self.three];
                button3.backgroundColor = [UIColor whiteColor];
                UIButton *button4 = [self viewWithTag:self.four];
                button4.backgroundColor = [UIColor whiteColor];
                button2.backgroundColor = [UIColor redColor];
            }
                break;
            case 2:
            {
                UIButton *button1 = [self viewWithTag:self.one];
                button1.backgroundColor = [UIColor whiteColor];
                UIButton *button2 = [self viewWithTag:self.two];
                button2.backgroundColor = [UIColor whiteColor];
                UIButton *button3 = [self viewWithTag:self.three];
                UIButton *button4 = [self viewWithTag:self.four];
                button4.backgroundColor = [UIColor whiteColor];
                button3.backgroundColor = [UIColor redColor];
            }
                break;
            case 3:
            {
                UIButton *button1 = [self viewWithTag:self.one];
                button1.backgroundColor = [UIColor whiteColor];
                UIButton *button2 = [self viewWithTag:self.two];
                button2.backgroundColor = [UIColor whiteColor];
                UIButton *button3 = [self viewWithTag:self.three];
                button3.backgroundColor = [UIColor whiteColor];
                UIButton *button4 = [self viewWithTag:self.four];
                button4.backgroundColor = [UIColor redColor];
            }
                break;
        }
        
        if (i == 0) {
            [button setTitle:@"全部" forState:(UIControlStateNormal)];
        } else  if (i >= 1 && i <= filters.channels.count){
            button.hidden = NO;
            [button setTitle:((Channels *)filters.channels[i - 1]).name forState:(UIControlStateNormal)];
        } else {
            button.hidden = YES;
        }
    }
    
}
- (void)back:(UIButton *)button {
    self.back();
}
- (void)click:(UIButton *)button {
    
    //当前的button点击不变
    if (1) {
        //以前的button变白色
        switch (self.index) {
            case 0:
            {
                UIButton *button1 = [self viewWithTag:self.one];
                button1.backgroundColor = [UIColor whiteColor];
                self.one = button.tag;
            }
                break;
            case 1:
            {
                UIButton *button1 = [self viewWithTag:self.two];
                button1.backgroundColor = [UIColor whiteColor];
                self.two = button.tag;
        
            }
                break;
            case 2:
            {
                UIButton *button1 = [self viewWithTag:self.three];
                button1.backgroundColor = [UIColor whiteColor];
                self.three = button.tag;
            }
                break;
            case 3:
            {
                UIButton *button1 = [self viewWithTag:self.four];
                button1.backgroundColor = [UIColor whiteColor];
                self.four = button.tag;
            }
                break;
        }
        //现在的button变红色
        button.backgroundColor = [UIColor redColor];
    }
    if (button.tag == 3400) {
        //NSLog(@"全部");
        self.upAndDown(@"全部", @"", [NSString stringWithFormat:@"%ld", (long)self.index]);
    } else {
        //NSLog(@"%@", ((Channels *)self.filters.channels[button.tag - 3400 - 1]).name);
        self.upAndDown(((Channels *)self.filters.channels[button.tag - 3400 - 1]).name, ((Channels *)self.filters.channels[button.tag - 3400 - 1]).key, [NSString stringWithFormat:@"%ld", (long)self.index]);
    }
}
@end
