//
//  City1.m
//  MyProject
//
//  Created by M-coppco on 15/11/16.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "City1.h"

@implementation City1

// Insert code here to add functionality to your managed object subclass

@end
