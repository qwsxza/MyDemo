//
//  City1+CoreDataProperties.h
//  MyProject
//
//  Created by M-coppco on 15/11/16.
//  Copyright © 2015年 gp. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "City1.h"

NS_ASSUME_NONNULL_BEGIN

@interface City1 (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *districtName;
@property (nullable, nonatomic, retain) NSString *cityId;
@property (nullable, nonatomic, retain) NSString *name;
@property (nullable, nonatomic, retain) NSString *tip;

@end

NS_ASSUME_NONNULL_END
