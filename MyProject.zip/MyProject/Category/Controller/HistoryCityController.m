//
//  HistoryCithController.m
//  MyProject
//
//  Created by M-coppco on 15/11/16.
//  Copyright © 2015年 . All rights reserved.
//

#import "HistoryCityController.h"
#import "UIColor+AddColor.h"
#import "City1.h"  //类
#import "AppDelegate.h"
#import "HistoryCityCell.h"

@interface HistoryCityController ()<UICollectionViewDataSource, UICollectionViewDelegate, UIAlertViewDelegate>
@property (nonatomic, retain)NSManagedObjectContext *manageObjectContext; //临时数据库  上下文

@property (nonatomic, strong)NSMutableArray *array;  //city数组
@property (nonatomic, strong)UICollectionViewFlowLayout *layout;
@property (nonatomic, strong)UICollectionView *collectView;

@property (nonatomic, strong)UIButton *rubbishButton;
@end

@implementation HistoryCityController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.topView.backgroundColor = [UIColor jinjuse];
    self.titleLabel.text = @"History";
    self.titleLabel.textColor = [UIColor blueColor];
    self.titleLabel.font = [UIFont fontWithName:@"SnellRoundhand-Black" size:24];
    
    //历史button
    self.rubbishButton = [UIButton buttonWithType:(UIButtonTypeCustom)];
    self.rubbishButton.frame = CGRectMake(self.topView.frame.size.width - self.titleLabel.frame.size.height- 30, self.titleLabel.frame.origin.y, self.titleLabel.frame.size.height, self.titleLabel.frame.size.height);
    [self.rubbishButton setBackgroundImage:[UIImage imageNamed:@"laji"] forState:(UIControlStateNormal)];
    [self.rubbishButton addTarget:self action:@selector(deleteB:) forControlEvents:(UIControlEventTouchUpInside)];
    [self.topView addSubview:self.rubbishButton];
    
    //在程序的任何地方都可以获取appdelegate ,它是一个单例
    //获取到AppDelegate中的临时数据库
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    self.manageObjectContext = appDelegate.managedObjectContext;
    self.layout = [[UICollectionViewFlowLayout alloc] init];
    self.layout.minimumInteritemSpacing = 0;
    self.layout.minimumLineSpacing = 0;
    
    self.layout.itemSize = CGSizeMake(self.backView.frame.size.width / 2, self.backView.frame.size.width / 2);
    self.collectView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height) collectionViewLayout:self.layout];
    
    self.collectView.delegate = self;
    self.collectView.dataSource = self;
    
    self.collectView.backgroundColor = [UIColor whiteColor];
    //注册
    [self.collectView registerClass:[HistoryCityCell class] forCellWithReuseIdentifier:@"HistoryCityCell"];
    [self.backView addSubview:self.collectView];
    [self search];
    
    
    // Do any additional setup after loading the view.
}
#pragma mark 
- (void)longPressAction:(UILongPressGestureRecognizer *)longPress {
    HistoryCityCell *cell = (HistoryCityCell *)longPress.view;
    [cell removeGestureRecognizer:longPress];
    self.collectView.userInteractionEnabled = NO;
    [self searchWith:self.array[cell.index.item]];
}

//查找某个并删除city
- (void)searchWith:(City1 *)city {
    // 1. 实例化一个查询(Fetch)请求
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"City1"];
    
    //2 谓词
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"cityId CONTAINS %@", city.cityId]; //一定要加单引号
    request.predicate = predicate;
    
    // 3. 由上下文查询数据
    NSArray *result = [self.manageObjectContext executeFetchRequest:request error:nil];
    
    // 4. 输出结果
    for (City1 *city1 in result) {
        // 删除一条记录
        [self.manageObjectContext deleteObject:city1];
    }
    
    // 5. 通知_context保存数据
    if ([self.manageObjectContext save:nil]) {
        NSLog(@"删除成功");
    } else {
        NSLog(@"删除失败");
    }
    [self search];
}
//查找所有city
- (void)search {
    //请求
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"City1"];
    
    //排序
    NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"tip" ascending:YES];
    NSSortDescriptor *sort1 = [NSSortDescriptor sortDescriptorWithKey:@"name" ascending:YES];
    request.sortDescriptors = @[sort, sort1];//先根据sort中的属性进行排序,然后在重复的name中按照sort1中的属性再进行排序
    
    //执行这个请求,得到结果
    NSArray *array = [self.manageObjectContext executeFetchRequest:request error:nil];
//    if (array.count != 0) {
        self.array = [NSMutableArray arrayWithArray:array];
//    }
}
#pragma mark alertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        [self deleteAllCities];
    }
}
- (void)deleteB:(UIButton *)button {
    
    if ([[UIDevice currentDevice].systemVersion floatValue] == 7.0) {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"是否清空历史记录" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
        [alertView show];
    } else {
        UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"提示" message:@"是否清空历史记录" preferredStyle:(UIAlertControllerStyleAlert)];
        UIAlertAction *actionSure = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            [self deleteAllCities];
        }];
        UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:@"取消" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        [alertVC addAction:actionCancel];
        [alertVC addAction:actionSure];
        [self presentViewController:alertVC animated:YES completion:nil];
    }
    
}
- (void)deleteAllCities {
    // 1. 实例化一个查询(Fetch)请求
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"City1"];
    // 3. 由上下文查询数据
    NSArray *result = [self.manageObjectContext executeFetchRequest:request error:nil];
    
    // 4. 输出结果
    for (City1 *city1 in result) {
        // 删除一条记录
        [self.manageObjectContext deleteObject:city1];
    }
    
    // 5. 通知_context保存数据
    if ([self.manageObjectContext save:nil]) {
        NSLog(@"删除成功");
    } else {
        NSLog(@"删除失败");
    }
    self.array = nil;
}
-(void)setArray:(NSMutableArray *)array {
    _array = array;
    
    //刷新数据
    [self.collectView reloadData];
}
#pragma mark UICollectionView
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.array.count;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    HistoryCityCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"HistoryCityCell" forIndexPath:indexPath];
    cell.city1 = self.array[indexPath.item];
    cell.index = indexPath;
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressAction:)];
    longPress.minimumPressDuration = 1;
    [cell addGestureRecognizer:longPress];
    self.collectView.userInteractionEnabled = YES;
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    self.changeCity(self.array[indexPath.item]);
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
