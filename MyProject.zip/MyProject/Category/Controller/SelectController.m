//
//  SelectController.m
//  MyProject
//
//  Created by M-coppco on 15/11/10.
//  Copyright © 2015年 . All rights reserved.
//

#import "SelectController.h"
#import "UIColor+AddColor.h"  //颜色
#import "AFNetworking.h"
#import "Filters.h"  //model
#import "SelectListView.h"  //选择列表视图
#import "GoodsList.h"  //MODEL
#import "UpAndDownView.h"
#import "MBProgressHUD.h"  //菊花转
#import "MJRefresh.h"  //上下拉刷新
#import "BrandGiftDetailViewController.h"  //礼物详情

@interface SelectController ()<UITableViewDelegate>
@property (nonatomic, strong)NSMutableArray *segmentArray;  //segment数组
@property (nonatomic, strong)NSMutableArray *selectArray;  //选择数组
@property (nonatomic, strong)NSMutableArray *selectArrayDDD;  //选择数组
@property (nonatomic ,strong)SelectListView *selectListView;

@property (nonatomic, strong)NSMutableArray *categoryArray;  //几个分段数组

@property (nonatomic, strong)UISegmentedControl *segment;
@property (nonatomic, strong)UpAndDownView *upAndDownView;  //动画view
@property (nonatomic, strong)MBProgressHUD *hud;

//target 男票参数   scene 生日   personality  萌  price 价格
@property (nonatomic, copy)NSString *target;
@property (nonatomic, copy)NSString *scene;
@property (nonatomic, copy)NSString *personality;
@property (nonatomic, copy)NSString *price;
@end

@implementation SelectController
- (void)p_setLoading {
    self.hud = [[MBProgressHUD alloc]initWithView:self.backView];
    self.hud.frame = self.view.bounds;
    self.hud.minSize = CGSizeMake(100, 100);
    self.hud.mode = MBProgressHUDModeCustomView;
    self.hud.animationType = MBProgressHUDAnimationZoom;
    self.hud.labelText = @"正在加载";
    [self.backView addSubview:self.hud];
    [self.hud show:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.topView.backgroundColor = [UIColor jinjuse];
    self.titleLabel.text = @"选礼神器";
    self.target = @"";
    self.personality = @"";
    self.price = @"";
    self.scene = @"";
    self.selectArray = [NSMutableArray array];
    self.selectArrayDDD = [NSMutableArray array];
    //分段控制
    self.segment = [[UISegmentedControl alloc] initWithItems:@[@"", @"", @"", @""]];
    self.segment.frame = CGRectMake(0, 0, self.backView.frame.size.width, self.backView.frame.size.height / 18);

    
    self.segment.tintColor = [UIColor redColor];
    
    [self.segment setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:18 weight:1],NSFontAttributeName, nil] forState:UIControlStateNormal];
    [self.segment addTarget:self action:@selector(changeSegment:) forControlEvents:(UIControlEventValueChanged)];
    self.segment.backgroundColor = [UIColor whiteColor];
    [self.backView addSubview:self.segment];
    

    //选择视图
    self.selectListView = [[SelectListView alloc] initWithFrame:CGRectMake(0, self.segment.frame.size.height, self.backView.frame.size.width, self.backView.frame.size.height - self.segment.frame.size.height)];
    self.selectListView.tableView.delegate = self;
    //上拉加载更多
    self.selectListView.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self p_setLoading];
        [self.target  isEqual: @""] && [self.personality  isEqual: @""] && [self.price  isEqual: @""] && [self.scene  isEqual: @""] ? [self getListData] : [self getListSelectData];
        
    }];
    [self.backView addSubview:self.selectListView];
   
    //上面的选择视图
    self.upAndDownView = [[UpAndDownView alloc] initWithFrame:CGRectMake(0, self.segment.frame.size.height - self.view.frame.size.height / 4 - 30, self.view.frame.size.width, self.view.frame.size.height / 4 + 30)];
    self.upAndDownView.backgroundColor = [UIColor whiteColor];
    self.upAndDownView.hidden = YES;
    
    __weak typeof(self) myself = self;
    //返回block
    [self.upAndDownView setBack:^{
        //上移
        [UIView animateWithDuration:0.5 animations:^{
            myself.upAndDownView.frame = CGRectMake(0, myself.segment.frame.size.height - self.view.frame.size.height / 4 - 30, myself.view.frame.size.width, self.view.frame.size.height / 4 + 30);
        } completion:^(BOOL finished) {
            myself.upAndDownView.hidden = YES;
            myself.selectListView.userInteractionEnabled = YES;
        }];
    }];
    
    //搜索block
    [self.upAndDownView setUpAndDown:^(NSString *name, NSString *flag, NSString *index) {
        //改变segment的标题
        [myself.segment setTitle:name forSegmentAtIndex:myself.upAndDownView.index];
        
        //根据index判断参数是什么
        switch ([index integerValue]) {
            case 0:
            {
                myself.target = flag;
            }
                break;
            case 1:
            {
                myself.scene = flag;
            }
                break;
            case 2:
            {
                myself.personality = flag;
            }
                break;
            case 3:
            {
                myself.price = flag;
            }
                break;
        }
        
        //上移
        [UIView animateWithDuration:0.5 animations:^{
            myself.upAndDownView.frame = CGRectMake(0, myself.segment.frame.size.height - self.view.frame.size.height / 4 - 30, myself.view.frame.size.width, self.view.frame.size.height / 4 + 30);
        } completion:^(BOOL finished) {
            myself.upAndDownView.hidden = YES;
            myself.selectListView.userInteractionEnabled = YES;
            
            
            //动画完成开始解析数据
            //回来的时候把数组置空
            myself.selectArrayDDD = [NSMutableArray array];
            myself.selectListView.selectArray = myself.selectArrayDDD;
            [myself p_setLoading];
            [myself getListSelectData];
        }];
    }];
    [self.backView addSubview:self.upAndDownView];
    
    [[self.topView superview] bringSubviewToFront:self.topView];
    [self.backView bringSubviewToFront:self.segment];
    //解析数据菊花转
    [self p_setLoading];
    [self getSegmentData];
    [self getListData];
    // Do any additional setup after loading the view.
}
#pragma mark  getSegmentData
- (void)getSegmentData {
    self.segmentArray = [NSMutableArray array];
    self.categoryArray = [NSMutableArray array];

    [[AFHTTPRequestOperationManager manager] GET:@"http://api.liwushuo.com/v2/search/item_filter" parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSArray *sourceArray = responseObject[@"data"][@"filters"];
        [self.hud hide:YES];
        //多线程
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
            //上面选项的数据
            for (NSDictionary *dic in sourceArray) {
                [self.categoryArray addObject:dic[@"name"]];
                Filters *filters = [[Filters alloc] init];
                [filters setValuesForKeysWithDictionary:dic];
                [self.segmentArray addObject:filters];
            }
            
            
            dispatch_async(dispatch_get_main_queue(), ^{
                //segment添加分段
                if (self.categoryArray.count != 0) {
                    for (int i = 0; i < self.categoryArray.count; i++) {
                        [self.segment setTitle:self.categoryArray[i] forSegmentAtIndex:i];
                    }
                }
            });
        });
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        self.hud.labelText = @"加载网络失败,请检查网络重试";
        //延时消失
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.hud hide:YES];
        });
    }];
}
#pragma mark getListData默认
- (void)getListData {
    
    [[AFHTTPRequestOperationManager manager] GET:[NSString stringWithFormat:@"http://api.liwushuo.com/v2/search/item_by_type?limit=20&offset=%ld", (unsigned long)self.selectArray.count] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [self.hud hide:YES];
        [self.selectListView.tableView.footer endRefreshing];
        //多线程
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
            //下面tableView的数据
            NSArray *sourceArray = responseObject[@"data"][@"items"];
            for (NSDictionary *dic in sourceArray) {
                GoodsList *goodlist = [[GoodsList alloc] init];
                [goodlist setValuesForKeysWithDictionary:dic];
                [self.selectArray addObject:goodlist];
            }
        
            dispatch_async(dispatch_get_main_queue(), ^{
                self.selectListView.selectArray = self.selectArray;
            });
            
        });
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        self.hud.labelText = @"加载网络失败,请检查网络重试";
        //延时消失
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.hud hide:YES];
            [self.selectListView.tableView.footer endRefreshing];
        });
    }];
}
#pragma mark getListData选择
- (void)getListSelectData{
    self.selectArray = [NSMutableArray array];
    //NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"target", self.target, @"limit",@"20", @"scene", self.scene, @"price", self.price ,@"personality", self.personality, @"offset", @"0", nil];
    [[AFHTTPRequestOperationManager manager] GET:[NSString stringWithFormat:@"http://api.liwushuo.com/v2/search/item_by_type?target=%@&limit=20&scene=%@&price=%@&personality=%@&offset=%ld", self.target, self.scene, self.price, self.personality, (unsigned long)self.selectArrayDDD.count] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [self.hud hide:YES];
        [self.selectListView.tableView.footer endRefreshing];
        //多线程
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
            //下面tableView的数据
            NSArray *sourceArray = responseObject[@"data"][@"items"];
            for (NSDictionary *dic in sourceArray) {
                GoodsList *goodlist = [[GoodsList alloc] init];
                [goodlist setValuesForKeysWithDictionary:dic];
                [self.selectArrayDDD addObject:goodlist];
            }

            dispatch_async(dispatch_get_main_queue(), ^{
                self.selectListView.selectArray = self.selectArrayDDD;
            });
            
        });
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        self.hud.labelText = @"加载网络失败,请检查网络重试";
        //延时消失
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.hud hide:YES];
            [self.selectListView.tableView.footer endRefreshing];
        });
    }];

}
- (void)changeSegment:(UISegmentedControl *)segment {
 
    self.selectListView.userInteractionEnabled = NO;
    self.upAndDownView.hidden = NO;
    [UIView animateWithDuration:0.5 animations:^{
     
        self.upAndDownView.frame = CGRectMake(0, self.segment.frame.size.height, self.view.frame.size.width, self.view.frame.size.height / 4 + 30);
    } completion:^(BOOL finished) {
        
    }];
    self.upAndDownView.index = segment.selectedSegmentIndex;
    self.upAndDownView.filters = self.segmentArray[segment.selectedSegmentIndex];
    self.segment.selectedSegmentIndex = -1;

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    BrandGiftDetailViewController *giftDetailVC = [[BrandGiftDetailViewController alloc] init];
    GoodsList *goodList;
    if (self.selectArray.count == 0) {
         goodList = self.selectArrayDDD[indexPath.row];
    } else {
        goodList = self.selectArray[indexPath.row];
    }
    NSLog(@"%ld, %ld", self.selectArray.count, self.selectArrayDDD.count);
    giftDetailVC.ID = goodList.goodsId;
    [self.navigationController pushViewController:giftDetailVC animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
