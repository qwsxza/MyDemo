//
//  CategoryListController.m
//  MyProject
//
//  Created by M-coppco on 15/11/5.
//  Copyright © 2015年 . All rights reserved.
//

#import "CategoryListController.h"
#import "AFHTTPRequestOperationManager.h"  //解析
#import "BelowView.h"  //下面的视图
#import "StrategyView.h"  //攻略视图
#import "WhaleView.h"  //鲸选视图
#import "Subject.h"  //专题model
#import "Channel.h"  //下面的model
#import "SubjectListController.h"   //专题listcontroller
#import "AllSubjectController.h"  //全部专题
#import "UIColor+AddColor.h"
#import "MJRefresh.h"  //上下拉刷新
#import "MBProgressHUD.h"  //菊花转
#import "SelectController.h"   //选礼神器
#import "SubCategory.h"  //model
#import "WeatherController.h"

@interface CategoryListController ()<UIScrollViewDelegate, UITableViewDelegate>
@property (nonatomic, strong)MBProgressHUD *hud;
@property (nonatomic, strong)BelowView *belowView;  //下面的视图
@property (nonatomic, strong)UIScrollView *scrollView;  //滚动视图
@property (nonatomic, strong)StrategyView *strategyView;  //攻略视图
@property (nonatomic, strong)WhaleView *whaleVeiw;   //鲸选
@property (nonatomic, assign)CGFloat contentY;  //用于判断tableView上下滚动
@property (nonatomic, strong)NSMutableArray *subjectArray;  //专题model数组
@property (nonatomic, strong)NSMutableArray *categoryArray;  //品类
@property (nonatomic, strong)NSMutableArray *objectArray;  //对象
@property (nonatomic, strong)NSMutableArray *occasionArray;  //场合
@property (nonatomic, strong)NSMutableArray *styleArray;  //风格
@property (nonatomic, strong)NSMutableDictionary *whaleDictionary;  //鲸选字典
@property (nonatomic, strong)UIButton *rightButton;  //挑选礼物
@end

@implementation CategoryListController
- (void)p_setLoading {
    self.hud = [[MBProgressHUD alloc]initWithView:self.backView];
    self.hud.frame = self.view.bounds;
    self.hud.minSize = CGSizeMake(100, 100);
    self.hud.mode = MBProgressHUDModeCustomView;
    self.hud.animationType = MBProgressHUDAnimationZoom;
    self.hud.labelText = @"正在加载";
    [self.backView addSubview:self.hud];
    [self.hud show:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.topView.backgroundColor = [UIColor jinjuse];
    
    //选择button
    self.rightButton = [UIButton buttonWithType:(UIButtonTypeCustom)];
    self.rightButton.frame = CGRectMake(self.topView.frame.size.width - self.titleLabel.frame.size.height - 30, self.titleLabel.frame.origin.y, self.titleLabel.frame.size.height, self.titleLabel.frame.size.height);
    [self.rightButton setBackgroundImage:[UIImage imageNamed:@"tiao"] forState:(UIControlStateNormal)];
    [self.rightButton addTarget:self action:@selector(click11:) forControlEvents:(UIControlEventTouchUpInside)];
    [self.topView addSubview:self.rightButton];
    
    //下面的视图
    self.belowView = [[BelowView alloc]initWithFrame:CGRectMake(self.backView.frame.size.width / 4, self.view.frame.size.height / 18 * 17 , self.backView.bounds.size.width / 2, self.view.frame.size.height / 18)];
    [self.view addSubview:self.belowView];
 
    [self.belowView.segment addTarget:self action:@selector(selectSegment:) forControlEvents:(UIControlEventValueChanged)];
    
    self.titleLabel.text = @"推荐";
    
    //滚动视图
    self.scrollView = [[UIScrollView alloc]initWithFrame:self.backView.bounds];
    //攻略视图
    self.strategyView = [[StrategyView alloc]initWithFrame:self.scrollView.bounds];
   
    self.strategyView.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self p_setLoading];
        [self getSubjectData];
        [self getOtherData];
        [self getWhaleData];
    }];
    
    //block  点击专题button切换页面
    __weak typeof(self) myself = self;
    [self.strategyView setToController:^(NSString *subjectId, NSString *title) {
        SubjectListController *subjectVC = [[SubjectListController alloc] init];
        subjectVC.channelId = nil;
        subjectVC.subjectId = subjectId;
        subjectVC.subjectTitle = title;
        [myself.navigationController pushViewController:subjectVC animated:YES];
    }];
    
    //block  点击item切换页面
    [self.strategyView setToControllerC:^(NSString *channelId, NSString *title) {
        SubjectListController *subjectVC = [[SubjectListController alloc] init];
        subjectVC.subjectId = nil;
        subjectVC.channelId = channelId;
        subjectVC.subjectTitle = title;
        [myself.navigationController pushViewController:subjectVC animated:YES];
    }];
    
    //block   判断上下滚动
    [self.strategyView setUp:^{
        [UIView animateWithDuration:1 animations:^{
            //NSLog(@"向上滚动");
            myself.belowView.frame = CGRectMake(self.backView.frame.size.width / 4, myself.view.frame.size.height , myself.backView.bounds.size.width / 2, myself.view.frame.size.height / 18);
        } completion:^(BOOL finished) {
        }];
    }];
    
    [self.strategyView setDown:^{
        [UIView animateWithDuration:1 animations:^{
            //NSLog(@"向下滚动");
            myself.belowView.frame = CGRectMake(self.backView.frame.size.width / 4, myself.view.frame.size.height / 18 * 17 , myself.backView.bounds.size.width / 2, myself.view.frame.size.height / 18);
        } completion:^(BOOL finished) {
            
        }];
    }];
    
    //block  点击查看全部button
    [self.strategyView setAllSubject:^{
        //跳到专题全部页面
        AllSubjectController *allVC = [[AllSubjectController alloc]init];
        [myself.navigationController pushViewController:allVC animated:YES];
    }];
    
    [self.scrollView addSubview:self.strategyView];
    
    
    //鲸选视图
    self.whaleVeiw = [[WhaleView alloc]initWithFrame:CGRectMake(self.scrollView.frame.size.width, 0, self.scrollView.frame.size.width, self.scrollView.frame.size.height)];
    
    self.whaleVeiw.rightTableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self p_setLoading];
        [self getWhaleData];
    }];
    self.whaleVeiw.leftTableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self p_setLoading];
        [self getWhaleData];
    }];
    
    //block   判断上下滚动
    [self.whaleVeiw setUp:^{
        [UIView animateWithDuration:1 animations:^{
            //NSLog(@"向上滚动");
            myself.belowView.frame = CGRectMake(self.backView.frame.size.width / 4, myself.view.frame.size.height , myself.backView.bounds.size.width / 2, myself.view.frame.size.height / 18);
        } completion:^(BOOL finished) {
        }];
    }];
    
    [self.whaleVeiw setDown:^{
        [UIView animateWithDuration:1 animations:^{
            //NSLog(@"向下滚动");
            myself.belowView.frame = CGRectMake(self.backView.frame.size.width / 4, myself.view.frame.size.height / 18 * 17 , myself.backView.bounds.size.width / 2, myself.view.frame.size.height / 18);
        } completion:^(BOOL finished) {
            
        }];
    }];
    
    
    [self.scrollView addSubview:self.whaleVeiw];
    
    self.scrollView.delegate = self;
    self.scrollView.contentSize = CGSizeMake(self.scrollView.frame.size.width * 2, 0);
    
    self.scrollView.pagingEnabled = YES;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    [self.backView addSubview:self.scrollView];
    
    self.contentY = self.strategyView.tableView.contentOffset.y;
    
    
    //解析数据和菊花转

    [self p_setLoading];
    [self getSubjectData];
    [self getOtherData];
    [self getWhaleData];
}
#pragma mark button点击方法
- (void)click11:(UIButton *)button {
    //进入筛选界面
    SelectController *selectVC = [[SelectController alloc] init];
    [self.navigationController pushViewController:selectVC animated:YES];
  
}
#pragma mark segment点击方法
- (void)selectSegment:(UISegmentedControl *)segment {
    switch (segment.selectedSegmentIndex) {
        case 0:
        {
           self.titleLabel.text = @"推荐";
            [self.scrollView setContentOffset:CGPointZero animated:YES];
        }
            break;
        case 1:
        {
            self.titleLabel.text = @"鲸选";
            [self.scrollView setContentOffset:CGPointMake(self.scrollView.frame.size.width, 0) animated:YES];
        }
            break;
    }
}

#pragma mark UIScrollerViewDelegate
//下面两个方法判断scrollerView或者tableView或者collection的滚动方向
//- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
//    self.contentY = scrollView.contentOffset.y;
//}
//
//- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView{
//    //判断tableview上下移动
//    if (((UITableView *)scrollView) == self.strategyView.tableView) {
//        //向下拉  y是负值
//        if (self.contentY < scrollView.contentOffset.y) {
//           
//            [UIView animateWithDuration:1 animations:^{
//                NSLog(@"向上滚动");
//                self.belowView.frame = CGRectMake(0, self.view.frame.size.height , self.backView.bounds.size.width, self.view.frame.size.height / 18);
//            } completion:^(BOOL finished) {
//            }];
//        } else {
//            //上拉
//            [self.view bringSubviewToFront:self.belowView];
//            self.belowView.hidden = NO;
//            [UIView animateWithDuration:1 animations:^{
//                NSLog(@"向下滚动");
//                self.belowView.frame = CGRectMake(0, self.view.frame.size.height / 18 * 17 , self.backView.bounds.size.width, self.view.frame.size.height / 18);
//            } completion:^(BOOL finished) {
//                
//            }];
//        }
//    }
//}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView {
    //判断scrollerView左右移动
    CGFloat width = self.scrollView.bounds.size.width;
    if (scrollView.contentOffset.x / width == 0) {
        self.belowView.segment.selectedSegmentIndex = 0;
        self.titleLabel.text = @"推荐";
    }
    if (scrollView.contentOffset.x / width == 1) {
        self.belowView.segment.selectedSegmentIndex = 1;
        self.titleLabel.text = @"鲸选";
    }
    
}

#pragma mark 解析专题数据
- (void)getSubjectData {
    self.subjectArray = [NSMutableArray array];
    [[AFHTTPRequestOperationManager manager] GET:@"http://api.liwushuo.com/v2/collections?limit=6&offset=0" parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [self.hud hide:YES];
        [self.strategyView.tableView.header endRefreshing];
        NSArray *array = responseObject[@"data"][@"collections"];
        //多线程
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
            for (NSDictionary *dic in array) {
                Subject *subject = [[Subject alloc]init];
                [subject setValuesForKeysWithDictionary:dic];
                
                [self.subjectArray addObject:subject];
            }
            
            dispatch_async(dispatch_get_main_queue(), ^{
                //回主线程刷新数据
                NSLog(@"111111");
                self.strategyView.subjectArray = self.subjectArray;
            });
            
        });
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"aaaaaaa");
        self.hud.labelText = @"加载网络失败,请检查网络重试";
        //延时消失
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.hud hide:YES];
        });
        [self.strategyView.tableView.header endRefreshing];

    }];
}

#pragma mark 解析下面数据
- (void)getOtherData {
    self.categoryArray = [NSMutableArray array];
    self.objectArray = [NSMutableArray array];
    self.occasionArray = [NSMutableArray array];
    self.styleArray = [NSMutableArray array];
    
    
    [[AFHTTPRequestOperationManager manager] GET:@"http://api.liwushuo.com/v2/channel_groups/all" parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSArray *array0 = responseObject[@"data"][@"channel_groups"][0][@"channels"];
        NSArray *array1 = responseObject[@"data"][@"channel_groups"][1][@"channels"];
        NSArray *array2 = responseObject[@"data"][@"channel_groups"][2][@"channels"];
        //NSArray *array3 = responseObject[@"data"][@"channel_groups"][3][@"channels"];
        [self.hud hide:YES];
        [self.strategyView.tableView.header endRefreshing];
        //分组提交方式
        //创建并行队列
        dispatch_queue_t queue = dispatch_queue_create("queue", DISPATCH_QUEUE_CONCURRENT);
        //创建分组
        dispatch_group_t group = dispatch_group_create();
        //分组提交
        dispatch_group_async(group, queue, ^{
            //第一个cell//多线程  品类
            for (NSDictionary *dic in array0) {
                Channel *channel = [[Channel alloc]init];
                [channel setValuesForKeysWithDictionary:dic];
                
                [self.categoryArray addObject:channel];
            }
            
        });
        
        dispatch_group_async(group, queue, ^{
            //多线程 对象
            for (NSDictionary *dic in array1) {
                Channel *channel = [[Channel alloc]init];
                [channel setValuesForKeysWithDictionary:dic];
                
                [self.objectArray addObject:channel];
            }
        });
        
        dispatch_group_async(group, queue, ^{
            //多线程  场合
            for (NSDictionary *dic in array2) {
                Channel *channel = [[Channel alloc]init];
                [channel setValuesForKeysWithDictionary:dic];
                
                [self.occasionArray addObject:channel];
            }
        });
       /*
        dispatch_group_async(group, queue, ^{
            //多线程  风格
            for (NSDictionary *dic in array3) {
                Channel *channel = [[Channel alloc]init];
                [channel setValuesForKeysWithDictionary:dic];
                [self.styleArray addObject:channel];
            }
        });
        */
        //会主线程刷新数据
        dispatch_group_notify(group, dispatch_get_main_queue(), ^{
            NSLog(@"222222");
            [self.strategyView setFourArrayWithCategoryArray:self.categoryArray objectArray:self.objectArray occasionArray:self.occasionArray styleArray:self.styleArray];
        });

        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        self.hud.labelText = @"加载网络失败,请检查网络重试";
        NSLog(@"bbbbbbb");
        //延时消失
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.hud hide:YES];
        });
        [self.strategyView.tableView.header endRefreshing];
        
  
    }];
}
#pragma mark getWhaleData 
- (void)getWhaleData {
    self.whaleDictionary = [NSMutableDictionary dictionary];
    [[AFHTTPRequestOperationManager manager] GET:[NSString stringWithFormat:@"%@", @"http://api.liwushuo.com/v2/item_categories/tree"] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSArray *array = responseObject[@"data"][@"categories"];
        
        [self.hud hide:YES];
        [self.whaleVeiw.rightTableView.header endRefreshing];
        [self.whaleVeiw.leftTableView.header endRefreshing];
        //多线程  鲸选
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
            //分类名称
            for (NSDictionary *dic in array) {
                NSString *string = [NSString stringWithFormat:@"%@", dic[@"id"]].length == 1 ? [NSString stringWithFormat:@"0%@%@", dic[@"id"], dic[@"name"]] : [NSString stringWithFormat:@"%@%@", dic[@"id"], dic[@"name"]];
                NSMutableArray *array = [NSMutableArray array];
            
                for (NSDictionary *dic1 in dic[@"subcategories"]) {
                    SubCategory *subCategory = [[SubCategory alloc] init];
                    [subCategory setValuesForKeysWithDictionary:dic1];
                    [array addObject:subCategory];
                }
                [self.whaleDictionary setObject:array forKey:string];
            }
            
            //回主线程刷新
            dispatch_async(dispatch_get_main_queue(), ^{
                self.whaleVeiw.whaleDictionary = self.whaleDictionary;
            });
            
        });
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        //延时消失
        self.hud.labelText = @"加载失败,请检测网络重试";
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.hud hide:YES];
        });
        [self.whaleVeiw.rightTableView.header endRefreshing];
        [self.whaleVeiw.leftTableView.header endRefreshing];
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
