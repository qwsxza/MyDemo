//
//  AllSubjectController.m
//  MyProject
//
//  Created by M-coppco on 15/11/6.
//  Copyright © 2015年 . All rights reserved.
//

#import "AllSubjectController.h"
#import "UIColor+AddColor.h"
#import "AFHTTPRequestOperationManager.h"
#import "Subject.h"  //model
#import "AllSubjectCell.h"  //自定义cell
#import "MBProgressHUD.h"  //菊花转
#import "MJRefresh.h"  //上下拉刷新
#import "SubjectListController.h"  //列表视图

@interface AllSubjectController ()<UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong)UITableView *tableView;  //集合视图
@property (nonatomic, strong)MBProgressHUD *hud;
@property (nonatomic, strong)NSMutableArray *modelArray;
@end

@implementation AllSubjectController

- (void)p_setLoading {
    self.hud = [[MBProgressHUD alloc]initWithView:self.backView];
    self.hud.frame = self.view.bounds;
    self.hud.minSize = CGSizeMake(100, 100);
    self.hud.mode = MBProgressHUDModeCustomView;
    self.hud.animationType = MBProgressHUDAnimationZoom;
    self.hud.labelText = @"正在加载";
    [self.backView addSubview:self.hud];
    [self.hud show:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.modelArray = [NSMutableArray array];
    self.titleLabel.text = @"全部专题";
    self.topView.backgroundColor = [UIColor jinjuse];
    
    self.tableView = [[UITableView alloc] initWithFrame:self.backView.bounds style:(UITableViewStylePlain)];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    
    self.tableView.rowHeight = self.backView.frame.size.height / 3.3;
    [self.backView addSubview:self.tableView];
    
    //上拉刷新
    __block int i = 20;
    self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        if (i <= 120) {
            [self p_setLoading];
            [self getAllSubjectDataWithOffset:i];
        }
        i+=20;
    }];
    
    //
    [self p_setLoading];
    [self getAllSubjectDataWithOffset:0];
    
    // Do any additional setup after loading the view.
}
#pragma mark 解析数据
- (void)getAllSubjectDataWithOffset:(NSInteger)i {
   
    [[AFHTTPRequestOperationManager manager] GET:[NSString stringWithFormat:@"http://api.liwushuo.com/v2/collections?limit=20&offset=%ld", (long)i] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSArray *array = responseObject[@"data"][@"collections"];
        [self.hud hide:YES];
        [self.tableView.footer endRefreshing];
        //多线程
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
            for (NSDictionary *dic in array) {
                Subject *subject = [[Subject alloc]init];
                [subject setValuesForKeysWithDictionary:dic];
                
                [self.modelArray addObject:subject];
            }
            
            dispatch_async(dispatch_get_main_queue(), ^{
                //回主线程刷新数据
                [self.tableView reloadData];
            });
            
        });
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        self.hud.labelText = @"加载网络失败,请检查网络重试";
        [self.tableView.footer endRefreshing];
        //延时消失
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.hud hide:YES];
        });
    }];
}
#pragma mark UITableViewDatasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.modelArray.count;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    AllSubjectCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[AllSubjectCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:@"cell"];
    }
    cell.subject = self.modelArray[indexPath.row];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    Subject *subject = self.modelArray[indexPath.row];
    SubjectListController *subjectVC = [[SubjectListController alloc] init];
    subjectVC.channelId = nil;
    subjectVC.subjectId = subject.subjectId;
    subjectVC.subjectTitle = subject.title;
    [self.navigationController pushViewController:subjectVC animated:YES];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
