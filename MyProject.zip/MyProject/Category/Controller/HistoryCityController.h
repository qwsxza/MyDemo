//
//  HistoryCithController.h
//  MyProject
//
//  Created by M-coppco on 15/11/16.
//  Copyright © 2015年 . All rights reserved.
//

#import "ViewController.h"
@class City1;
@interface HistoryCityController : ViewController

@property (nonatomic, copy)void (^changeCity)(City1 *city1);

@end
