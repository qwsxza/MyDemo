//
//  SubjectListController.h
//  MyProject
//
//  Created by M-coppco on 15/11/6.
//  Copyright © 2015年 . All rights reserved.
//

#import "ViewController.h"

@interface SubjectListController : ViewController

@property (nonatomic, copy)NSString *subjectId;  //专题button按钮
@property (nonatomic, copy)NSString *subjectTitle;

@property (nonatomic, copy)NSString *channelId;  //item点击事件
@property (nonatomic, copy)NSString *channelTitle;  //
@end
