//
//  SubjectDetailController.m
//  MyProject
//
//  Created by M-coppco on 15/11/6.
//  Copyright © 2015年 . All rights reserved.
//

#import "SubjectDetailController.h"
#import "UIImageView+WebCache.h"
#import "UIColor+AddColor.h"
#import "MBProgressHUD.h"  //菊花转

#define KLeft 10
#define KTop 10
#define KV 10

@interface SubjectDetailController ()<UIScrollViewDelegate, UIWebViewDelegate>

@property (nonatomic, strong)UILabel *nameLabel;  //标题
@property (nonatomic, strong)UIWebView *web;

@property (nonatomic, assign)CGFloat contentY;
@property (nonatomic, strong)MBProgressHUD *hud;

@end

@implementation SubjectDetailController
- (void)p_setLoading {
    self.hud = [[MBProgressHUD alloc]initWithView:self.backView];
    self.hud.frame = self.view.bounds;
    self.hud.minSize = CGSizeMake(100, 100);
    self.hud.mode = MBProgressHUDModeCustomView;
    self.hud.animationType = MBProgressHUDAnimationZoom;
    self.hud.labelText = @"正在加载";
    [self.backView addSubview:self.hud];
    [self.hud show:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.topView.backgroundColor = [UIColor jinjuse];
    self.titleLabel.text = @"推荐详情";
    //滚动视图
    //标题和web加到scrollView中
    self.nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(KLeft, KTop, self.backView.frame.size.width - 2 * KLeft, 40)];
    self.nameLabel.numberOfLines = 0;
    self.nameLabel.font = [UIFont systemFontOfSize:22 weight:1];
    self.nameLabel.text = self.longTitle;
    [self.nameLabel sizeToFit];
    
    [self.backView addSubview:self.nameLabel];
    
    self.web = [[UIWebView alloc]initWithFrame:CGRectMake(0, self.nameLabel.frame.size.height + KTop + KV, self.backView.frame.size.width, self.backView.frame.size.height - self.nameLabel.frame.size.height - KTop - KV)];
    self.web.delegate = self;
    self.web.userInteractionEnabled = YES;
    self.web.backgroundColor = [UIColor whiteColor];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:self.contentUrl] cachePolicy:0 timeoutInterval:10];
    
    [self.web loadRequest:request];
    [self.backView addSubview:self.web];
    // Do any additional setup after loading the view.
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [self.hud hide:YES];
}
-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
//    self.hud.labelText = @"加载网络失败,请检查网络重试";
//    //延时消失
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.hud hide:YES];
    });
}
-(void)webViewDidStartLoad:(UIWebView *)webView {
    [self p_setLoading];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
