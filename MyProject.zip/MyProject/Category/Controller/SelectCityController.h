//
//  SelectCityController.h
//  MyProject
//
//  Created by M-coppco on 15/11/13.
//  Copyright © 2015年 . All rights reserved.
//

#import "ViewController.h"
@class City;
@interface SelectCityController : ViewController

@property (nonatomic, copy)void (^myBlock)(City *city);
@end
