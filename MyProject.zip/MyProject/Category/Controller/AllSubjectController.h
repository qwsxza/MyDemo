//
//  AllSubjectController.h
//  MyProject
//
//  Created by M-coppco on 15/11/6.
//  Copyright © 2015年 . All rights reserved.
//

#import "ViewController.h"

@interface AllSubjectController : ViewController

@end
