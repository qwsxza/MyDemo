//
//  SubjectDetailController.h
//  MyProject
//
//  Created by M-coppco on 15/11/6.
//  Copyright © 2015年 . All rights reserved.
//

#import "ViewController.h"

@interface SubjectDetailController : ViewController
@property (nonatomic, copy)NSString *contentUrl; //内容地址
@property (nonatomic, copy)NSString *imageUrl;  //图片地址
@property (nonatomic, copy)NSString *longTitle;  //长标题
@end
