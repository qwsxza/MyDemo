//
//  WeatherController.m
//  MyProject
//
//  Created by M-coppco on 15/11/12.
//  Copyright © 2015年 . All rights reserved.
//

#import "WeatherController.h"
#import "SelectCityController.h"  //选择城市
#import "City.h"
#import "AFNetworking.h"
#import "UIImageView+WebCache.h"
#import "WeatherTopCell.h"  //最上面cell
#import "WeatherTipsCell.h"  //提醒cell
#import "MoreDayCell.h"  //未来天气cell
#import "WindAndHumidityCell.h"  //cell
#import "ZhiShuCell.h"  //指数cell
#import "WeatherTop.h"  //model上面的model
#import "WeatherTips.h"  //提醒model
#import "FutureWeather.h"  //未来天气model
#import "ZhishuModel.h"  //指数model
#import "WindAndHumidity.h" // model
#import "UIColor+AddColor.h"
#import "HistoryCityController.h"
#import "UIColor+AddColor.h"
#import <CoreData/CoreData.h>  //coreData
#import "City1.h"  //model
#import "AppDelegate.h"
#import "MJRefresh.h"
#import "MBProgressHUD.h"  //菊花转

@interface WeatherController ()<UITableViewDataSource, UITableViewDelegate, UIAlertViewDelegate>
@property (nonatomic, strong)MBProgressHUD *hud;

@property (nonatomic, strong)UIButton *locationButton;  //定位button

@property (nonatomic, strong)UITableView *tableView;  //表视图

@property (nonatomic, strong)UIImageView *backImageView;  //背景图片

@property (nonatomic, strong)WeatherTop *weatherTop;  //上面的model
@property (nonatomic ,strong)WeatherTips *weatherTips;  //提醒model

@property (nonatomic, strong)CAEmitterLayer *snowEmitter;  //动画
@property (nonatomic, strong)CAEmitterCell *snowflake;

@property (nonatomic, strong)NSMutableArray *futureArray;  //未来天气数组
@property (nonatomic, strong)NSMutableArray *zhiShuArray;  //指数
@property (nonatomic, strong)WindAndHumidity *windAndHumidity;  //model

@property (nonatomic, strong)NSMutableArray *array;
@property (nonatomic, strong)NSMutableArray *array1;

@property (nonatomic, strong)UIButton *historyButton;
@property (nonatomic, strong)City *city;
@property (nonatomic, retain)NSManagedObjectContext *manageObjectContext; //  上下文

@end

@implementation WeatherController
- (void)p_setLoading {
    self.hud = [[MBProgressHUD alloc]initWithView:self.backView];
    self.hud.frame = self.view.bounds;
    self.hud.minSize = CGSizeMake(100, 100);
    self.hud.mode = MBProgressHUDModeCustomView;
    self.hud.animationType = MBProgressHUDAnimationZoom;
    self.hud.labelText = @"正在加载";
    [self.backView addSubview:self.hud];
    [self.hud show:YES];
}
- (void)getAnimationWith:(NSString *)string {
    _snowEmitter = [CAEmitterLayer layer];
    _snowEmitter.emitterPosition = CGPointMake(self.backImageView.bounds.size.width / 2.0, -30);
    _snowEmitter.emitterSize		= CGSizeMake(self.backImageView.bounds.size.width , 0.0);;
    
    // Spawn points for the flakes are within on the outline of the line
    _snowEmitter.emitterMode		= kCAEmitterLayerOutline;
    _snowEmitter.emitterShape	= kCAEmitterLayerLine;
    
    // Configure the snowflake emitter cell
    _snowflake = [CAEmitterCell emitterCell];
    _snowflake.birthRate		= 2.0;   //粒子发射速率
    if ([self.weatherTop.tname containsString:@"小"] || [self.weatherTop.tname containsString:@"阵"]) {
        _snowflake.birthRate		= 2.0;   //粒子发射速率
    }
    if ([self.weatherTop.tname containsString:@"中"]) {
        _snowflake.birthRate		= 4.0;   //粒子发射速率
    }
    if ([self.weatherTop.tname containsString:@"大"]) {
        _snowflake.birthRate		= 6.0;   //粒子发射速率
    }
    if ([self.weatherTop.tname containsString:@"暴"]) {
        _snowflake.birthRate		= 10.0;   //粒子发射速率
    }
    _snowflake.lifetime		= 10.0;  //生命周期
    
    _snowflake.velocity		= -100;				// falling down slowly

    if ([string  isEqual: @"DazFlake"]) {
        _snowflake.lifetime		= 50.0;  //生命周期
        _snowflake.velocity		= -10;				// falling down slowly速度
        _snowflake.velocityRange = 10;
        _snowflake.yAcceleration = 2;
        _snowflake.emissionRange = 0.5 * M_PI;		// some variation in angle
        _snowflake.spinRange		= 0.25 * M_PI;		// slow spin
    }
    
    _snowflake.contents		= (id) [[UIImage imageNamed:string] CGImage];
    _snowflake.color			= [[UIColor colorWithRed:0.600 green:0.658 blue:0.743 alpha:1.000] CGColor];
    
    // Make the flakes seem inset in the background
    _snowEmitter.shadowOpacity = 1.0;
    _snowEmitter.shadowRadius  = 0.0;
    _snowEmitter.shadowOffset  = CGSizeMake(0.0, 1.0);
    _snowEmitter.shadowColor   = [[UIColor whiteColor] CGColor];
    
    // Add everything to our backing layer below the UIContol defined in the storyboard
    _snowEmitter.emitterCells = [NSArray arrayWithObject:_snowflake];
    [self.backImageView.layer insertSublayer:_snowEmitter atIndex:0];
   
}
//获取城市名字  如果选择过从本地取
- (void)getCity {
    //①反归档data
    NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:@"city"];
    if (data != nil) {
        //②创建反归档对象 NSKeyedUnarchiver
        NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc]initForReadingWithData:data];
        //③进行解码, 反归档
        City *city = [unarchiver decodeObjectForKey:@"city"];
        //④结束解码
        [unarchiver finishDecoding];
        self.city = city;
        [self.locationButton setTitle:city.name forState:(UIControlStateNormal)];
        //菊花转和解析数据
        [self p_setLoading];
        [self getWeatherDataWith:city];
    } else {
        [self.locationButton setTitle:@"选择城市" forState:(UIControlStateNormal)];
        
        if ([[UIDevice currentDevice].systemVersion floatValue] == 7.0) {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:@"你还没去定位,是否现在去定位?" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
            [alertView show];
        } else {
            UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"提示" message:@"你还没去定位,是否现在去定位?" preferredStyle:(UIAlertControllerStyleAlert)];
            UIAlertAction *actionSure = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
                [self selectCity:nil];
            }];
            UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:@"取消" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
                
            }];
            [alertVC addAction:actionCancel];
            [alertVC addAction:actionSure];
            [self presentViewController:alertVC animated:YES completion:nil];
        }

    }
}
#pragma mark UIAlertView
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    switch (buttonIndex) {
        case 0:
        {
            
        }
            break;
            
        case 1:
        {
            [self selectCity:nil];
        }
            break;
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];

    //点击上面导航栏返回键的时候 重新置初值
    self.topView.backgroundColor = [UIColor jinjuse];
    //在程序的任何地方都可以获取appdelegate ,它是一个单例
    //获取到AppDelegate中的临时数据库  coreData用到的
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    self.manageObjectContext = appDelegate.managedObjectContext;
    
    
    self.array = [@[@"提醒", @"多日天气", @"生活指数", @"风力和湿度"] mutableCopy];
    self.array1 = [@[@"多日天气", @"生活指数", @"风力和湿度"] mutableCopy];
    self.view.backgroundColor = [UIColor whiteColor];
    self.locationButton = [UIButton buttonWithType:(UIButtonTypeCustom)];
    self.locationButton.frame = self.titleLabel.frame;
    [self.topView addSubview:self.locationButton];
    
    
    //历史button
    self.historyButton = [UIButton buttonWithType:(UIButtonTypeCustom)];
    self.historyButton.frame = CGRectMake(self.topView.frame.size.width - self.titleLabel.frame.size.height- 30, self.titleLabel.frame.origin.y, self.titleLabel.frame.size.height, self.titleLabel.frame.size.height);
    [self.historyButton setBackgroundImage:[UIImage imageNamed:@"history11"] forState:(UIControlStateNormal)];
    [self.historyButton addTarget:self action:@selector(historyButton:) forControlEvents:(UIControlEventTouchUpInside)];
    [self.topView addSubview:self.historyButton];
    
    [self.locationButton addTarget:self action:@selector(selectCity:) forControlEvents:(UIControlEventTouchUpInside)];
    
    self.backImageView = [[UIImageView alloc] initWithFrame:self.backView.bounds];
    self.backImageView.userInteractionEnabled = YES;
    self.backImageView.contentMode = UIViewContentModeScaleAspectFill;
    [self.backImageView.layer removeAllAnimations];
    [self.backView addSubview:self.backImageView];
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, -20, self.backView.frame.size.width, self.backView.frame.size.height + 20) style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    //下拉刷新
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        if (self.city != nil) {
            [self p_setLoading];
            //移除动画
            [_snowEmitter removeFromSuperlayer];
            [self getWeatherDataWith:self.city];
        }
    }];
    
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.1];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.backImageView addSubview:self.tableView];
    
    [[self.topView superview] bringSubviewToFront:self.topView];
    
    [self getCity];
    self.tableView.userInteractionEnabled = NO;
}
- (void)historyButton:(UIButton *)button {
    HistoryCityController *historyVC = [[HistoryCityController alloc] init];
    [historyVC setChangeCity:^(City1 *city1) {
        City *city11 = [[City alloc] init];
        city11.name = city1.name;
        city11.tip = city1.tip;
        city11.cityId = city1.cityId;
        city11.districtName = city1.districtName;
    
        if (![self.city.cityId isEqualToString:city11.cityId]) {
            //移除动画
            [self.snowEmitter removeFromSuperlayer];

            [self.locationButton setTitle:city11.name forState:(UIControlStateNormal)];
            [self p_setLoading];
            [self getWeatherDataWith:city11];
            self.city = city11;
            //写入NSUserDefault
            [self writeToNSUserDefaultWith:city11];
        } else {
            //这里因为在viewDidDisappear移除了动画效果,所以需要增加效果
//            if ([self.weatherTop.tname containsString:@"雪"]) {
//                [self getAnimationWith:@"DazFlake"];
//            }
//            if ([self.weatherTop.tname containsString:@"雨"]) {
//                [self getAnimationWith:@"雨"];
//            }
        }
        //把tableView滚动最上面
        [self.tableView setContentOffset:CGPointZero animated:YES];
    }];
    [self.navigationController pushViewController:historyVC animated:YES];
}
//点击选择城市button
- (void)selectCity:(UIButton *)button {
    SelectCityController *selectVC = [[SelectCityController alloc] init];
    [selectVC setMyBlock:^(City *city) {
        if (![self.city.cityId isEqualToString:city.cityId]) {
            //移除动画
            [self.snowEmitter removeFromSuperlayer];

            
            [self.locationButton setTitle:city.name forState:(UIControlStateNormal)];
            //存到数据库
            [self searchWith:city] == NO ? [self addCityWith:city] : nil;
            [self p_setLoading];
            [self getWeatherDataWith:city];
            self.city = city;
            //写入NSUserDefault
            [self writeToNSUserDefaultWith:city];
        } else {
            //这里因为在viewDidDisappear移除了动画效果,所以需要增加效果
//            if ([self.weatherTop.tname containsString:@"雪"]) {
//                [self getAnimationWith:@"DazFlake"];
//            }
//            if ([self.weatherTop.tname containsString:@"雨"]) {
//                [self getAnimationWith:@"雨"];
//            }
        }
        //把tableView滚动最上面
        [self.tableView setContentOffset:CGPointZero animated:YES];
    }];
    [self presentViewController:selectVC animated:YES completion:nil];
}
#pragma mark 写入nsuserdefault
- (void)writeToNSUserDefaultWith:(City *)city {
    //①创建NSMutableData 对象
    NSMutableData *mutableData = [NSMutableData data];
    //②创建归档对象,初始化时指定对应的NSMutableData对象
    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc]initForWritingWithMutableData:mutableData];
    //③开始编码
    [archiver encodeObject:city forKey:@"city"];
    //④结束编码
    [archiver finishEncoding];
    [[NSUserDefaults standardUserDefaults] setValue:mutableData forKey:@"city"];
}
#pragma mark coreData添加数据
- (void)addCityWith:(City *)city {
    //先生成一个null的对象
    City1 *city1 = [NSEntityDescription insertNewObjectForEntityForName:@"City1" inManagedObjectContext:self.manageObjectContext];
    city1.districtName = city.districtName;
    city1.cityId = city.cityId;
    city1.name = city.name;
    city1.tip = city.tip;
    //一定要保存
    [self.manageObjectContext save:nil];
}
#pragma mark  coreData查找数据
- (BOOL)searchWith:(City *)city {
    //请求
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"City1"];
    //谓词
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"cityId CONTAINS %@", city.cityId]; //一定要加单引号
    request.predicate = predicate;
    NSError *error;
    NSArray *array = [self.manageObjectContext executeFetchRequest:request error:&error];
    return array.count == 0 ? NO : YES;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)getWeatherDataWith:(City *)city {
    NSString *url = [[NSString stringWithFormat:@"http://tq.91.com/api/?act=210&city=%@&cityName=%@&isfamily=0&mt=4&sv=3.13.3&osv=4.4.2&imei=863990022601940&dm=HM+NOTE+1TD&nt=10&CUID=F285040327F1AF69B3DC31842F407501%@7C049106220099368&pid=115&chl=1010791a", city.cityId, city.name, @"%"] stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    NSLog(@"%@", url);
    [[AFHTTPRequestOperationManager manager] GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
      
        
        [self.hud hide:YES];
        [self.tableView.header endRefreshing];
        //分组提交方式
        //创建并行队列
        dispatch_queue_t queue = dispatch_queue_create("queue", DISPATCH_QUEUE_CONCURRENT);
        //创建分组
        dispatch_group_t group = dispatch_group_create();
        //分组提交
        dispatch_group_async(group, queue, ^{
            //第一个cell
            WeatherTop *weatherTop = [[WeatherTop alloc] init];
            [weatherTop setValuesForKeysWithDictionary:responseObject[@"items"][0]];

            self.weatherTop = weatherTop;

        });
        dispatch_group_async(group, queue, ^{
            //提醒
            NSDictionary *dic = responseObject[@"items"][2];
            if ([[dic allKeys] containsObject:@"male"]) {
            
                WeatherTips *weatherTips = [[WeatherTips alloc] init];
                [weatherTips setValuesForKeysWithDictionary:responseObject[@"items"][2]];
                self.weatherTips = weatherTips;
            } else {
                self.weatherTips = nil;
            }
        });
        dispatch_group_async(group, queue, ^{
            self.futureArray = [NSMutableArray array];
            if (((NSArray *)responseObject[@"items"]).count == 9) {
                //未来天气
                NSArray *array = responseObject[@"items"][5][@"future"][@"items"];
                for (NSDictionary *dic in array) {
                    FutureWeather *futherW = [[FutureWeather alloc] init];
                    [futherW setValuesForKeysWithDictionary:dic];
                    [self.futureArray addObject:futherW];
                }
            }
            if (((NSArray *)responseObject[@"items"]).count == 8) {
                //未来天气
                NSArray *array = responseObject[@"items"][4][@"future"][@"items"];
                for (NSDictionary *dic in array) {
                    FutureWeather *futherW = [[FutureWeather alloc] init];
                    [futherW setValuesForKeysWithDictionary:dic];
                    [self.futureArray addObject:futherW];
                }
            }
            if (((NSArray *)responseObject[@"items"]).count == 7) {
                //未来天气
                NSArray *array = responseObject[@"items"][3][@"future"][@"items"];
                for (NSDictionary *dic in array) {
                    FutureWeather *futherW = [[FutureWeather alloc] init];
                    [futherW setValuesForKeysWithDictionary:dic];
                    [self.futureArray addObject:futherW];
                }
            }
        });
        dispatch_group_async(group, queue, ^{
            self.zhiShuArray = [NSMutableArray array];
            if (((NSArray *)responseObject[@"items"]).count == 9) {
                //指数
                NSArray *array1 = responseObject[@"items"][6][@"items"];
                for (NSDictionary *dic in array1) {
                    ZhishuModel *zhiShu = [[ZhishuModel alloc] init];
                    [zhiShu setValuesForKeysWithDictionary:dic];
                    [self.zhiShuArray addObject:zhiShu];
                }
            }
            if (((NSArray *)responseObject[@"items"]).count == 8) {
                //指数
                NSArray *array1 = responseObject[@"items"][5][@"items"];
                for (NSDictionary *dic in array1) {
                    ZhishuModel *zhiShu = [[ZhishuModel alloc] init];
                    [zhiShu setValuesForKeysWithDictionary:dic];
                    [self.zhiShuArray addObject:zhiShu];
                }
            }
            if (((NSArray *)responseObject[@"items"]).count == 7) {
                //指数
                NSArray *array1 = responseObject[@"items"][4][@"items"];
                for (NSDictionary *dic in array1) {
                    ZhishuModel *zhiShu = [[ZhishuModel alloc] init];
                    [zhiShu setValuesForKeysWithDictionary:dic];
                    [self.zhiShuArray addObject:zhiShu];
                }
            }
            });
        
        dispatch_group_async(group, queue, ^{
            //风力和湿度
            if (((NSArray *)responseObject[@"items"]).count == 9) {
                NSDictionary *dic = responseObject[@"items"][7];
                WindAndHumidity *windAndHumidity = [[WindAndHumidity alloc] init];
                [windAndHumidity setValuesForKeysWithDictionary:dic];
                self.windAndHumidity = windAndHumidity;
            }
            if (((NSArray *)responseObject[@"items"]).count == 8) {
                NSDictionary *dic = responseObject[@"items"][6];
                WindAndHumidity *windAndHumidity = [[WindAndHumidity alloc] init];
                [windAndHumidity setValuesForKeysWithDictionary:dic];
                self.windAndHumidity = windAndHumidity;
            }
            if (((NSArray *)responseObject[@"items"]).count == 7) {
                NSDictionary *dic = responseObject[@"items"][5];
                WindAndHumidity *windAndHumidity = [[WindAndHumidity alloc] init];
                [windAndHumidity setValuesForKeysWithDictionary:dic];
                self.windAndHumidity = windAndHumidity;
            }
        });
        //最后执行,等前面的执行完成才会刷新UI(回到主线程)
        dispatch_group_notify(group, dispatch_get_main_queue(), ^{
            //刷新数据
            [self.tableView reloadData];
            [self.backImageView sd_setImageWithURL:[NSURL URLWithString:self.weatherTop.clear] placeholderImage:nil];
            
            if ([self.weatherTop.tname containsString:@"雪"] && ![self.weatherTop.tname containsString:@"雨"]) {
                NSLog(@"雪");
                [self getAnimationWith:@"DazFlake"];
            }
            if ([self.weatherTop.tname containsString:@"雨"] && ![self.weatherTop.tname containsString:@"雪"]) {
                NSLog(@"雨");
                [self getAnimationWith:@"雨"];
            }
            if ([self.weatherTop.tname containsString:@"雨"] && [self.weatherTop.tname containsString:@"雪"]) {
                NSLog(@"雪1");

                [self getAnimationWith:@"DazFlake"];
            }
        });
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        //延时消失
        self.hud.labelText = @"加载失败,请检测网络重试";
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.hud hide:YES];
        });
        [self.tableView.header endRefreshing];
    }];
}
#pragma mark UITabelView
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
  
    return self.weatherTips == nil ? 4 : 5;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if ((self.weatherTips != nil && section == 2) || (self.weatherTips == nil && section == 1)) {
        return self.futureArray.count;
    } else {
        return 1;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return self.backView.frame.size.height;
    }
    //有提醒的时候
    if (self.weatherTips != nil) {
        if (indexPath.section == 1) {
            return self.backImageView.frame.size.height / 5 + 5;
        }
        if (indexPath.section == 2) {
            return self.backImageView.bounds.size.width / 5;
        }
        if (indexPath.section == 3) {
            return (self.backImageView.bounds.size.width / 5 + 2) * (self.zhiShuArray.count % 2 == 0 ? self.zhiShuArray.count / 2 : (self.zhiShuArray.count / 2 + 1)) - 2;
        }
        if (indexPath.section == 4) {
            return self.backImageView.frame.size.width / 5;
        }
    } else {
        if (indexPath.section == 1) {
            return self.backImageView.bounds.size.width / 5;
        }
        if (indexPath.section == 2) {
            return (self.backImageView.bounds.size.width / 5 + 2) * (self.zhiShuArray.count % 2 == 0 ? self.zhiShuArray.count / 2 : (self.zhiShuArray.count / 2 + 1));
        }
        if (indexPath.section == 3) {
            return self.backImageView.frame.size.width / 5;
        }
    }
    return 1000;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        //第一行cell
        static NSString *reuse = @"WeatherTopCell";
        WeatherTopCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
        if (!cell) {
            cell = [[WeatherTopCell alloc] initWithStyle:(UITableViewCellStyleValue2) reuseIdentifier:reuse];
        }
        
        if (self.weatherTop != nil) {
            cell.weatherTop = self.weatherTop;
        }
        return cell;
    }
    if (indexPath.section == 1 && self.weatherTips != nil) {
        //提醒cell
            static NSString *reuse = @"WeatherTipsCell";
            WeatherTipsCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
            if (!cell) {
                cell = [[WeatherTipsCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:reuse];
            }
            if (self.weatherTips != nil) {
                cell.weatherTips = self.weatherTips;
            }
            return cell;
    }
    if ((indexPath.section == 2 && self.weatherTips != nil) || (indexPath.section == 1 && self.weatherTips == nil)) {
        //多日天气
        static NSString *reuse = @"MoreDayCell";
        MoreDayCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
        if (!cell) {
            cell = [[MoreDayCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:reuse];
        }
        if (self.futureArray.count != 0) {
            cell.futureWeather = self.futureArray[indexPath.row];
        }
        switch (indexPath.row % 2) {
            case 0:
            {
                cell.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.6];
            }
                break;
            case 1:
            {
                cell.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.4];
            }
                break;
        }
        return cell;
    }
    if ((indexPath.section == 3 && self.weatherTips != nil) || (indexPath.section == 2 && self.weatherTips == nil)) {
        //指数
        static NSString *reuse = @"ZhiShuCell";
        ZhiShuCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
        if (!cell) {
            cell = [[ZhiShuCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:reuse];
        }
        if (self.zhiShuArray.count != 0) {
            cell.zhiShuArray = self.zhiShuArray;
        }
        return cell;
    }
    if ((indexPath.section == 4 && self.weatherTips != nil) || (indexPath.section == 3 && self.weatherTips == nil)) {
        //指数
        static NSString *reuse = @"WindAndHumidityCell";
        WindAndHumidityCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
        if (!cell) {
            cell = [[WindAndHumidityCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:reuse];
        }
        if (self.windAndHumidity != nil) {
            cell.windAndHumidity = self.windAndHumidity;
        }
        return cell;
    }
    return nil;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section != 0) {
        return 20;
    }
    return 0;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *view = [[UIView alloc] init];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.backView.frame.size.width, 20)];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor jinjuse];
    label.font = [UIFont systemFontOfSize:17 weight:1];
    if (section != 0) {
        label.text = self.weatherTips == nil ? self.array1[section -1] : self.array[section - 1];
    }
    [view addSubview:label];
    view.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.2];
    return view;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
