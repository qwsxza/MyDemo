//
//  SelectCityController.m
//  MyProject
//
//  Created by M-coppco on 15/11/13.
//  Copyright © 2015年 . All rights reserved.
//
/**
 *  CoreLocation框架中CLLocationManager 位置管理者 来做定位,一般单例写法
 CLLocationCoordinate2D 表示经纬度的一个结构体
 *
 *  @param void 7.0之后需要在plist文件中配置NSLocationAlwaysUsageDescription或者NSLocationWhenInUseUsageDescription的信息,新增Key: NSLocationAlwaysUsageDescription 和 NSLocationWhenInUseUsageDescription ，这两个Key的值将分别用于描述应用程序始终使用和使用期间使用定位的说明，这些说明将显示在用户设置中。
 */
#import "SelectCityController.h"
#import "AFNetworking.h"
#import "City.h"  //model
#import <CoreLocation/CoreLocation.h>   //头文件
#import "UIColor+AddColor.h"
#import "MBProgressHUD.h"  //菊花转

@interface SelectCityController ()<UISearchBarDelegate, UITableViewDataSource, UITableViewDelegate, CLLocationManagerDelegate>
@property (nonatomic, strong) UISearchBar *searchBar;//搜索框
@property(nonatomic, assign) BOOL isSearch;//是否是search状态
@property (nonatomic, strong)UILabel * lable;  //定位
@property (nonatomic, strong)UIButton * button;  //按钮
@property (nonatomic, strong)UITableView * table;  //按钮
@property(nonatomic, strong) NSString * loctionCity;//定位城市
@property (nonatomic, strong)NSMutableArray *cityArray;

@property (nonatomic, strong)MBProgressHUD *hud;

@property (nonatomic, strong)CLLocationManager *clmgr;  //地位服务
@property (nonatomic, strong)CLGeocoder *clg;  //地理编码器
@property (nonatomic, strong)CLLocation *location;  //位置
@end

@implementation SelectCityController
- (void)p_setLoading {
    self.hud = [[MBProgressHUD alloc]initWithView:self.backView];
    self.hud.frame = self.view.bounds;
    self.hud.minSize = CGSizeMake(100, 100);
    self.hud.mode = MBProgressHUDModeCustomView;
    self.hud.animationType = MBProgressHUDAnimationZoom;
    self.hud.labelText = @"正在加载";
    [self.backView addSubview:self.hud];
    [self.hud show:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.topView.backgroundColor = [UIColor jinjuse];
    self.view.backgroundColor = [UIColor whiteColor];
    self.isSearch = NO;
    
    [self initSubview];
    // Do any additional setup after loading the view.
}
- (void)initSubview {
    self.searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), 44)];
 
    self.searchBar.barStyle     = UIBarStyleDefault;
    self.searchBar.translucent  = YES;
    self.searchBar.delegate     = self;
    self.searchBar.placeholder  = @"请输入城市名字";
    self.searchBar.keyboardType = UIKeyboardTypeDefault;
    self.searchBar.backgroundColor = [UIColor redColor];
    [self.backView addSubview:self.searchBar];
    
    self.button = [UIButton buttonWithType:UIButtonTypeSystem];
    self.button.frame = CGRectMake(260, CGRectGetMaxY(self.searchBar.frame), 50, 30);
    [self.button addTarget:self action:@selector(location:) forControlEvents:(UIControlEventTouchUpInside)];
    self.lable = [[UILabel alloc] initWithFrame:CGRectMake(5, CGRectGetMaxY(self.searchBar.frame), 180, 30)];
    self.table = [[UITableView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(self.lable.frame), self.view.bounds.size.width, self.backView.bounds.size.height - CGRectGetMaxY(self.lable.frame)) style:UITableViewStylePlain];
    self.table.dataSource = self;
    self.table.delegate = self;
    //取消尾部多余的行
    self.table.tableFooterView = [[UIView alloc] init];
    self.lable.font = [UIFont systemFontOfSize:16];
    [self.backView addSubview:self.button];
    [self.backView addSubview:self.table];
    [self.backView addSubview:self.lable];
    [self.button setTitle:@"定位" forState:UIControlStateNormal];
    //[button addTarget:self action:@selector(reLOadLoction) forControlEvents:UIControlEventTouchUpInside];
    self.loctionCity = [[NSUserDefaults standardUserDefaults] objectForKey:@"location"];
   
    if (self.loctionCity) {
        self.lable.text = [NSString stringWithFormat:@"定位城市:%@",self.loctionCity];
    }else{
        self.lable.text = @"还没有定位";
    }
    
}
#pragma mark  UITableView协议中方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.cityArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *reuse = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleValue1) reuseIdentifier:reuse];
    }
    City *city = self.cityArray[indexPath.row];
    cell.textLabel.text = city.name;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@", city.tip];
    return cell;
}
#pragma mark searchBarDelegete
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    
    if (searchText.length == 0) {
        self.isSearch = NO;
    }else{
        self.isSearch = YES;
        [self.cityArray removeAllObjects];
//        [self p_setLoading];
        [self getCityDataWith:searchText];
    }
    
}
-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    [self.view endEditing:YES];
}
- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    self.isSearch = NO;
    
}
- (void)getCityDataWith:(NSString *)string {
    NSString *str = [NSString stringWithFormat:@"http://tq.91.com/api/?act=107&word=%@&mt=4&sv=3.13.3&osv=4.4.2&imei=863990022601940&dm=HM+NOTE+1TD&nt=10&CUID=F285040327F1AF69B3DC31842F407501%@7C049106220099368&pid=115&chl=1010791a", string, @"%"];
    //杭州市
    //字符串转码   中文编码
    NSString *url = [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    [[AFHTTPRequestOperationManager manager] GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        self.cityArray = [NSMutableArray array];
        [self.hud hide:YES];
        NSArray *array = responseObject[@"items"];
        if (array.count == 0) {
            City *city = [[City alloc] init];
            city.name = @"没有搜索到结果";
            city.tip = @"";
            self.table.userInteractionEnabled = NO;
            [self.cityArray removeAllObjects];
            [self.cityArray addObject:city];
        } else {
            for (NSDictionary *dic in responseObject[@"items"]) {
                City *city = [[City alloc] init];
                [city setValuesForKeysWithDictionary:dic];
                [self.cityArray addObject:city];
            }
            self.table.userInteractionEnabled = YES;
        }
        [self.table reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        //延时消失
        self.hud.labelText = @"加载失败,请检测网络重试";
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.hud hide:YES];
        });
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//经纬度转名字
- (void)reverseGeocoder {
    [self.clg reverseGeocodeLocation:self.location completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        if (error || placemarks.count == 0) {
            
        } else {
            CLPlacemark *clp = [placemarks firstObject];
            NSLog(@"%@", clp.subLocality);
            self.loctionCity = clp.subLocality;
            [[NSUserDefaults standardUserDefaults] setValue:clp.subLocality forKey:@"location"];
            //改变位置
            self.lable.text = [NSString stringWithFormat:@"定位:%@-%@", self.loctionCity, clp.locality];
            [self getCityDataWith:self.loctionCity];
        }
    }];
}
-(CLGeocoder *)clg {
    if (!_clg) {
        _clg = [[CLGeocoder alloc]init];
    }
    return _clg;
}
//懒加载
-(CLLocationManager *)clmgr {
    if (!_clmgr) {
        _clmgr = [[CLLocationManager alloc]init];
        _clmgr.delegate = self;
        _clmgr.desiredAccuracy = kCLLocationAccuracyNearestTenMeters; //精准度
        _clmgr.distanceFilter = 200; //多少米定位一次 默认任何移动
        //8.0后需要增加这一句
        if ([[UIDevice currentDevice].systemVersion floatValue]>= 8.0) {
            //使用期间
            //            [_clmgr requestWhenInUseAuthorization];
            //始终
            //or [self.locationManage requestAlwaysAuthorization]
        }
    }
    return _clmgr;
}
#pragma mark  这个方法可以得到位置  是一个数组
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations {
    //CLLocationCoordinate2D  经纬度的一个结构体
    CLLocation *loc = [locations firstObject];
    if (loc != nil) {
        
        [self.clmgr stopUpdatingLocation];
        self.location = loc;
        //反地理编码
        [self reverseGeocoder];
    } else {
        //延时消失
        self.hud.labelText = @"定位失败,请手动选取城市";
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.hud hide:YES];
        });
    }
    //数组中存放CLLocation类型的对象,
    //纬度 loc.coordinate.latitude
    //经度:loc.coordinate.longitude
    //定位比较耗电,如果不需要实时定位一旦定位到要停止定位
}
- (void)locationManager:(CLLocationManager *)manager
       didFailWithError:(NSError *)error {
    [self.clmgr stopUpdatingLocation];
//    NSLog(@"1111");
    //延时消失
    self.hud.labelText = @"定位失败,请手动选取城市";
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.hud hide:YES];
    });
}
- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status{
    switch (status) {
        case kCLAuthorizationStatusNotDetermined:
            if([self.clmgr respondsToSelector:@selector(requestAlwaysAuthorization)]){
                [self.clmgr requestWhenInUseAuthorization];
            }
            break;
        case kCLAuthorizationStatusDenied:
        {
            UIAlertView *view = [[UIAlertView alloc]initWithTitle:@"提示" message:@"请在设置-隐私-定位服务中开启本应用的定位功能！或者手动选择城市" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [view show];
        }
            break;
        case kCLAuthorizationStatusRestricted:
        {
            UIAlertView *view = [[UIAlertView alloc]initWithTitle:@"提示" message:@"定位服务无法开启" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [view show];
            
        }
        default:
            break;
    }
}
- (void)location:(UIButton *)button {
    if ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusDenied) {
        UIAlertView *view = [[UIAlertView alloc]initWithTitle:@"定位功能没有开启" message:@"请在设置-隐私-定位服务中开启本应用的定位功能！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [view show];
    } else {
        [self p_setLoading];
        self.hud.labelText = @"正在定位";
        [self.clmgr startUpdatingLocation];
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    City *city = self.cityArray[indexPath.row];
    [self.view endEditing:YES];
    //①创建NSMutableData 对象
    NSMutableData *mutableData = [NSMutableData data];
    //②创建归档对象,初始化时指定对应的NSMutableData对象
    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc]initForWritingWithMutableData:mutableData];
    //③开始编码
    [archiver encodeObject:city forKey:@"city"];
    //④结束编码
    [archiver finishEncoding];
    
    [[NSUserDefaults standardUserDefaults] setValue:mutableData forKey:@"city"];
    self.myBlock(city);
    [self dismissViewControllerAnimated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
