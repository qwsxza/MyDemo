//
//  Subject.m
//  MyProject
//
//  Created by M-coppco on 15/11/5.
//  Copyright © 2015年 . All rights reserved.
//

#import "Subject.h"

@implementation Subject

-(void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}
-(void)setValue:(id)value forKey:(NSString *)key {
    [super setValue:value forKey:key];
    
    if ([key isEqualToString:@"created_at"]) {
        self.created_at = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"posts_count"]) {
        self.posts_count = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"status"]) {
        self.status = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"updated_at"]) {
        self.updated_at = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"id"]) {
        self.subjectId = [NSString stringWithFormat:@"%@", value];
    }
}
@end
