//
//  Channels.h
//  MyProject
//
//  Created by M-coppco on 15/11/10.
//  Copyright © 2015年 . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Channels : NSObject
@property (nonatomic, strong)NSString *group_id;//1,
@property (nonatomic, strong)NSString *icon_url;//null,
@property (nonatomic, strong)NSString *channelId;//16,
@property (nonatomic, strong)NSString *items_count;//0,
@property (nonatomic, strong)NSString *key;//16,
@property (nonatomic, strong)NSString *name;//男票,
@property (nonatomic, strong)NSString *order;//7,
@property (nonatomic, strong)NSString *status;//0

-(instancetype)initWithDictionary:(NSDictionary *)dic;
+(instancetype)channelsWithDictionary:(NSDictionary *)dic;
@end
