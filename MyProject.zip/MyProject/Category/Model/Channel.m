//
//  Channel.m
//  MyProject
//
//  Created by M-coppco on 15/11/6.
//  Copyright © 2015年 . All rights reserved.
//

#import "Channel.h"

@implementation Channel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key {
    if ([key isEqualToString:@"id"]) {
        self.channelId = [NSString stringWithFormat:@"%@", value];
    }
}
-(void)setValue:(id)value forKey:(NSString *)key {
    [super setValue:value forKey:key];
    if ([key isEqualToString:@"group_id"]) {
        self.group_id = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"items_count"]) {
        self.items_count = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"order"]) {
        self.order = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"status"]) {
        self.status = [NSString stringWithFormat:@"%@", value];
    }
}
-(void)setNilValueForKey:(NSString *)key {}
@end
