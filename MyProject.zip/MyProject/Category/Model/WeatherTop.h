//
//  WeatherTop.h
//  MyProject
//
//  Created by M-coppco on 15/11/13.
//  Copyright © 2015年 . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WeatherTop : NSObject
@property (nonatomic, strong)NSString *logo;  //图标
@property (nonatomic, strong)NSString *bgImg;  //图标
@property (nonatomic, strong)NSString *text;  //良
@property (nonatomic, strong)NSString *act;//良进人页面url

@property (nonatomic, strong)NSString *warningLogo;  //图标
@property (nonatomic, strong)NSString *warningBgImg;  //图标
@property (nonatomic, strong)NSString *warningText;  //良
@property (nonatomic, strong)NSString *warningAct;//良进人页面url

@property (nonatomic, strong)NSString *clear;//背景图
@property (nonatomic, strong)NSString *temp;
@property (nonatomic, strong)NSString *title;
@property (nonatomic, strong)NSString *degreeText;
@property (nonatomic, strong)NSString *pubdate;  //发布时间

@property (nonatomic, strong)NSString *tid; //今天天气
@property (nonatomic, strong)NSString *tname;
@property (nonatomic, strong)NSString *tdateName;
@property (nonatomic, strong)NSString *theight;
@property (nonatomic, strong)NSString *tlow;

@property (nonatomic, strong)NSString *mid; //明天天气
@property (nonatomic, strong)NSString *mname;
@property (nonatomic, strong)NSString *mdateName;
@property (nonatomic, strong)NSString *mheight;
@property (nonatomic, strong)NSString *mlow;
@end
