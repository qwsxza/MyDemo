//
//  ZhishuModel.h
//  MyProject
//
//  Created by M-coppco on 15/11/14.
//  Copyright © 2015年 . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZhishuModel : NSObject
@property (nonatomic, copy)NSString *title;  //标题 农历
@property (nonatomic, copy)NSString *text;  //内容  小雪
@property (nonatomic, copy)NSString *icon;  //图标
@property (nonatomic, copy)NSString *color;  //颜色
@end
