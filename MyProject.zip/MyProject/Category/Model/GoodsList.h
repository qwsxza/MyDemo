//
//  GoodsList.h
//  MyProject
//
//  Created by M-coppco on 15/11/10.
//  Copyright © 2015年 . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GoodsList : NSObject

@property (nonatomic, strong)NSString *cover_image_url;//http://img03.liwushuo.com/image/151110/2al6cplyb.jpg-w640,
@property (nonatomic, strong)NSString *description1;//小礼君身边有朋友做保健品代购，最火的就属葡萄籽胶囊了，经常卖断货。葡萄籽不仅可以预防衰老、提高机体免疫力，还可以延缓皮肤衰老和美容，缓解部分过敏症状。搭配辅酶Q10，加倍吸收。两瓶就只要193元！要不要这么划算啊！,
@property (nonatomic, strong)NSString *favorites_count;//0,
@property (nonatomic, strong)NSString *goodsId;//1041116,
@property (nonatomic, strong)NSString *liked;//false,
@property (nonatomic, strong)NSString *name;//OL博奥维·葡萄籽浓缩精华400mg*100粒+辅酶Q10胶囊60,
@property (nonatomic, strong)NSString *price;//193.00
@end
