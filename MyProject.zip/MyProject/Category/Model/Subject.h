//
//  Subject.h
//  MyProject
//
//  Created by M-coppco on 15/11/5.
//  Copyright © 2015年 . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Subject : NSObject

@property (nonatomic, strong)NSString *banner_image_url;// http://img02.liwushuo.com/image/151104/slo0yu2ld.jpg-w300,
@property (nonatomic, strong)NSString *cover_image_url;// http://img01.liwushuo.com/image/151104/d9329w98y.jpg-w720,
@property (nonatomic, strong)NSString *created_at;// 1446626233,
@property (nonatomic, strong)NSString *subjectId;// 153,
@property (nonatomic, strong)NSString *posts_count;// 5,
@property (nonatomic, strong)NSString *status;// 0,
@property (nonatomic, strong)NSString *subtitle;// 帮你记录美好时光,
@property (nonatomic, strong)NSString *title;// 时间の恋人,
@property (nonatomic, strong)NSString *updated_at;// 1446626233
@end
