//
//  Channels.m
//  MyProject
//
//  Created by M-coppco on 15/11/10.
//  Copyright © 2015年 . All rights reserved.
//

#import "Channels.h"

@implementation Channels
-(instancetype)initWithDictionary:(NSDictionary *)dic {
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dic];
    }
    return self;
}
+(instancetype)channelsWithDictionary:(NSDictionary *)dic {
    return [[Channels alloc] initWithDictionary:dic];
}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key {
    if ([key isEqualToString:@"id"]) {
        self.channelId = [NSString stringWithFormat:@"%@", value];
    }
}
-(void)setNilValueForKey:(NSString *)key {

}
-(void)setValue:(id)value forKey:(NSString *)key {
    [super setValue:value forKey:key];
    if ([key isEqualToString:@"group_id"]) {
        self.group_id = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"items_count"]) {
        self.items_count = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"key"]) {
        self.key = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"order"]) {
        self.order = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"status"]) {
        self.status = [NSString stringWithFormat:@"%@", value];
    }
}
@end
