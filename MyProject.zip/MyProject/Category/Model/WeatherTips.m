//
//  WeatherTips.m
//  MyProject
//
//  Created by M-coppco on 15/11/14.
//  Copyright © 2015年 . All rights reserved.
//

#import "WeatherTips.h"

@implementation WeatherTips
-(void)setNilValueForKey:(NSString *)key {}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key {
 
}
-(void)setValue:(id)value forKey:(NSString *)key {
    [super setValue:value forKey:key];
    if ([key isEqualToString:@"text"]) {
        self.raw= value[@"raw"];
        self.keyword = [NSString stringWithFormat:@"%@", value[@"cfg"][0][@"keyword"]];
        self.color = [NSString stringWithFormat:@"%@", value[@"cfg"][0][@"color"]];;
    }
    if ([key isEqualToString:@"male"]) {
        self.take= [[value allValues] firstObject];

    }
}
@end
