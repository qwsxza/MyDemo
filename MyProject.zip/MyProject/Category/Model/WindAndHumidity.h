//
//  WindAndHumidity.h
//  MyProject
//
//  Created by M-coppco on 15/11/16.
//  Copyright © 2015年 . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WindAndHumidity : NSObject

@property (nonatomic, strong)NSString *wind;
@property (nonatomic, strong)NSString *humidity;
@end
