//
//  GoodsList.m
//  MyProject
//
//  Created by M-coppco on 15/11/10.
//  Copyright © 2015年 . All rights reserved.
//

#import "GoodsList.h"

@implementation GoodsList
-(void)setNilValueForKey:(NSString *)key {}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key {
    if ([key isEqualToString:@"id"]) {
        self.goodsId = [NSString stringWithFormat:@"%@", value];
    }
}
-(void)setValue:(id)value forKey:(NSString *)key {
    [super setValue:value forKey:key];
    if ([key isEqualToString:@"favorites_count"]) {
        self.favorites_count = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"liked"]) {
        self.liked = [NSString stringWithFormat:@"%@", value];
    }
}

@end
