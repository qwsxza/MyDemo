//
//  WeatherTop.m
//  MyProject
//
//  Created by M-coppco on 15/11/13.
//  Copyright © 2015年 . All rights reserved.
//

#import "WeatherTop.h"
//@property (nonatomic, strong)NSString *logo;  //图标
//@property (nonatomic, strong)NSString *bgImg;  //图标
//@property (nonatomic, strong)NSString *text;  //良
//@property (nonatomic, strong)NSString *act;//良进人页面url
//@property (nonatomic, strong)NSString *clear;//背景图
//@property (nonatomic, strong)NSString *temp;
//@property (nonatomic, strong)NSString *title;
//@property (nonatomic, strong)NSString *degreeText;
//@property (nonatomic, strong)NSString *pubdate;  //发布时间
//
//@property (nonatomic, strong)NSString *tid; //今天天气
//@property (nonatomic, strong)NSString *tname;
//@property (nonatomic, strong)NSString *tdateName;
//@property (nonatomic, strong)NSString *theight;
//@property (nonatomic, strong)NSString *tlow;
//
//@property (nonatomic, strong)NSString *mid; //明天天气
//@property (nonatomic, strong)NSString *mname;
//@property (nonatomic, strong)NSString *mdateName;
//@property (nonatomic, strong)NSString *mheight;
//@property (nonatomic, strong)NSString *mlow;
@implementation WeatherTop
-(void)setValue:(id)value forUndefinedKey:(NSString *)key {
    }
-(void)setValue:(id)value forKey:(NSString *)key {
    [super setValue:value forKey:key];
    if ([key isEqualToString:@"pm"]) {
        self.logo = value[@"icon"][@"logo"];
        self.bgImg = value[@"icon"][@"bgImg"];
        self.text = value[@"text"];
        self.act = value[@"act"];
    }
    if ([key isEqualToString:@"warning"]) {
        self.warningLogo = value[@"icon"][@"logo"];
        self.warningBgImg = value[@"icon"][@"bgImg"];
        self.warningText = value[@"text"];
        self.warningAct = value[@"act"];
    }
    if ([key isEqualToString:@"bg"]) {
        self.clear = value[@"static"][@"clear"];
    }
    
    if ([key isEqualToString:@"now"]) {
        self.temp = value[@"temp"];
        self.title = value[@"desc"][@"title"];
        self.degreeText = value[@"desc"][@"text"];
    }
    if ([key isEqualToString:@"summary"]) {
        self.pubdate = value[@"right"][@"pubdate"];
    }
    if ([key isEqualToString:@"future"]) {
        self.tdateName = value[@"items"][0][@"dateName"];
        self.tid = [NSString stringWithFormat:@"%@", value[@"items"][0][@"climate"][@"id"]];
        self.tname = value[@"items"][0][@"climate"][@"name"];
        self.theight = [NSString stringWithFormat:@"%@", value[@"items"][0][@"temp"][@"height"]];
        self.tlow = [NSString stringWithFormat:@"%@", value[@"items"][0][@"temp"][@"low"]];
        
        self.mdateName = value[@"items"][1][@"dateName"];
        self.mid = [NSString stringWithFormat:@"%@", value[@"items"][1][@"climate"][@"id"]];
        self.mname = value[@"items"][1][@"climate"][@"name"];
        self.mheight = [NSString stringWithFormat:@"%@", value[@"items"][1][@"temp"][@"height"]];
        self.mlow = [NSString stringWithFormat:@"%@", value[@"items"][1][@"temp"][@"low"]];
    }

}
-(void)setNilValueForKey:(NSString *)key {}
@end
