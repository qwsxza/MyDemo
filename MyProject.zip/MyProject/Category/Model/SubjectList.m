//
//  SunjectList.m
//  MyProject
//
//  Created by M-coppco on 15/11/6.
//  Copyright © 2015年 . All rights reserved.
//

#import "SubjectList.h"

@implementation SubjectList
-(void)setValue:(id)value forKey:(NSString *)key {
    [super setValue:value forKey:key];

    if ([key isEqualToString:@"created_at"]) {
        self.created_at = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"id"]) {
        self.subjectListId = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"liked"]) {
        self.liked = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"likes_count"]) {
        self.likes_count = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"published_at"]) {
        self.published_at = [NSString stringWithFormat:@"%@", value];
    }
}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key {}
-(void)setNilValueForKey:(NSString *)key {}
@end
