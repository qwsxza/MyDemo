//
//  Filters.h
//  MyProject
//
//  Created by M-coppco on 15/11/10.
//  Copyright © 2015年 . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Filters : NSObject

@property (nonatomic, strong)NSMutableArray *channels;//[],
@property (nonatomic, strong)NSString *filtersId;//1,
@property (nonatomic, strong)NSString *key;//target,
@property (nonatomic, strong)NSString *name;//对象,
@property (nonatomic, strong)NSString *order;//4,
@property (nonatomic, strong)NSString *status;//0
@end
