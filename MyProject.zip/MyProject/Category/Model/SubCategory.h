//
//  SubCategory.h
//  MyProject
//
//  Created by M-coppco on 15/11/7.
//  Copyright © 2015年 . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SubCategory : NSObject
@property (nonatomic, strong)NSString *icon_url;//http://img03.liwushuo.com/image/150615/urgs9vy8a.png-pw144,
@property (nonatomic, strong)NSString *subCategoryId;//7,
@property (nonatomic, strong)NSString *items_count;//-62,
@property (nonatomic, strong)NSString *name;//智能设备,
@property (nonatomic, strong)NSString *order;//7,
@property (nonatomic, strong)NSString *parent_id;//1,
@property (nonatomic, strong)NSString *status;//0
@end
