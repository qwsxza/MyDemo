//
//  WindAndHumidity.m
//  MyProject
//
//  Created by M-coppco on 15/11/16.
//  Copyright © 2015年 . All rights reserved.
//

#import "WindAndHumidity.h"

@implementation WindAndHumidity
-(void)setNilValueForKey:(NSString *)key {}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key {}
@end
