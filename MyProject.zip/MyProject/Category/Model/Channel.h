//
//  Channel.h
//  MyProject
//
//  Created by M-coppco on 15/11/6.
//  Copyright © 2015年 . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Channel : NSObject

@property (nonatomic, strong)NSString *group_id;//5,
@property (nonatomic, strong)NSString *icon_url;//http://img02.liwushuo.com/image/150615/yfdkhhsiy.png-pw144,
@property (nonatomic, strong)NSString *channelId;//111,
@property (nonatomic, strong)NSString *items_count;//941,
@property (nonatomic, strong)NSString *name;//礼物,
@property (nonatomic, strong)NSString *order;//10,
@property (nonatomic, strong)NSString *status;//0
@end
