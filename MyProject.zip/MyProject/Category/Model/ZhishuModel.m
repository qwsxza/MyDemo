//
//  ZhishuModel.m
//  MyProject
//
//  Created by M-coppco on 15/11/14.
//  Copyright © 2015年 . All rights reserved.
//

#import "ZhishuModel.h"

@implementation ZhishuModel
-(void)setNilValueForKey:(NSString *)key {}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key {}

@end
