//
//  Filters.m
//  MyProject
//
//  Created by M-coppco on 15/11/10.
//  Copyright © 2015年 . All rights reserved.
//

#import "Filters.h"
#import "Channels.h"  //model

@implementation Filters

-(void)setValue:(id)value forUndefinedKey:(NSString *)key {
    if ([key isEqualToString:@"id"]) {
        self.filtersId = [NSString stringWithFormat:@"%@", value];
    }
}

-(void)setNilValueForKey:(NSString *)key {}

-(void)setValue:(id)value forKey:(NSString *)key {
    [super setValue:value forKey:key];
    if ([key isEqualToString:@"order"]) {
        self.order = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"status"]) {
        self.status = [NSString stringWithFormat:@"%@", value];
    }
    if ([key isEqualToString:@"channels"]) {
        NSMutableArray *array = [NSMutableArray array];
        for (NSDictionary *dic in value) {
            Channels *channels = [[Channels alloc]initWithDictionary:dic];
            [array addObject:channels];
        }
        self.channels = [NSMutableArray arrayWithArray:array];
    }
}
@end
