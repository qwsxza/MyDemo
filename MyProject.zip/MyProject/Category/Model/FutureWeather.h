//
//  FutureWeather.h
//  MyProject
//
//  Created by M-coppco on 15/11/14.
//  Copyright © 2015年 . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FutureWeather : NSObject

@property (nonatomic, copy)NSString *name;  //小雨
@property (nonatomic, copy)NSString *dateName;  //周五
@property (nonatomic, copy)NSString *date;  //时间
@property (nonatomic, copy)NSString *direction;  //北风
@property (nonatomic, copy)NSString *grade; //风力
@property (nonatomic, copy)NSString *height;  //最高温度
@property (nonatomic, copy)NSString *low; //最低温度

@end
