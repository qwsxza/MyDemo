//
//  WeatherTips.h
//  MyProject
//
//  Created by M-coppco on 15/11/14.
//  Copyright © 2015年 . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WeatherTips : NSObject

@property (nonatomic, copy)NSString *raw;//{提醒familyName}
@property (nonatomic, copy)NSString *take;  //图片地图
@property (nonatomic, copy)NSString *background; //背景图片
@property (nonatomic, copy)NSString *expireAt;  //时间
@property (nonatomic, copy)NSString *keyword;  //关键字
@property (nonatomic, copy)NSString *color;  //颜色
@end
