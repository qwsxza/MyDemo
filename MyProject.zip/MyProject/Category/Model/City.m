//
//  City.m
//  MyProject
//
//  Created by M-coppco on 15/11/13.
//  Copyright © 2015年 . All rights reserved.
//

#import "City.h"

@implementation City
-(void)setValue:(id)value forUndefinedKey:(NSString *)key {
    if ([key isEqualToString:@"id"]) {
        self.cityId = [NSString stringWithFormat:@"%@", value];
    }
}
-(void)setNilValueForKey:(NSString *)key {}
- (void)encodeWithCoder:(NSCoder *)aCoder {
    [aCoder encodeObject:self.name forKey:@"name"];
    [aCoder encodeObject:self.cityId forKey:@"cityId"];
    [aCoder encodeObject:self.districtName forKey:@"districtName"];
    [aCoder encodeObject:self.tip forKey:@"tip"];
}
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self) {
        self.name = [aDecoder decodeObjectForKey:@"name"];
        self.cityId = [aDecoder decodeObjectForKey:@"cityId"];
        self.districtName = [aDecoder decodeObjectForKey:@"districtName"];
        self.tip = [aDecoder decodeObjectForKey:@"tip"];
    }
    return self;
}
@end
