//
//  City.h
//  MyProject
//
//  Created by M-coppco on 15/11/13.
//  Copyright © 2015年 . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface City : NSObject<NSCoding>

@property (nonatomic, strong)NSString *districtName;// = "\U5546\U6cb3\U53bf";
@property (nonatomic, strong)NSString *cityId; //= 1011201033701260014;
@property (nonatomic, strong)NSString *name;// = "1\U3001\U8bb8\U5546\U8857\U9053";
@property (nonatomic, strong)NSString *tip;// = "(\U5c71\U4e1c\U7701.\U6d4e\U5357\U5e02)";
@end
