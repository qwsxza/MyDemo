//
//  SunjectList.h
//  MyProject
//
//  Created by M-coppco on 15/11/6.
//  Copyright © 2015年 . All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SubjectList : NSObject

@property (nonatomic, strong)NSString *content_url;// http://www.liwushuo.com/posts/1002064/content
@property (nonatomic, strong)NSString *cover_image_url;// http://img02.liwushuo.com/image/150629/6fiohu3gf.jpg-w720
@property (nonatomic, strong)NSString *created_at;// 1435622400,
@property (nonatomic, strong)NSString *subjectListId;// 1002064,

@property (nonatomic, strong)NSString *liked;// false,
@property (nonatomic, strong)NSString *likes_count;// 73974,
@property (nonatomic, strong)NSString *published_at;// 1433169587,
@property (nonatomic, strong)NSString *share_msg;// 千呼万唤始出来的学生党手表推荐，终于新鲜出炉喽！那么对于你来说，手表是什么样的存在呢？是看时间的工具，还是点睛之笔的配饰呢？对于小礼君来说这二者皆是，所以今天给各位推荐的都是百元内性价比美表哦，总有一款是你的菜！,
@property (nonatomic, strong)NSString *short_title;// 学生党手表,
@property (nonatomic, strong)NSString *status;// 0,
@property (nonatomic, strong)NSString *title;// 学生党看过来：百元内女表推荐,
@property (nonatomic, strong)NSString *updated_at;// 1435575749,
@property (nonatomic, strong)NSString *url;// http://www.liwushuo.com/posts/1002064

@end
