//
//  FutureWeather.m
//  MyProject
//
//  Created by M-coppco on 15/11/14.
//  Copyright © 2015年 . All rights reserved.
//

#import "FutureWeather.h"

@implementation FutureWeather
-(void)setNilValueForKey:(NSString *)key {}
-(void)setValue:(id)value forKey:(NSString *)key {
    [super setValue:value forKey:key];
    if ([key isEqualToString:@"temp"]) {
        self.height = [NSString stringWithFormat:@"%@", value[@"height"]];
        self.low = [NSString stringWithFormat:@"%@", value[@"low"]];
    }
    if ([key isEqualToString:@"climate"]) {
        self.name = value[@"name"];
    }
    if ([key isEqualToString:@"winds"]) {
        self.direction = value[@"direction"];
        self.grade = value[@"grade"];
    }
}
-(void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}

@end
