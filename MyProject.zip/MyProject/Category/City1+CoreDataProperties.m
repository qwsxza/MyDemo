//
//  City1+CoreDataProperties.m
//  MyProject
//
//  Created by M-coppco on 15/11/16.
//  Copyright © 2015年 gp. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "City1+CoreDataProperties.h"

@implementation City1 (CoreDataProperties)

@dynamic districtName;
@dynamic cityId;
@dynamic name;
@dynamic tip;

@end
