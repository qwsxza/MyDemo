//
//  City1.h
//  MyProject
//
//  Created by M-coppco on 15/11/16.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface City1 : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "City1+CoreDataProperties.h"
