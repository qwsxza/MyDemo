//
//  radioView.h
//  vNews
//
//  Created by gp on 15/10/30.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface radioView : UIView

@property(nonatomic, strong)NSMutableArray *headArr;

@property(nonatomic, strong)NSMutableArray *secondArr;

@property(nonatomic, strong)NSMutableArray *cellArr;

@property(nonatomic, strong)UITableView *tableView;

@end
