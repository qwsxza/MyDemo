//
//  HeadView.m
//  vNews
//
//  Created by gp on 15/11/3.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import "HeadView.h"
#import "UIImageView+WebCache.h"


@interface HeadView ()
@property(nonatomic, strong)UIImageView *imageview;
@property(nonatomic, strong)UIImageView *photoV;
@property(nonatomic, strong)UIImageView *tingV;

@property(nonatomic, strong)UILabel *title;
@property(nonatomic, strong)UILabel *des;
@property(nonatomic, strong)UILabel *count;
@end

@implementation HeadView

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self) {
        
        self.imageview = [[UIImageView alloc] initWithFrame:(CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 150))];
        [self addSubview:self.imageview];
        self.photoV = [[UIImageView alloc] initWithFrame:(CGRectMake(20, self.imageview.frame.origin.x + self.imageview.bounds.size.height + 20, 20, 20))];
        [self addSubview:self.photoV];
        self.title = [[UILabel alloc] initWithFrame:(CGRectMake(self.photoV.frame.origin.x + 25, self.photoV.frame.origin.y + 5, 100, 10))];
        self.title.font = [UIFont boldSystemFontOfSize:14];
        [self addSubview:self.title];
        self.des = [[UILabel alloc] initWithFrame:(CGRectMake(self.photoV.frame.origin.x, self.photoV.frame.origin.y + 30,[UIScreen mainScreen].bounds.size.width - self.photoV.frame.origin.x, 40))];
        [self addSubview:self.des];
        self.des.font = [UIFont boldSystemFontOfSize:15];
        self.des.numberOfLines = 0;
        
        self.tingV = [[UIImageView alloc] initWithFrame:(CGRectMake( [UIScreen mainScreen].bounds.size.width - 100, self.photoV.frame.origin.y, 15,15))];
        [self addSubview:self.tingV];
        self.count = [[UILabel alloc] initWithFrame:(CGRectMake(self.tingV.frame.origin.x + self.tingV.frame.size.width + 3, self.photoV.frame.origin.y, 80, 15))];
        [self addSubview:self.count];
        self.count.font = [UIFont boldSystemFontOfSize:13];
  
        
    }
    return self;
}


-(void)setInfonation:(radioINfo *)infonation
{
    _infonation = infonation;
    
    self.title.text = infonation.title;
    
    self.des.text = infonation.desc;
    
    [self.imageview sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@", infonation.coverimg]] placeholderImage:nil];
    
    NSString *str = [infonation.userinfo objectForKey:@"icon"];
    [self.photoV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@", str]] placeholderImage:nil];
    
    //    NSLog(@"%@", infonation.musicvisitnum);
    self.tingV.image = [UIImage imageNamed:@"radio"];
    
       self.count.text = [NSString stringWithFormat:@"%@", infonation.musicvisitnum];
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
