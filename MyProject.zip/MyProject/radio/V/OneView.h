//
//  OneView.h
//  vNews
//
//  Created by gp on 15/11/3.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "playINFO.h"

@interface OneView : UIView


@property(nonatomic, strong)playINFO *play;

@property(nonatomic, strong)UIImageView *imageV;

@property(nonatomic, strong)UISlider *silder;
@property(nonatomic, strong)UILabel *titlelabel;
@property(nonatomic, strong)UILabel *timelabel;
@property(nonatomic, strong)UILabel *totallabel;

@end
