//
//  sceondCell.h
//  vNews
//
//  Created by gp on 15/10/30.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIButton+WebCache.h"

@interface sceondCell : UITableViewCell

@property(nonatomic, strong)NSMutableArray *modelArr;

@property(nonatomic, strong)UIButton *dailyB;//每日精选
@property(nonatomic, strong)UIButton *voice;//最新发声
@property(nonatomic, strong)UIButton *nanaya;//七夜


@end
