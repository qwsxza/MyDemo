//
//  listCell.h
//  vNews
//
//  Created by gp on 15/10/31.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "detaillist.h"

@interface listCell : UITableViewCell

@property(nonatomic, strong)detaillist *list;

@end
