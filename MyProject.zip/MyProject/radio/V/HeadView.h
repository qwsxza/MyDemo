//
//  HeadView.h
//  vNews
//
//  Created by gp on 15/11/3.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "radioINfo.h"

@interface HeadView : UIView
@property(nonatomic, strong)radioINfo *infonation;

@end
