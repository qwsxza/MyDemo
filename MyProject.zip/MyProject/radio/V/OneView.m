//
//  OneView.m
//  vNews
//
//  Created by gp on 15/11/3.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import "OneView.h"
#import "UIView+Extension.h"
#import "UIImageView+WebCache.h"
#import "LMusicPlay.h"
#import "UIColor+AddColor.h"

@interface OneView ()





@end

@implementation OneView


-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
    
        self.imageV = [[UIImageView alloc] initWithFrame:(CGRectMake(frame.size.width * 1/7, 20, frame.size.width * 5/7, frame.size.width * 5/7))];
        [self addSubview:self.imageV];
        CALayer *layer = self.imageV.layer;
        
        [layer setMasksToBounds:YES];
        [layer setCornerRadius:frame.size.width * 5/14];
        [layer setBorderWidth:3];
        [layer setBorderColor:[UIColor tiankonglan].CGColor];
        
       
        self.titlelabel = [[UILabel alloc] initWithFrame:(CGRectMake(20, self.imageV.y + self.imageV.height + 20, frame.size.width - 40, 20))];
        [self addSubview:self.titlelabel];
        self.titlelabel.textAlignment = NSTextAlignmentCenter;

        
        self.timelabel = [[UILabel alloc] initWithFrame:(CGRectMake(30, self.titlelabel.y + self.titlelabel.height + 30, 50, 15))];
        [self addSubview:self.timelabel];
        self.timelabel.font = [UIFont systemFontOfSize:15];
        
        self.silder = [[UISlider alloc] initWithFrame:(CGRectMake(frame.size.width * 1/4, self.titlelabel.y + self.titlelabel.height + 30, frame.size.width * 1/2, 15))];
        [self addSubview:self.silder];

        
        self.totallabel = [[UILabel alloc] initWithFrame:(CGRectMake(self.silder.x + self.silder.width + 20, self.silder.y, 50, 15))];
        [self addSubview:self.totallabel];
        self.totallabel.font = [UIFont systemFontOfSize:15];

        
        [self animation:_imageV];

        
    }
    
    return self;
}


-(void)setPlay:(playINFO *)play
{
    _play = play;
    
    [self.imageV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@", play.imgUrl]] placeholderImage:nil];
    
   
    

    
    self.titlelabel.text = play.title;
    
    
}

-(void)animation:(UIImageView *)imageView{
    
    [UIView animateWithDuration:0.01 animations:^{
        
        _imageV.transform = CGAffineTransformRotate(_imageV.transform, M_PI / 380);
        
    } completion:^(BOOL finished) {
      
        [self animation:_imageV];
    }];

    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
