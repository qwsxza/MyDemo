//
//  alllistCell.h
//  vNews
//
//  Created by gp on 15/10/31.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Alllist.h"

@interface alllistCell : UITableViewCell


@property(nonatomic, strong)Alllist *list;

@end
