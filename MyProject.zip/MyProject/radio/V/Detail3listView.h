//
//  Detail3listView.h
//  vNews
//
//  Created by gp on 15/10/31.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "radioINfo.h"

@interface Detail3listView : UIView

@property(nonatomic, strong)UITableView  *tableview;

@property(nonatomic, strong)NSMutableArray *modelArr;

@property(nonatomic, strong)radioINfo *infonation;



@end
