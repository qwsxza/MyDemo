
//
//  HeadviewCell.m
//  vNews
//
//  Created by gp on 15/11/2.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import "HeadviewCell.h"
#import "UIImageView+WebCache.h"


@interface HeadviewCell ()

@property(nonatomic, strong)UIImageView *imageview;
@property(nonatomic, strong)UIImageView *photoV;

@property(nonatomic, strong)UILabel *title;
@property(nonatomic, strong)UILabel *des;
@property(nonatomic, strong)UILabel *count;

@end


@implementation HeadviewCell


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.imageview = [[UIImageView alloc] initWithFrame:(CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 150))];
        [self addSubview:self.imageview];
        self.photoV = [[UIImageView alloc] initWithFrame:(CGRectMake(20, self.imageview.frame.origin.x + self.imageview.bounds.size.height + 20, 20, 20))];
        [self addSubview:self.photoV];
        self.title = [[UILabel alloc] initWithFrame:(CGRectMake(self.photoV.frame.origin.x + 25, self.photoV.frame.origin.y + 5, 100, 10))];
        self.title.font = [UIFont boldSystemFontOfSize:14];
        [self addSubview:self.title];
        self.des = [[UILabel alloc] initWithFrame:(CGRectMake(self.photoV.frame.origin.x, self.photoV.frame.origin.y + 30,[UIScreen mainScreen].bounds.size.width - self.photoV.frame.origin.x, 40))];
        [self addSubview:self.des];
        self.des.font = [UIFont boldSystemFontOfSize:15];
        self.des.numberOfLines = 0;
        
        self.count = [[UILabel alloc] initWithFrame:(CGRectMake(self.photoV.frame.origin.x + 280, self.photoV.frame.origin.y, 60, 15))];
        [self addSubview:self.count];
        self.count.font = [UIFont boldSystemFontOfSize:13];
        
    }
    return self;
}

-(void)setInfonation:(radioINfo *)infonation
{
    _infonation = infonation;
    
    self.title.text = infonation.title;
    
    self.des.text = infonation.desc;
    
    [self.imageview sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@", infonation.coverimg]] placeholderImage:nil];
    
    NSString *str = [infonation.userinfo objectForKey:@"icon"];
    [self.photoV sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@", str]] placeholderImage:nil];
    
    //    NSLog(@"%@", infonation.musicvisitnum);
    
    
    if (self.count.text.length == 0) {
        self.count.hidden = YES;
    }
    self.count.text = [NSString stringWithFormat:@"%@", infonation.musicvisitnum];
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
