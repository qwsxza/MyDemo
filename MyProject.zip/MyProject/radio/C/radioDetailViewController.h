//
//  radioDetailViewController.h
//  vNews
//
//  Created by gp on 15/10/31.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface radioDetailViewController : UIViewController

@property(nonatomic, strong)NSString *API;

@property(nonatomic, strong)NSString *name;

@end
