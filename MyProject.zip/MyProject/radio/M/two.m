//
//  two.m
//  vNews
//
//  Created by gp on 15/10/30.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import "two.h"

@implementation two

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
