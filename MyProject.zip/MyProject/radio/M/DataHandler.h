//
//  DataHandler.h
//  vNews
//
//  Created by gp on 15/11/16.
//  Copyright © 2015年 vNewsTeam. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "playINFO.h"
@interface DataHandler : NSObject

@property(nonatomic, strong)playINFO *info;

@property(nonatomic, assign)float totalTime;

+(DataHandler *)shareDataHandler;

@end
