//
//  DataHandler.m
//  vNews
//
//  Created by gp on 15/11/16.
//  Copyright © 2015年 vNewsTeam. All rights reserved.
//

#import "DataHandler.h"


static DataHandler *handler;

@implementation DataHandler


+(DataHandler *)shareDataHandler
{
    @synchronized(self) {
        if (handler == nil) {
            handler = [[DataHandler alloc] init];
        }
        return handler;
    }
}

@end
