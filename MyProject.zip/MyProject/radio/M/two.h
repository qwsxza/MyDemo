//
//  two.h
//  vNews
//
//  Created by gp on 15/10/30.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface two : NSObject


@property(nonatomic, strong)NSString *radioid;
@property(nonatomic, strong)NSString *title;
@property(nonatomic, strong)NSString *coverimg;

@property(nonatomic, strong)NSDictionary *userinfo;
@property(nonatomic, strong)NSString *count;

@property(nonatomic, strong)NSString *desc;
@property(nonatomic, strong)NSString *isnew;


@end
