//
//  playINFO.m
//  vNews
//
//  Created by gp on 15/11/3.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import "playINFO.h"

@implementation playINFO

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

@end
