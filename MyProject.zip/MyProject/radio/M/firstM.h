//
//  firstM.h
//  vNews
//
//  Created by gp on 15/10/30.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface firstM : NSObject

@property(nonatomic, strong)NSString *img;

@property(nonatomic, strong)NSString *url;

@end
