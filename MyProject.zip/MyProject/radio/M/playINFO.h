//
//  playINFO.h
//  vNews
//
//  Created by gp on 15/11/3.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface playINFO : NSObject

@property(nonatomic, strong)NSString *title;
@property(nonatomic, strong)NSString *imgUrl;//图片地址
@property(nonatomic, strong)NSString *musicUrl;//MP3地址
@property(nonatomic, strong)NSString *webview_url;//webview地址
@property(nonatomic, strong)NSString *tingid;


@end
