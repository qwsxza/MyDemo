//
//  radioINfo.h
//  vNews
//
//  Created by gp on 15/10/31.
//  Copyright (c) 2015年 vNewsTeam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface radioINfo : NSObject

@property(nonatomic, strong)NSString *title;
@property(nonatomic, strong)NSString *coverimg;
@property(nonatomic, strong)NSString *desc;
@property(nonatomic, strong)NSDictionary *userinfo;
@property(nonatomic, strong)NSString *musicvisitnum;



@end
