//
//  StartController.h
//  MyProject
//
//  Created by M-coppco on 15/11/17.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StartController : UIViewController

@end
