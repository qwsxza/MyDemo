//
//  ViewController.m
//  MyProject
//
//  Created by gp on 15/11/5.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "ViewController.h"
#define KWidth 200
@interface ViewController ()


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.navigationController.navigationBar.hidden = YES;
    [self addSubViews];
}

- (void)addSubViews{
    _topView = [[UIView alloc] initWithFrame:(CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height / 9))];
    self.topView.backgroundColor = [UIColor redColor];
    self.topView.userInteractionEnabled = YES;
    [self.view addSubview:self.topView];
    
    _backView = [[UIView alloc] initWithFrame:(CGRectMake(0, self.topView.bounds.size.height, self.view.bounds.size.width, self.view.bounds.size.height * 8 / 9))];
    self.backView.userInteractionEnabled = YES;
    self.backView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.backView];
    
    UIButton *backButton = [UIButton buttonWithType:(UIButtonTypeCustom)];
    backButton.frame = CGRectMake(10, self.view.bounds.size.height / 20, self.view.bounds.size.width / 8, self.view.bounds.size.height / 18);
    [backButton setImage:[UIImage imageNamed:@"back"] forState:(UIControlStateNormal)];
    [backButton addTarget:self action:@selector(backAction:) forControlEvents:(UIControlEventTouchUpInside)];
    self.view.userInteractionEnabled = YES;
    [self.topView addSubview:backButton];
    
    //上面的title
    _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake((self.topView.bounds.size.width - KWidth) / 2, self.view.bounds.size.height / 9 / 3, KWidth, self.view.bounds.size.height / 9 / 3 * 2)];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.topView addSubview:self.titleLabel];
}

- (void)backAction:(UIButton *)button{
    [self.navigationController popViewControllerAnimated:YES];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
