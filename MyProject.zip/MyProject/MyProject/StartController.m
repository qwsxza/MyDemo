//
//  StartController.m
//  MyProject
//
//  Created by M-coppco on 15/11/17.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "StartController.h"
#import "CHTumblrMenuView.h"
#import "CategoryListController.h"  //分类
#import "WeatherController.h"  //天气
#import "TripViewController.h"  //游记 视频
#import "HotViewController.h"  //热门
#import "GiftViewController.h"  //礼物首页
#import "SettingViewController.h"  //我的
#import "radioController.h" //电台
#import "MovieViewController.h" //电影
@interface StartController ()

@property (nonatomic, strong)CHTumblrMenuView *menuView;
@end

@implementation StartController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"modal_background.png"]];
    
    _menuView = [[CHTumblrMenuView alloc] initWithFrame:self.view.bounds];
    
    __weak typeof(self) myself = self;
    [_menuView addMenuItemWithTitle:@"懒得淘" andIcon:[UIImage imageNamed:@"购物"] andSelectedBlock:^{
        GiftViewController *giftVC = [[GiftViewController alloc] init];
        [myself.navigationController pushViewController:giftVC animated:NO];
        [myself SetCubeAnimation];
    }];
    [_menuView addMenuItemWithTitle:@"热门" andIcon:[UIImage imageNamed:@"热门"] andSelectedBlock:^{
        HotViewController *hotVC = [[HotViewController alloc] init];
        [myself.navigationController pushViewController:hotVC animated:NO];
    }];
    [_menuView addMenuItemWithTitle:@"分类" andIcon:[UIImage imageNamed:@"分类"] andSelectedBlock:^{
        //进入分类
        CategoryListController *categoryVC = [[CategoryListController alloc] init];
        
        [myself.navigationController pushViewController:categoryVC animated:NO];
        
    }];
    [_menuView addMenuItemWithTitle:@"旅行" andIcon:[UIImage imageNamed:@"旅行"] andSelectedBlock:^{
        TripViewController *tripVC = [[TripViewController alloc] init];
        [myself.navigationController pushViewController:tripVC animated:NO];
        
    }];
    [_menuView addMenuItemWithTitle:@"天气" andIcon:[UIImage imageNamed:@"天气"] andSelectedBlock:^{
        //进入天气页面
        WeatherController *weather = [[WeatherController alloc] init];
        [myself.navigationController pushViewController:weather animated:NO];
        
    }];
    [_menuView addMenuItemWithTitle:@"电台" andIcon:[UIImage imageNamed:@"电台"] andSelectedBlock:^{
        radioController *radio = [[radioController alloc] init];
        [myself.navigationController pushViewController:radio animated:NO];
    }];
    
    [_menuView addMenuItemWithTitle:@"视频" andIcon:[UIImage imageNamed:@"视频"] andSelectedBlock:^{
        MovieViewController *movie = [[MovieViewController alloc] init];
        [myself.navigationController pushViewController:movie animated:NO];
    }];
    
    [_menuView addMenuItemWithTitle:@"我的" andIcon:[UIImage imageNamed:@"我的"] andSelectedBlock:^{
        SettingViewController *setterVC = [[SettingViewController alloc] init];
        [myself.navigationController pushViewController:setterVC animated:NO];
    }];
    
    [self.view addSubview:self.menuView];
}
//立方体 动画
- (void)SetCubeAnimation
{
    CATransition *transition = [CATransition animation];
    transition.type = @"cube";
    transition.subtype = kCATransitionFromRight;
    transition.duration = 0.8;
    [self.view.layer addAnimation:transition forKey:@"立方体效果"];
    
}
-(void)viewWillAppear:(BOOL)animated {
    [_menuView show];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
