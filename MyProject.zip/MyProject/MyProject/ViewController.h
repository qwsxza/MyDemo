//
//  ViewController.h
//  MyProject
//
//  Created by gp on 15/11/5.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (nonatomic, strong, readonly) UIView *topView;
@property (nonatomic, strong, readonly) UIView *backView;
@property (nonatomic, strong, readonly)UILabel *titleLabel;
@end

