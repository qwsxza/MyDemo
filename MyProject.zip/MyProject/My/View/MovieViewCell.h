//
//  MovieViewCell.h
//  MyProject
//
//  Created by 陆超 on 15/11/12.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Movie;
@interface MovieViewCell : UITableViewCell
@property (nonatomic, strong) Movie *movie;

@end
