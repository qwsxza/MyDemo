//
//  TripViewCell.m
//  MyProject
//
//  Created by 陆超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "TripViewCell.h"
#import "Trip.h"
#import "UIImageView+WebCache.h"
#import "User.h"
#import "UIColor+AddColor.h"
#import "Trips.h"
#define KLeft 10
#define kTop 10
@interface TripViewCell ()
@property (nonatomic, strong) UIImageView *picImageView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) UIImageView *peopleImageView;
@end

@implementation TripViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.picImageView = [[UIImageView alloc] init];
        [self.contentView addSubview:self.picImageView];
        
        self.titleLabel = [[UILabel alloc] init];
        [self.picImageView addSubview:self.titleLabel];
        
        self.timeLabel = [[UILabel alloc] init];
        [self.picImageView addSubview:self.timeLabel];
       
        self.peopleImageView = [[UIImageView alloc] init];
        [self.picImageView addSubview:self.peopleImageView];
    }
    return self;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    self.picImageView.frame = CGRectMake(KLeft, kTop, self.contentView.bounds.size.width - 2 * KLeft, self.contentView.bounds.size.height - 2 * kTop);
    self.picImageView.layer.masksToBounds = YES;
    self.picImageView.layer.cornerRadius = 20;
    self.picImageView.layer.borderWidth = 2;
    self.picImageView.layer.borderColor = [[UIColor whiteColor] CGColor];
    self.picImageView.userInteractionEnabled = YES;
    self.titleLabel.frame = CGRectMake(KLeft, kTop + 10, self.picImageView.bounds.size.width - 2 * KLeft, self.picImageView.bounds.size.height / 5);
    self.titleLabel.font = [UIFont systemFontOfSize:20 weight:1];
    self.titleLabel.textColor = [UIColor whiteColor];
    self.titleLabel.numberOfLines = 2;
   
    self.timeLabel.frame = CGRectMake(self.titleLabel.frame.origin.x, CGRectGetMaxY(_titleLabel.frame), self.titleLabel.bounds.size.width, 40);
    self.timeLabel.textColor = [UIColor whiteColor];
    
    self.peopleImageView.frame = CGRectMake(KLeft, self.picImageView.bounds.size.height * 4 / 5 - kTop , self.picImageView.bounds.size.width / 8, self.picImageView.bounds.size.width / 8);
    
    self.peopleImageView.layer.cornerRadius = self.peopleImageView.bounds.size.width / 2;
    self.peopleImageView.layer.masksToBounds = YES;
    self.peopleImageView.userInteractionEnabled = YES;

    
}

- (void)tapAction:(UITapGestureRecognizer *)tap{
    self.myBlock();
}

- (void)setTrip:(Trip *)trip{
    _trip = trip;
    [_picImageView sd_setImageWithURL:[NSURL URLWithString:_trip.front_cover_photo_url] placeholderImage:nil];
    _titleLabel.text = _trip.name;
    _timeLabel.text = [NSString stringWithFormat:@"%@/%@天",_trip.start_date,_trip.days];
    [_peopleImageView sd_setImageWithURL:[NSURL URLWithString:_trip.user.image] placeholderImage:nil];
    self.peopleImageView.layer.borderWidth = 2;
    self.peopleImageView.layer.borderColor = [[UIColor cloudsColor] CGColor];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
    
    [self.peopleImageView addGestureRecognizer:tap];
}

- (void)setTrips:(Trips *)trips{
    _trips = trips;
    [_picImageView sd_setImageWithURL:[NSURL URLWithString:_trips.front_cover_photo_url] placeholderImage:nil];
    _titleLabel.text = _trips.name;
    _timeLabel.text = [NSString stringWithFormat:@"%@/%@天",_trips.start_date,_trips.days];
    
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
