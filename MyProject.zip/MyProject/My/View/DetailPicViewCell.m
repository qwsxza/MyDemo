//
//  DetailPicViewCell.m
//  MyProject
//
//  Created by 陆超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "DetailPicViewCell.h"
#import "UIImageView+WebCache.h"
#import "Notes.h"
@interface DetailPicViewCell ()
@property (nonatomic, strong) UIImageView *picImageView;

@property (nonatomic, strong) UILabel *desLabel;
@end

@implementation DetailPicViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.picImageView = [[UIImageView alloc] init];
        [self.contentView addSubview:self.picImageView];
        
        self.desLabel = [[UILabel alloc] init];
        [self.contentView addSubview:self.desLabel];
    }
    return self;
}
//
- (void)layoutSubviews{
    [super layoutSubviews];
//    self.picImageView.frame = CGRectMake(10, 10, self.contentView.bounds.size.width - 20, 250);
//    self.picImageView.layer.cornerRadius = 20;
//    self.picImageView.layer.borderWidth = 2;
//    self.picImageView.layer.borderColor = [[UIColor whiteColor] CGColor];
//    self.picImageView.layer.masksToBounds = YES;
//    
//    self.desLabel.frame = CGRectMake(self.picImageView.frame.origin.x, CGRectGetMaxY(_picImageView.frame) + 10, self.picImageView.bounds.size.width, 100);
//    self.desLabel.numberOfLines = 0;
//    [self.desLabel sizeToFit];
    if ([_notes.url length] == 0) {
        self.picImageView.frame = CGRectZero;
        self.picImageView.image = nil;
        self.desLabel.frame = CGRectMake(10, CGRectGetMaxY(_picImageView.frame) + 10, self.contentView.bounds.size.width - 20, 100);
        self.desLabel.numberOfLines = 0;
        [self.desLabel sizeToFit];
    }else{
        self.picImageView.frame = CGRectMake(10, 10, self.contentView.bounds.size.width - 20, 250);
        self.desLabel.frame = CGRectMake(self.picImageView.frame.origin.x, CGRectGetMaxY(_picImageView.frame) + 10, self.picImageView.bounds.size.width, 100);
        self.desLabel.numberOfLines = 0;
        [self.desLabel sizeToFit];
        [self.picImageView sd_setImageWithURL:[NSURL URLWithString:_notes.url] placeholderImage:nil];}

}

- (void)setNotes:(Notes *)notes{
    _notes = notes;
    if ([_notes.des isEqualToString:@"(null)"]) {
        self.desLabel.text = @"";
    }else{
        self.desLabel.text = _notes.des;
        
    }
    if ([_notes.url length] == 0) {
        self.picImageView.frame = CGRectZero;
        self.picImageView.image = nil;
        self.desLabel.frame = CGRectMake(self.picImageView.frame.origin.x, CGRectGetMaxY(_picImageView.frame) + 10, self.picImageView.bounds.size.width, 100);
        self.desLabel.numberOfLines = 0;
        [self.desLabel sizeToFit];
    }else{
        self.picImageView.frame = CGRectMake(10, 10, self.contentView.bounds.size.width - 20, 250);
        self.desLabel.frame = CGRectMake(self.picImageView.frame.origin.x, CGRectGetMaxY(_picImageView.frame) + 10, self.picImageView.bounds.size.width, 100);
        self.desLabel.numberOfLines = 0;
        [self.desLabel sizeToFit];
        [self.picImageView sd_setImageWithURL:[NSURL URLWithString:_notes.url] placeholderImage:nil];}
    
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
