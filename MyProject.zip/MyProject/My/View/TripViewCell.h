//
//  TripViewCell.h
//  MyProject
//
//  Created by 陆超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Trip;
@class Trips;
@interface TripViewCell : UITableViewCell
@property (nonatomic, strong) Trip *trip;
@property (nonatomic, copy) void (^myBlock)();
@property (nonatomic, strong) Trips *trips;
@end
