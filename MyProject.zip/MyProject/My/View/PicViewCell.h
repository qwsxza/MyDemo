//
//  PicViewCell.h
//  MyProject
//
//  Created by 陆超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <UIKit/UIKit.h>
@class TopPic;
@interface PicViewCell : UITableViewCell
@property (nonatomic, strong) NSMutableArray *picImageArray;
@property (nonatomic, copy) void (^myBlock)(TopPic *);
@end
