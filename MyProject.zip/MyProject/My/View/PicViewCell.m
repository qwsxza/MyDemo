//
//  PicViewCell.m
//  MyProject
//
//  Created by 陆超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "PicViewCell.h"
#import "UIImageView+WebCache.h"
#import "TopPic.h"
@interface PicViewCell ()<UIScrollViewDelegate>
@property (nonatomic, strong) UIImageView *imageView0;
@property (nonatomic, strong) UIImageView *imageView1;
@property (nonatomic, strong) UIImageView *imageView2;
@property (nonatomic, strong) UIImageView *imageView3;
@property (nonatomic, strong) UIScrollView *scrollView;
@end
@implementation PicViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.scrollView = [[UIScrollView alloc] init];
        [self.contentView addSubview:self.scrollView];
        
        self.imageView0 = [[UIImageView alloc] init];
        [self.scrollView addSubview:self.imageView0];
        
        self.imageView1 = [[UIImageView alloc] init];
        [self.scrollView addSubview:self.imageView1];
        
        self.imageView2 = [[UIImageView alloc] init];
        [self.scrollView addSubview:self.imageView2];
        
        self.imageView3 = [[UIImageView alloc] init];
        [self.scrollView addSubview:self.imageView3];
        
       [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(autoPlay:) userInfo:nil repeats:YES];
    }
    return self;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    self.scrollView.frame = CGRectMake(0, 0, self.contentView.bounds.size.width, self.contentView.bounds.size.height);
    self.scrollView.contentSize = CGSizeMake(self.contentView.bounds.size.width * 4, 0);
    self.scrollView.contentOffset = CGPointMake(self.contentView.bounds.size.width, 0);
    self.scrollView.pagingEnabled = YES;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.delegate = self;
    self.imageView0.frame = CGRectMake(0, 0, self.contentView.bounds.size.width, self.contentView.bounds.size.height);
    self.imageView1.frame = CGRectMake(CGRectGetMaxX(_imageView0.frame), 0, self.imageView0.bounds.size.width, self.imageView0.bounds.size.height);
    self.imageView2.frame = CGRectMake(CGRectGetMaxX(_imageView1.frame), 0, self.imageView1.bounds.size.width, self.imageView1.bounds.size.height);
    self.imageView3.frame = CGRectMake(CGRectGetMaxX(_imageView2.frame), 0, self.imageView2.bounds.size.width, self.imageView2.bounds.size.height);
    for (int i = 0 ; i < [_picImageArray count]; i++) {
        UIButton *button = [UIButton buttonWithType:(UIButtonTypeSystem)];
        button.frame = CGRectMake(self.scrollView.bounds.size.width * i, 0, self.contentView.bounds.size.width, self.scrollView.bounds.size.height);
        button.tag = 2000 + i;
        [button addTarget:self action:@selector(clickAction:) forControlEvents:(UIControlEventTouchUpInside)];
        [self.scrollView addSubview:button];
    }
    
}

- (void)clickAction:(UIButton *)button{
    TopPic *topPic = [[TopPic alloc] init];
    if (button.tag == 2000 || button.tag == 2003) {
        topPic = _picImageArray[2];
    }else if (button.tag == 2001){
        topPic = _picImageArray[0];
    }else if (button.tag == 2002){
        topPic = _picImageArray[1];
    }
    self.myBlock(topPic);
    
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (scrollView.contentOffset.x >= self.scrollView.bounds.size.width * 3) {
        scrollView.contentOffset = CGPointZero;
    }
}
- (void)autoPlay:(NSTimer *)timer{
   
    
    CGFloat width = self.scrollView.bounds.size.width;
    CGPoint offset = self.scrollView.contentOffset;
    if (offset.x >= 3 * width) {
        [self.scrollView setContentOffset:(CGPointZero) animated:NO];
        [self.scrollView setContentOffset:(CGPointMake(width, 0)) animated:YES];
                CATransition *transition = [CATransition animation];
                transition.type = @"cube";
                transition.subtype = kCAGravityTopRight;
                transition.duration = 1;
                [self.scrollView.layer addAnimation:transition forKey:@"cube"];
    }else{
        [self.scrollView setContentOffset:(CGPointMake(width + offset.x, 0)) animated:YES];
                CATransition *transition = [CATransition animation];
                transition.type = @"rippleEffect";
                transition.subtype = kCAGravityTopRight;
                transition.duration = 1;
                [self.scrollView.layer addAnimation:transition forKey:@"rippleEffect"];
        
    }
    
    
}

- (void)setPicImageArray:(NSMutableArray *)picImageArray{
    _picImageArray = picImageArray;
    if ([_picImageArray count] != 0) {
        [_imageView0 sd_setImageWithURL:[NSURL URLWithString:[_picImageArray[2] image_url]] placeholderImage:nil];
        [_imageView1 sd_setImageWithURL:[NSURL URLWithString:[_picImageArray[0] image_url]] placeholderImage:nil];
        [_imageView2 sd_setImageWithURL:[NSURL URLWithString:[_picImageArray[1] image_url]] placeholderImage:nil];
        [_imageView3 sd_setImageWithURL:[NSURL URLWithString:[_picImageArray[2] image_url]] placeholderImage:nil];
    }
    
    
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
