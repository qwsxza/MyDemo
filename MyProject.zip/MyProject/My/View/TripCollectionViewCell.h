//
//  TripCollectionViewCell.h
//  MyProject
//
//  Created by 陆超 on 15/11/9.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <UIKit/UIKit.h>
@class TripPicture;
@interface TripCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong) TripPicture *tripPic;
@end
