//
//  TripCollectionViewCell.m
//  MyProject
//
//  Created by 陆超 on 15/11/9.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "TripCollectionViewCell.h"

#import "UIImageView+WebCache.h"
#import "TripPicture.h"
@interface TripCollectionViewCell ()
@property (nonatomic, strong) UIImageView *tripImageView;
@end

@implementation TripCollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.tripImageView = [[UIImageView alloc] init];
        [self.contentView addSubview:self.tripImageView];
    }
    return self;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    self.tripImageView.frame = CGRectMake(0, 0, self.contentView.bounds.size.width, self.contentView.bounds.size.height);
}

- (void)setTripPic:(TripPicture *)tripPic{
    _tripPic = tripPic;
  
    [_tripImageView sd_setImageWithURL:[NSURL URLWithString:_tripPic.photo_url] placeholderImage:nil];
}
@end
