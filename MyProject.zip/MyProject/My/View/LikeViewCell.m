//
//  LikeViewCell.m
//  MyProject
//
//  Created by 陆超 on 15/11/9.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "LikeViewCell.h"
#import "TripCollectionViewCell.h"
#import "TripPicture.h"
@interface LikeViewCell ()<UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) UICollectionViewFlowLayout *flowLayout;
@end

@implementation LikeViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
    
        _flowLayout = [[UICollectionViewFlowLayout alloc] init];
        
        
        self.collectionView = [[UICollectionView alloc] initWithFrame:(CGRectMake(0, 0, self.contentView.bounds.size.width, self.contentView.bounds.size.height)) collectionViewLayout:_flowLayout];
        self.collectionView.backgroundColor = [UIColor whiteColor];
        self.collectionView.delegate = self;
        self.collectionView.dataSource = self;
        self.collectionView.scrollEnabled = NO;
        [self.contentView addSubview:self.collectionView];
        [self.collectionView registerClass:[TripCollectionViewCell class] forCellWithReuseIdentifier:@"class"];
    }
    return self;
}

- (void)layoutSubviews{

    [super layoutSubviews];
    
    _flowLayout.itemSize = CGSizeMake(self.contentView.bounds.size.width / 3.5, self.contentView.bounds.size.width / 3.5);
    _flowLayout.minimumLineSpacing = 20;
    _flowLayout.minimumInteritemSpacing = 10;
    _flowLayout.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
    self.collectionView.frame = (CGRectMake(0, 0, self.contentView.bounds.size.width, self.contentView.bounds.size.height));

}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return [_tripsArray count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    TripCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"class" forIndexPath:indexPath];
    cell.tripPic = _tripsArray[indexPath.item];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    self.myBlock(indexPath.item);
}

- (void)setTripsArray:(NSMutableArray *)tripsArray{
    _tripsArray = tripsArray;
   
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
