//
//  MovieViewCell.m
//  MyProject
//
//  Created by 陆超 on 15/11/12.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "MovieViewCell.h"
#import "Movie.h"
#import "UIImageView+WebCache.h"

#define KLeft 10
#define kTop 10

@interface MovieViewCell ()
@property (nonatomic, strong) UIImageView *movieImageView;
@property (nonatomic, strong) UIImageView *coverImageView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *tipsLabel;
@end

@implementation MovieViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.movieImageView = [[UIImageView alloc] init];
        [self.contentView addSubview:self.movieImageView];
        
        self.coverImageView = [[UIImageView alloc] init];
        [self.contentView addSubview:self.coverImageView];
        
        self.titleLabel = [[UILabel alloc] init];
        [self.coverImageView addSubview:self.titleLabel];
        
        self.tipsLabel = [[UILabel alloc] init];
        [self.coverImageView addSubview:self.tipsLabel];
        
    }
    return self;
}



- (void)layoutSubviews{
    [super layoutSubviews];
    self.movieImageView.frame = CGRectMake(KLeft, kTop, self.contentView.bounds.size.width - 2 * KLeft, self.contentView.bounds.size.height - 2 * kTop);
    self.movieImageView.layer.borderWidth = 2;
    self.movieImageView.layer.cornerRadius = 20;
    self.movieImageView.layer.masksToBounds = YES;
    self.movieImageView.userInteractionEnabled = YES;
    self.movieImageView.layer.borderColor = [UIColor whiteColor].CGColor;
    self.coverImageView.frame = self.movieImageView.frame;
    self.coverImageView.backgroundColor = [UIColor colorWithRed:0.1 green:0.1 blue:0.1 alpha:0.4];
    self.coverImageView.layer.borderWidth = 2;
    self.coverImageView.layer.cornerRadius = 20;
    self.coverImageView.layer.masksToBounds = YES;
    self.coverImageView.layer.borderColor = [UIColor whiteColor].CGColor;
    self.coverImageView.userInteractionEnabled = YES;
    self.titleLabel.frame = CGRectMake(0, self.movieImageView.bounds.size.height / 2 - 60, self.movieImageView.bounds.size.width, 40);
    self.titleLabel.font = [UIFont systemFontOfSize:20];
    self.titleLabel.textColor = [UIColor whiteColor];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    
    self.tipsLabel.frame = CGRectMake(0, CGRectGetMaxY(_titleLabel.frame), self.titleLabel.bounds.size.width, 40);
    self.tipsLabel.textColor = [UIColor whiteColor];
    self.tipsLabel.textAlignment = NSTextAlignmentCenter;
    
   
 
}


//- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
//    self.coverImageView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
//    
//}
//
//- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
//    self.coverImageView.backgroundColor = [UIColor colorWithRed:0.1 green:0.1 blue:0.1 alpha:0.4];
//}

- (void)setMovie:(Movie *)movie{
    _movie = movie;
    [self.movieImageView sd_setImageWithURL:[NSURL URLWithString:_movie.coverForFeed] placeholderImage:nil];
    self.titleLabel.text = _movie.title;
    NSInteger min = [_movie.duration intValue] / 60;
    NSInteger sec = [_movie.duration intValue] % 60;
    self.tipsLabel.text = [NSString stringWithFormat:@"#%@  /  %0.2ld'%0.2ld''",_movie.category,(long)min,(long)sec];
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
