//
//  LikeViewCell.h
//  MyProject
//
//  Created by 陆超 on 15/11/9.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LikeViewCell : UITableViewCell
@property (nonatomic, strong) NSMutableArray *tripsArray;
@property (nonatomic, copy) void (^myBlock)(NSInteger page);
@end
