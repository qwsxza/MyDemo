//
//  PicDetailViewController.h
//  MyProject
//
//  Created by gp on 15/11/10.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "ViewController.h"

@interface PicDetailViewController : ViewController
@property (nonatomic, strong) NSMutableArray *picArray;
@property (nonatomic, assign) NSInteger page;
@end
