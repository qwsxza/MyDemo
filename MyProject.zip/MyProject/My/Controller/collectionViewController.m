//
//  collectionViewController.m
//  MyProject
//
//  Created by gp on 15/11/14.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "collectionViewController.h"
#import "FavoriteDataHandle.h"
#import "Movie.h"
#import "MovieDetailViewController.h"
#import "DataBaseHandle.h"
#import "CollectionCell.h"

@interface collectionViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UIImageView *backImageView;
@property (nonatomic, strong) UIImageView *coverImageView;

@end

@implementation collectionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.titleLabel.text = @"我的视频";
    self.backImageView = [[UIImageView alloc] initWithFrame:(CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height))];
    self.backImageView.image = [UIImage imageNamed:@"night1.jpg"];
//      self.backImageView.contentMode = UIViewContentModeScaleAspectFill;
    [self.backView addSubview:self.backImageView];
    self.backView.backgroundColor = [UIColor blackColor];
    
   
    
    
    self.tableView = [[UITableView alloc] initWithFrame:(CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height)) style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.backView addSubview:self.tableView];
    
    self.tableView.backgroundColor = [UIColor clearColor];
    
    self.tableView.tableFooterView = [[UIView alloc] init];
    
    [[FavoriteDataHandle shareInstance]setupMovieDataSource];
    
    [self changePicture:nil];
    [NSTimer scheduledTimerWithTimeInterval:22 target:self selector:@selector(changePicture:) userInfo:nil repeats:YES];
    
    
}


- (void)changePicture:(NSTimer *)timer{
    
    [UIView animateWithDuration:5 animations:^{
        
        self.backImageView.alpha = 0.3;
        self.backImageView.image = [UIImage imageNamed:@"night1.jpg"];
        
    } completion:^(BOOL finished) {
        
        [UIView animateWithDuration:5  animations:^{
            self.backImageView.image = [UIImage imageNamed:@"night2.jpeg"];
            
            self.backImageView.alpha = 1;

        } completion:^(BOOL finished) {
            
            [UIView animateWithDuration:5 animations:^{
                
                self.backImageView.alpha = 0.3;
                
        } completion:^(BOOL finished) {
            
            [UIView animateWithDuration:5 animations:^{
                self.backImageView.image = [UIImage imageNamed:@"night3.jpg"];
                
                
            } completion:^(BOOL finished) {
                [UIView animateWithDuration:3 animations:^{
                    self.backImageView.alpha = 1;
                } completion:^(BOOL finished) {

                    
                }];
            }];
            
        }];
        }];
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    
    return [[FavoriteDataHandle shareInstance] countOfMovie];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    

    return 160;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuseIdentifer = @"cell";
    CollectionCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifer];
    if (!cell) {
        cell = [[CollectionCell alloc] initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:reuseIdentifer];
    }
    cell.movie = [DataBaseHandle selectAllMovie][indexPath.row];
    cell.backgroundColor = [UIColor clearColor];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    MovieDetailViewController *movieDetaiVC = [[MovieDetailViewController alloc] init];
    
    movieDetaiVC.movieDetailArray = [[DataBaseHandle selectAllMovie] mutableCopy];
    movieDetaiVC.isCollectionV = @"collect";
    [movieDetaiVC setReload:^{
         [[FavoriteDataHandle shareInstance]setupMovieDataSource];
        [self.tableView reloadData];
    }];
    
    movieDetaiVC.page = indexPath.row;
    [self.navigationController pushViewController:movieDetaiVC animated:YES];
    

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
