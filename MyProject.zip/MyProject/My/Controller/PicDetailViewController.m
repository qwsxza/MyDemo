//
//  PicDetailViewController.m
//  MyProject
//
//  Created by gp on 15/11/10.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "PicDetailViewController.h"
#import "UIImageView+WebCache.h"
#import "TripPicture.h"
@interface PicDetailViewController ()<UIScrollViewDelegate>
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIImageView *picImageView;
@property (nonatomic, strong) UILabel *desLabel;
@end

@implementation PicDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.topView.backgroundColor = [UIColor blackColor];
    self.backView.backgroundColor = [UIColor blackColor];
    
    self.scrollView = [[UIScrollView alloc] initWithFrame:(CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height))];
    [self.backView addSubview:self.scrollView];
    self.picImageView = [[UIImageView alloc] initWithFrame:(CGRectMake(0, self.backView.bounds.size.height / 5, self.backView.bounds.size.width, self.backView.bounds.size.height *1/2))];
    
    self.scrollView.contentSize = CGSizeMake([_picArray count] * self.backView.bounds.size.width, 0);
    self.scrollView.contentOffset = CGPointMake(_page * self.backView.bounds.size.width, 0);
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.pagingEnabled = YES;
    self.scrollView.delegate = self;
    
    for (int i = 0; i < [_picArray count]; i++) {
        UIImageView *picImageView = [[UIImageView alloc] initWithFrame:(CGRectMake(i * self.scrollView.bounds.size.width, self.scrollView.bounds.size.height / 5, self.scrollView.bounds.size.width, self.scrollView.bounds.size.height *1/2))];
        [picImageView sd_setImageWithURL:[NSURL URLWithString:[_picArray[i] photo_url]] placeholderImage:nil];
        picImageView.contentMode = UIViewContentModeRedraw;
        [self.scrollView addSubview:picImageView];
    }
    
    self.desLabel = [[UILabel alloc] initWithFrame:(CGRectMake(0, self.backView.bounds.size.height *4/5, self.backView.bounds.size.width, self.backView.bounds.size.height / 5))];
    self.desLabel.numberOfLines = 0;
    self.desLabel.textColor = [UIColor whiteColor];
    self.desLabel.text = [_picArray[_page] picDes];
    [self.backView addSubview:self.desLabel];

    
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    NSInteger i = scrollView.contentOffset.x / scrollView.bounds.size.width;
    self.desLabel.text = [_picArray[i] picDes];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
