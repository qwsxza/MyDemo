//
//  CollectionCell.m
//  MyProject
//
//  Created by gp on 15/11/14.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "CollectionCell.h"
#import "Movie.h"
@interface CollectionCell ()
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *typeLabel;
@property (nonatomic, strong) UIImageView *backImageView;
@property (nonatomic, strong) UILabel *desLabel;
@end

@implementation CollectionCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backImageView = [[UIImageView alloc] init];
        [self.contentView addSubview:self.backImageView];
        self.titleLabel = [[UILabel alloc] init];
        [self.contentView addSubview:self.titleLabel];
        
        self.typeLabel = [[UILabel alloc] init];
        [self.contentView addSubview:self.typeLabel];
        
        
        self.desLabel = [[UILabel alloc] init];
        [self.contentView addSubview:self.desLabel];
    }
    
    return self;
}

- (void)layoutSubviews{
    [super layoutSubviews];
    
    self.backImageView.frame = CGRectMake(10, 10, self.contentView.bounds.size.width - 20, self.contentView.bounds.size.height - 20);
    self.backImageView.backgroundColor = [UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:0.4];
    self.backImageView.layer.cornerRadius = 10;
    self.backImageView.layer.masksToBounds = YES;

    self.titleLabel.frame = CGRectMake(15, self.backImageView.frame.origin.y , self.backImageView.bounds.size.width, 40);
    self.titleLabel.textColor = [UIColor whiteColor];
    self.titleLabel.font = [UIFont systemFontOfSize:20];
    
    self.typeLabel.frame = CGRectMake(self.titleLabel.frame.origin.x, CGRectGetMaxY(_titleLabel.frame), self.titleLabel.bounds.size.width, 30);
    self.typeLabel.textColor = [UIColor whiteColor];
    
    self.desLabel.frame = CGRectMake(self.typeLabel.frame.origin.x, CGRectGetMaxY(_typeLabel.frame), self.typeLabel.bounds.size.width, 30);
    self.desLabel.textColor = [UIColor whiteColor];
    self.desLabel.numberOfLines = 3;
    [self.desLabel sizeToFit];
    
}

- (void)setMovie:(Movie *)movie{
    _movie = movie;
    _titleLabel.text = movie.title;
    NSInteger min = [_movie.duration intValue] / 60;
    NSInteger sec = [_movie.duration intValue] % 60;
    self.typeLabel.text = [NSString stringWithFormat:@"#%@  /  %0.2ld'%0.2ld''",_movie.category,min,sec];
    self.desLabel.text = _movie.movieDes;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
