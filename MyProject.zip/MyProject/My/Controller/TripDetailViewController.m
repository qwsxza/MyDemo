//
//  TripDetailViewController.m
//  MyProject
//
//  Created by gp on 15/11/6.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "TripDetailViewController.h"
#import "AFNetworking.h"
#import "TripDetail.h"
#import "UIImageView+WebCache.h"
#import "User.h"
#import "Notes.h"
#import "DetailPicViewCell.h"
#import "MBProgressHUD.h"
#import "UserViewController.h"
#import "UMSocial.h"
#import "UIColor+AddColor.h"
@interface TripDetailViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UIImageView *backImageView;
@property (nonatomic, strong) TripDetail *tripDetail;
@property (nonatomic, strong) UIImageView *peopleImageView;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *timeLabl;
@property (nonatomic, strong) NSMutableArray *trip_daysArray;
@property (nonatomic, strong) MBProgressHUD *hud;

@end

@implementation TripDetailViewController

- (void)p_setupProgressHud
{
    self.hud = [[MBProgressHUD alloc]initWithView:self.view];
    self.hud.frame = self.view.bounds;
    self.hud.minSize = CGSizeMake(100, 100);
    self.hud.mode = MBProgressHUDModeIndeterminate;
    [self.view addSubview:self.hud];
    
    [self.hud show:YES];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    ;
    self.titleLabel.textColor = [UIColor whiteColor];
    
    [self p_setupProgressHud];
    [self handle];

    self.topView.backgroundColor = [UIColor colorFromHexCode:@"#408080"];
    self.view.backgroundColor = [UIColor whiteColor];
    self.tripDetail = [[TripDetail alloc] init];
    self.tableView = [[UITableView alloc] initWithFrame:(CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height )) style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.rowHeight = 300;
    self.tableView.backgroundColor = [UIColor clearColor];
 
    self.tableView.contentInset = UIEdgeInsetsMake(250, 0, 0, 0);
    [self.backView addSubview:self.tableView];
    self.backImageView = [[UIImageView alloc] initWithFrame:(CGRectMake(0, -20, self.backView.bounds.size.width, 250))];
    //self.backImageView.contentMode = UIViewContentModeScaleAspectFill;
    [self.backView addSubview:self.backImageView];
    
    self.peopleImageView = [[UIImageView alloc] initWithFrame:(CGRectMake(self.backImageView.bounds.size.width / 2 - 30, self.backImageView.bounds.size.height - 60, 60, 60))];
    self.peopleImageView.layer.borderColor = [[UIColor whiteColor] CGColor];
    self.peopleImageView.layer.borderWidth = 2;
    self.peopleImageView.layer.cornerRadius = 30;
    self.peopleImageView.layer.masksToBounds = YES;
    self.peopleImageView.userInteractionEnabled = YES;
    [self.backImageView addSubview:self.peopleImageView];
    
    self.nameLabel = [[UILabel alloc] initWithFrame:(CGRectMake(20, self.backImageView.bounds.size.height / 4, self.backImageView.bounds.size.width - 40, 40))];
    self.nameLabel.numberOfLines = 2;
    self.nameLabel.textColor = [UIColor whiteColor];
    self.nameLabel.font = [UIFont systemFontOfSize:20 weight:1];
    [self.backImageView addSubview:self.nameLabel];
    
    self.timeLabl = [[UILabel alloc] initWithFrame:(CGRectMake(self.nameLabel.frame.origin.x, CGRectGetMaxY(_nameLabel.frame), self.nameLabel.bounds.size.width, self.nameLabel.bounds.size.height))];
    self.timeLabl.textColor = [UIColor whiteColor];
    [self.backImageView addSubview:self.timeLabl];
    self.backImageView.userInteractionEnabled = YES;
    self.trip_daysArray = [NSMutableArray array];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
    [self.peopleImageView addGestureRecognizer:tap];
    
    [self.view bringSubviewToFront:self.topView];
    
    UIButton *button = [UIButton buttonWithType:(UIButtonTypeCustom)];
    button.frame = CGRectMake(self.topView.bounds.size.width - 100, self.topView.bounds.size.height / 2 - 10, 100, self.topView.bounds.size.height / 2);
    [button setImage:[UIImage imageNamed:@"show"] forState:(UIControlStateNormal)];
    [button addTarget:self action:@selector(shareAction:) forControlEvents:(UIControlEventTouchUpInside)];
    [self.topView addSubview:button];
    
}

- (void)shareAction:(UIButton *)button{
    
    NSString *shareText = self.nameLabel.text;
    UIImage *image = self.backImageView.image;
//    [UMSocialSnsService presentSnsIconSheetView:self
//                                         appKey:nil
//                                      shareText:shareText                                     shareImage:image
//                                shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToWechatSession,UMShareToQQ,nil]
//                                       delegate:nil];
//    
//    }
    [UMSocialSnsService presentSnsIconSheetView:self
                                     appKey:@"564afa5267e58e6a53001c0c"
                                  shareText:shareText
                                 shareImage:image
                            shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToDouban, UMShareToEmail, UMShareToSms,nil]
                                   delegate:nil];
    }
- (void)tapAction:(UITapGestureRecognizer *)tap{
    UserViewController *userVC = [[UserViewController alloc] init];
    userVC.userID = _tripDetail.user.userID;
    [self.navigationController pushViewController:userVC animated:YES];
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    
    CGFloat y = scrollView.contentOffset.y + 23;
    if (-y/250 >=1) {
        self.backImageView.transform = CGAffineTransformMakeScale(-y/250, -y/250);
//        CGRect frame = self.backImageView.frame;
//        frame.origin.y = y + 230;
//        self.backImageView.frame = frame;
    }
    if (-(y+250)<0) {
        [self setY:-(y+250)-5];
    }
//
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [_trip_daysArray count];
}




-(void)setY:(CGFloat)Y{
    CGRect frame = self.backImageView.frame;
    frame.origin.y = Y;
    self.backImageView.frame = frame;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuseIdentifer = @"cell";
    DetailPicViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifer];
    if (!cell) {
        cell = [[DetailPicViewCell alloc] initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:reuseIdentifer];
    }
    cell.notes = _trip_daysArray[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
  
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    Notes *notes = _trip_daysArray[indexPath.row];
    NSDictionary *dic = @{NSFontAttributeName:[UIFont systemFontOfSize:17]};
    CGRect rect = [notes.des boundingRectWithSize:(CGSizeMake(self.view.bounds.size.width - 20, NSIntegerMax)) options:(NSStringDrawingUsesLineFragmentOrigin) attributes:dic context:nil];
    if ([notes.url length] == 0) {
        return rect.size.height + 20;
    }else{
    return 250 + rect.size.height + 20;
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)handle{
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    [manager GET:[NSString stringWithFormat:@"http://chanyouji.com/api/trips/%@.json",_tripID] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [_tripDetail setValuesForKeysWithDictionary:responseObject];
        [self.backImageView sd_setImageWithURL:[NSURL URLWithString:_tripDetail.front_cover_photo_url] placeholderImage:nil];
        [self.peopleImageView sd_setImageWithURL:[NSURL URLWithString:_tripDetail.user.image] placeholderImage:nil];
        
        self.nameLabel.text = _tripDetail.name;
        self.timeLabl.text = [NSString stringWithFormat:@"%@~%@",_tripDetail.start_date,_tripDetail.end_date];
        self.titleLabel.text = _tripDetail.name;
        
        NSArray *trip_days = _tripDetail.trip_days;
        for (NSDictionary *dic in trip_days) {
            NSArray *nodesArray = dic[@"nodes"];
            for (NSDictionary *dic in nodesArray) {
                NSArray *notesArray = dic[@"notes"];
                if (notesArray.count != 0) {
                    for (NSDictionary *dic in notesArray) {
                        NSString *description = dic[@"description"];
                        NSString *url;
                        if ([[dic allKeys] containsObject:@"photo"]) {
                            url = dic[@"photo"][@"url"];
                        } else {
                            url = @"";
                        }
                        NSDictionary *dic = @{@"description":description,@"url":url,@"name":_tripDetail.name};
                        Notes *notes = [[Notes alloc] init];
                        [notes setValuesForKeysWithDictionary:dic];
                        [self.trip_daysArray addObject:notes];
                    }
                }
            }
        }
       
        [self.hud hide:YES];
        [self.tableView reloadData];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [self.hud removeFromSuperview];
    }];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
