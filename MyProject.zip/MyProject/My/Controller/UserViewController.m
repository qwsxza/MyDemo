//
//  UserViewController.m
//  MyProject
//
//  Created by gp on 15/11/9.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "UserViewController.h"
#import "AFNetworking.h"
#import "UserDetail.h"
#import "Trips.h"
#import "UIImageView+WebCache.h"
#import "UIColor+AddColor.h"
#import "TripViewCell.h"
#import "LikeViewCell.h"
#import "TripDetailViewController.h"
#import "TripPicture.h"
#import "PicDetailViewController.h"
#import "MJRefresh.h"
@interface UserViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UserDetail *userDetail;
@property (nonatomic, strong) UILabel *label;
@property (nonatomic, assign) BOOL isChoose;
@property (nonatomic, strong) NSMutableArray *picArray;

@end

@implementation UserViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.topView.backgroundColor = [UIColor blackColor];

    
    self.tableView = [[UITableView alloc] initWithFrame:(CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height)) style:(UITableViewStylePlain)];
    
    // Do any additional setup after loading the view.
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.backgroundColor = [UIColor whiteColor];
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.tableFooterView = [[UIView alloc] init];

    [self.backView addSubview:self.tableView];
    self.isChoose = YES;
    self.picArray = [NSMutableArray array];
    
    [self handleWith:self.userID AndPage:1];
  
    
    [self handleBy:_userID andPage:1];
    
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (self.isChoose == YES) {
        
        return [_userDetail.trips count];
    }else{
        return 1;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return  140;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.isChoose == YES) {
        
        return 250;
    }else{
        if ([_picArray count] % 3 == 0 ) {
            return ([_picArray count] / 3 ) * 140;
        }else{
        return ([_picArray count] / 3 + 1) * 140;
        }
    }
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view = [[UIView alloc] initWithFrame:(CGRectMake(0, 0, self.backView.bounds.size.width, 200))];
    view.backgroundColor = [UIColor whiteColor];
    UIImageView *peopleImageView = [[UIImageView alloc] initWithFrame:(CGRectMake(10, 10, view.bounds.size.width / 6, view.bounds.size.width / 6))];
    peopleImageView.layer.cornerRadius = peopleImageView.bounds.size.width / 2;
    peopleImageView.layer.borderWidth = 2;
    peopleImageView.layer.borderColor = [[UIColor whiteColor] CGColor];
    peopleImageView.layer.masksToBounds = YES;
    [peopleImageView sd_setImageWithURL:[NSURL URLWithString:_userDetail.image] placeholderImage:nil];
    
    [view addSubview:peopleImageView];
    
    UILabel *nameLabel = [[UILabel alloc] initWithFrame:(CGRectMake(CGRectGetMaxX(peopleImageView.frame) + 10, peopleImageView.frame.origin.y, view.bounds.size.width - CGRectGetMaxX(peopleImageView.frame)- 10 - 10, peopleImageView.bounds.size.height / 2))];
    nameLabel.text = _userDetail.name;

    [view addSubview:nameLabel];
    
    UILabel *countLabel = [[UILabel alloc] initWithFrame:(CGRectMake(nameLabel.frame.origin.x, CGRectGetMaxY(nameLabel.frame), nameLabel.bounds.size.width, nameLabel.bounds.size.height))];
    countLabel.text = [NSString stringWithFormat:@"%@篇游记",_userDetail.trips_count];
    [view addSubview:countLabel];
    
    UIButton *tripButton = [UIButton buttonWithType:(UIButtonTypeSystem)];
    tripButton.frame = CGRectMake(0, CGRectGetMaxY(peopleImageView.frame) + 10, (view.bounds.size.width )/ 2, countLabel.bounds.size.height);
    [tripButton setTitle:@"游记" forState:(UIControlStateNormal)];
    tripButton.titleLabel.font = [UIFont systemFontOfSize:20];
    if (self.isChoose == YES) {
        
        tripButton.tintColor = [UIColor jinjuse];
    }else{
        tripButton.tintColor = [UIColor blackColor];
    }
    tripButton.layer.borderWidth = 1;
    tripButton.tag = 2500;
    tripButton.layer.borderColor = [[UIColor silverColor] CGColor];
    [tripButton addTarget:self action:@selector(chooseAction:) forControlEvents:(UIControlEventTouchUpInside)];
    [view addSubview:tripButton];
    
    
    UIButton *likeButton = [UIButton buttonWithType:(UIButtonTypeSystem)];
        
        likeButton.frame = CGRectMake(CGRectGetMaxX(tripButton.frame), CGRectGetMaxY(peopleImageView.frame) + 10, (view.bounds.size.width  )/ 2, countLabel.bounds.size.height);
    
    [likeButton setTitle:@"喜欢" forState:(UIControlStateNormal)];
    likeButton.titleLabel.font = [UIFont systemFontOfSize:20];
    likeButton.layer.borderWidth = 1;
    likeButton.tag = 2501;
    likeButton.layer.borderColor = [[UIColor silverColor] CGColor];
    if (self.isChoose == NO) {
        likeButton.tintColor = [UIColor jinjuse];
    }else{
    
        likeButton.tintColor = [UIColor blackColor];
    }
    [likeButton addTarget:self action:@selector(chooseAction:) forControlEvents:(UIControlEventTouchUpInside)];
    [view addSubview:likeButton];
    
    
    if (self.isChoose == YES) {
        
        [UIView animateWithDuration:0.5 animations:^{
            
            self.label = [[UILabel alloc] initWithFrame:(CGRectMake(0, CGRectGetMaxY(tripButton.frame), tripButton.bounds.size.width, 2))];
        } completion:nil];
        
        
    }else{
        
        [UIView animateWithDuration:0.5 animations:^{
            
            self.label = [[UILabel alloc] initWithFrame:(CGRectMake(likeButton.frame.origin.x, CGRectGetMaxY(tripButton.frame), tripButton.bounds.size.width, 2))];
        } completion:nil];
    }
    self.label.backgroundColor = [UIColor jinjuse];
    [view addSubview:self.label];
    
    return view;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.isChoose == YES) {
        TripDetailViewController *tripDetailVC = [[TripDetailViewController alloc] init];
        Trips *trips = _userDetail.trips[indexPath.row];
        tripDetailVC.tripID = trips.tripsID;
        [self.navigationController pushViewController:tripDetailVC animated:YES];
    }
}
- (void)chooseAction:(UIButton *)button{
    UIButton *button1 = (UIButton *)[self.tableView viewWithTag:2500];
    UIButton *button2 = (UIButton *)[self.tableView viewWithTag:2501];
    button1.tintColor = [UIColor blackColor];
    button2.tintColor = [UIColor blackColor];
    if (button.tag == 2500) {
        self.isChoose = YES;
        button.tintColor = [UIColor jinjuse];
        [UIView animateWithDuration:0.2 animations:^{
            self.label.frame = CGRectMake(button.frame.origin.x, CGRectGetMaxY(button.frame), button.bounds.size.width, 2);
        } completion:nil];

    }
    
    if (button.tag == 2501) {
        self.isChoose = NO;
        button.tintColor = [UIColor jinjuse];
        [UIView animateWithDuration:0.2 animations:^{
            self.label.frame = CGRectMake(button.frame.origin.x, CGRectGetMaxY(button.frame), button.bounds.size.width, 2);
        } completion:nil];
    }
    [self.tableView reloadData];
}





- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.isChoose == YES) {
        
        static NSString *reuseIdentifer = @"cell";
        TripViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifer];
        if (!cell) {
            cell = [[TripViewCell alloc] initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:reuseIdentifer];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.trips = _userDetail.trips[indexPath.row];
        return  cell;
    }else{
        static NSString *reuseIdentifer = @"cell1";
        LikeViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifer];
        if (!cell) {
            cell = [[LikeViewCell alloc] initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:reuseIdentifer];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.tripsArray = _picArray;
        [cell setMyBlock:^(NSInteger page) {
            PicDetailViewController *picDetailVC = [[PicDetailViewController alloc] init];
            picDetailVC.picArray = _picArray;
            picDetailVC.page = page;
            [self.navigationController pushViewController:picDetailVC animated:YES];
        }];
        return cell;
    }
}

- (void)handleWith:(NSString *)userID AndPage:(NSInteger )i{
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    [manager GET:[NSString stringWithFormat:@"http://chanyouji.com/api/users/%@.json?page=%ld",userID,(long)i] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
      
        self.userDetail = [[UserDetail alloc] init];
        
        [self.userDetail setValuesForKeysWithDictionary:responseObject];
       
        [self.tableView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];

}

- (void)handleBy:(NSString *)userID andPage:(NSInteger )i{
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    [manager GET:[NSString stringWithFormat:@"http://chanyouji.com/api/users/likes/%@.json?per_page=15&page=%ld",_userID,(long)i] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        for (NSDictionary *dic in responseObject) {
           
            TripPicture *tripPic = [[TripPicture alloc] init];
            [tripPic setValuesForKeysWithDictionary:dic];
            [self.picArray addObject:tripPic];
        }
  
        [self.tableView reloadData];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
