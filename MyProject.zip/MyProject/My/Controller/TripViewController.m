//
//  TripViewController.m
//  MyProject
//
//  Created by gp on 15/11/5.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "TripViewController.h"
#import "TopPic.h"
#import "AFHTTPRequestOperationManager.h"
#import "MJRefresh.h"
#import "PicViewCell.h"
#import "PicViewController.h"
#import "Trip.h"
#import "TripViewCell.h"
#import "MBProgressHUD.h"
#import "UIColor+AddColor.h"
#import "TripDetailViewController.h"
#import "User.h"
#import "UserViewController.h"
#import "MovieViewController.h"
#import "SettingViewController.h"


@interface TripViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *topPicArray;
@property (nonatomic, strong) NSMutableArray *tripArray;

@property (nonatomic, strong) MBProgressHUD *hud;
@property (nonatomic, strong) UISegmentedControl *segment;
@property (nonatomic, strong) UIButton *movieButton;
@end

@implementation TripViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.topView.backgroundColor = [UIColor colorFromHexCode:@"#408080"];
   

    self.topView.layer.borderColor = [[UIColor whiteColor] CGColor];
    self.titleLabel.text = @"旅行的意义";
    self.titleLabel.font = [UIFont systemFontOfSize:22 weight:5];
    self.titleLabel.textColor = [UIColor whiteColor];
    self.tableView = [[UITableView alloc] initWithFrame:(CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height)) style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.rowHeight = 250;
    
    //self.tableView.backgroundColor = [UIColor blackColor];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
     self.tableView.backgroundColor = [UIColor colorFromHexCode:@"#F0FFF0"];

    [self.backView addSubview:self.tableView];
    self.topPicArray = [NSMutableArray array];
    self.tripArray = [NSMutableArray array];
    [self p_setupProgressHud];
    [self handle];
    [self handle2With:1];
    
    static NSInteger i = 2;
    self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self handle2With:i++];
    }];
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        self.tripArray = [NSMutableArray array];
        [self handle2With:1];
    }];
    
    
//    self.segment = [[UISegmentedControl alloc] initWithItems:@[@"游记",@"视频"]];
//    self.segment.frame = CGRectMake(self.backView.bounds.size.width/ 2 - self.backView.bounds.size.width / 6, self.backView.bounds.size.height * 13 / 14, self.backView.bounds.size.width  / 3, self.backView.bounds.size.height / 14);
//    self.segment.tintColor = [UIColor whiteColor];
//    self.segment.selectedSegmentIndex = 0;
//    [self.segment addTarget:self action:@selector(valueChange:) forControlEvents:(UIControlEventValueChanged)];
//
//    [self.backView addSubview:self.segment];
    
    self.movieButton = [UIButton buttonWithType:(UIButtonTypeCustom)];
    self.movieButton.frame = CGRectMake(self.view.bounds.size.width - 10 - self.view.bounds.size.width / 8, self.view.bounds.size.height / 20, self.view.bounds.size.width / 12, self.view.bounds.size.height / 20);
     //[self.movieButton setImage:[UIImage imageNamed:@"movie"] forState:(UIControlStateNormal)];
    
    [self.topView addSubview:self.movieButton];
    [self.movieButton addTarget:self action:@selector(moviePlay:) forControlEvents:(UIControlEventTouchUpInside)];
    
    
//    UIButton *settingButton = [UIButton buttonWithType:(UIButtonTypeSystem)];
//    settingButton.frame = CGRectMake(0, 0, 60, 40);
//    [settingButton setTitle:@"设置" forState:(UIControlStateNormal)];
//    [self.topView addSubview:settingButton];
//    [settingButton addTarget:self action:@selector(settingAction:) forControlEvents:(UIControlEventTouchUpInside)];
    
    

}

//- (void)settingAction:(UIButton *)button{
//    SettingViewController *settingVC = [[SettingViewController alloc] init];
//    [self.navigationController pushViewController:settingVC animated:YES];
//}

- (void)moviePlay:(UIButton *)button{
    MovieViewController *movieVC = [[MovieViewController alloc] init];
    [self.navigationController pushViewController:movieVC animated:YES];
}




//scrollView 
//static CGFloat i = 0;
//- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
//    
//    CGFloat Y = scrollView.contentOffset.y;
//    if (Y > 0) {
//        [UIView animateWithDuration:1 animations:^{
//            self.segment.frame = CGRectMake(self.backView.bounds.size.width/ 2 - self.backView.bounds.size.width / 6, self.backView.bounds.size.height , self.backView.bounds.size.width  / 3, self.backView.bounds.size.height / 14);
//        } completion:nil];
//       
//    }
//    
// 
//    if (Y < i) {
//        [UIView animateWithDuration:1 animations:^{
//            self.segment.frame = CGRectMake(self.backView.bounds.size.width/ 2 - self.backView.bounds.size.width / 6, self.backView.bounds.size.height * 13 / 14, self.backView.bounds.size.width  / 3, self.backView.bounds.size.height / 14);
//        } completion:nil];
//     
//    }
//    i = Y;
//}

- (void)p_setupProgressHud
{
    self.hud = [[MBProgressHUD alloc]initWithView:self.view];
    self.hud.frame = self.view.bounds;
    self.hud.minSize = CGSizeMake(100, 100);
    self.hud.mode = MBProgressHUDModeIndeterminate;
    [self.view addSubview:self.hud];
    
    [self.hud show:YES];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return 1;
    }
    else{
        return [_tripArray count];
    }
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 40;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    if (section == 1) {
        UIView *view = [[UIView alloc] init];
        view.backgroundColor = [UIColor whiteColor];
        UILabel *label = [[UILabel alloc] initWithFrame:(CGRectMake(0, 0, self.backView.bounds.size.width ,40))];
        label.backgroundColor = [UIColor colorFromHexCode:@"#8C8C00"];
        label.text = @"   精选 · 游记";
        label.font = [UIFont systemFontOfSize:20];
        label.textColor = [UIColor whiteColor];
        //label.layer.cornerRadius = 10;
        label.layer.masksToBounds = YES;
        [view addSubview:label];
        return view;
    }
    if (section == 0){
        UIView *view = [[UIView alloc] init];
        view.backgroundColor = [UIColor whiteColor];
        UILabel *label = [[UILabel alloc] initWithFrame:(CGRectMake(0, 0, self.backView.bounds.size.width,40))];
        label.backgroundColor = [UIColor colorFromHexCode:@"#8C8C00"];
        label.text = @"   旅行,是给自己最好的礼物";
        label.font = [UIFont systemFontOfSize:20];
        label.textColor = [UIColor whiteColor];
        //label.layer.cornerRadius = 10;
        label.layer.masksToBounds = YES;
        [view addSubview:label];
        return view;
    }
    else{
        return nil;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        static NSString *reuseIdentifer = @"cell1";
        PicViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifer];
        if (!cell) {
            cell = [[PicViewCell alloc] initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:reuseIdentifer];
        }
        cell.picImageArray = self.topPicArray;
        
        [cell setMyBlock:^(TopPic *topPic) {
            PicViewController *picVC = [[PicViewController alloc] init];
            picVC.topPic = topPic;
             [self.navigationController pushViewController:picVC animated:YES];
        }];
        
        
        return cell;
    }else{
        static NSString *reuseIdentifer = @"cell";
        TripViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifer];
        if (!cell) {
            cell = [[TripViewCell alloc] initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:reuseIdentifer];
        }
        if ([_tripArray count] != 0) {
            
            cell.trip = _tripArray[indexPath.row];
        }
     cell.backgroundColor = [UIColor colorFromHexCode:@"#FAFAD2"];
        //cell.backgroundColor = [UIColor blackColor];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        [cell setMyBlock:^{
            UserViewController *userVC = [[UserViewController alloc] init];
            Trip *trip = _tripArray[indexPath.row];
            
            userVC.userID = trip.user.userID;
            [self.navigationController pushViewController:userVC animated:YES];
        }];
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 1) {
        TripDetailViewController *tripDeatilVC = [[TripDetailViewController alloc] init];
        tripDeatilVC.tripID = [_tripArray[indexPath.row] tripID];
      
        [self.navigationController pushViewController:tripDeatilVC animated:YES];
        
    }
}
- (void)handle{
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    [manager GET:@"http://api.breadtrip.com/v2/index/?lat=%25s31.12815600000002&lng=%25s121.28838999999999" parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:(NSJSONReadingMutableContainers) error:nil];
        NSDictionary *dic = [NSDictionary dictionaryWithDictionary:responseObject];
        NSDictionary *dataDic = [dic objectForKey:@"data"];
        NSArray *elementsArray = [dataDic objectForKey:@"elements"];
        NSArray *dataArray = [elementsArray[0] objectForKey:@"data"];
        for (NSDictionary *dic in dataArray[0]) {
            TopPic *topPic = [[TopPic alloc] init];
            [topPic setValuesForKeysWithDictionary:dic];
            [self.topPicArray addObject:topPic];
         
        }
        [self.hud hide:YES];
        [self.tableView reloadData];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
       [self.hud removeFromSuperview];
    }];
}


//游记
- (void)handle2With:(NSInteger)i{

    
    [[AFHTTPRequestOperationManager manager] GET:[NSString stringWithFormat:@"http://chanyouji.com/api/trips/featured.json?page=%ld",(long)i] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [self.tableView.header endRefreshing];
        [self.tableView.footer endRefreshing];
        for (NSDictionary *dic in responseObject) {
            
            Trip *trip = [[Trip alloc] init];
            [trip setValuesForKeysWithDictionary:dic];
            [self.tripArray addObject:trip];
        }
        [self.tableView reloadData];
        [self.hud hide:YES];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [self.hud removeFromSuperview];
    }];
    
  
    
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
