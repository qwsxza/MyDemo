//
//  UserViewController.h
//  MyProject
//
//  Created by gp on 15/11/9.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "ViewController.h"

@interface UserViewController : ViewController
@property (nonatomic, strong) NSString *userID;
@end
