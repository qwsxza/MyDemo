//
//  MovieDetailViewController.m
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "MovieDetailViewController.h"
#import "Movie.h"
#import "UIImageView+WebCache.h"

#import <MediaPlayer/MediaPlayer.h>
#import "DataBaseHandle.h"
@interface MovieDetailViewController ()<UIScrollViewDelegate>
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *lineLabel;
@property (nonatomic, strong) UILabel *typeLabel;
@property (nonatomic, strong) UILabel *desLabel;
@property (nonatomic, strong) UILabel *countLabel;
@property (nonatomic, strong) UILabel *sliderLabel;
@property (nonatomic, strong) UIButton *backButton;
@property (nonatomic, strong) UIImageView *playImageView;

@property (nonatomic, strong) UIButton *collectionbutton;
@end

@implementation MovieDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.topView.backgroundColor = [UIColor whiteColor];
    self.backButton = [UIButton buttonWithType:(UIButtonTypeCustom)];
    self.backButton.frame = CGRectMake(10, self.view.bounds.size.height / 20, self.view.bounds.size.width / 10, self.view.bounds.size.height / 18);
    [self.backButton setImage:[UIImage imageNamed:@"MovieBack"] forState:(UIControlStateNormal)];
    [self.backButton addTarget:self action:@selector(backAction:) forControlEvents:(UIControlEventTouchUpInside)];
    [self.topView addSubview:self.backButton];
    
    
    self.scrollView = [[UIScrollView alloc] initWithFrame:(CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height ))];
    self.scrollView.contentSize = CGSizeMake([_movieDetailArray count] * self.backView.bounds.size.width, 0);
    self.scrollView.contentOffset = CGPointMake(_page * self.backView.bounds.size.width, 0);
    self.scrollView.pagingEnabled = YES;
    self.scrollView.delegate = self;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    [self.backView addSubview:self.scrollView];
    
    self.playImageView = [[UIImageView alloc] initWithFrame:(CGRectMake(self.scrollView.bounds.size.width / 2 - 40, self.scrollView.bounds.size.height * 3 / 10 - 40, 80, 80))];
    self.playImageView.image = [UIImage imageNamed:@"MoviePlay"];
    [self.backView addSubview:self.playImageView];
    
    NSLog(@"%@",_movieDetailArray);
    for (int i = 0; i < [_movieDetailArray count]; i++) {
        UIImageView *topImageView = [[UIImageView alloc] initWithFrame:(CGRectMake(i * self.scrollView.bounds.size.width, 0, self.scrollView.bounds.size.width, self.scrollView.bounds.size.height * 3 / 5))];
        topImageView.userInteractionEnabled = YES;
        [topImageView sd_setImageWithURL:[NSURL URLWithString:[_movieDetailArray[i] coverForFeed]] placeholderImage:nil];
        
        UIImageView *backImageView = [[UIImageView alloc] initWithFrame:(CGRectMake(i * self.scrollView.bounds.size.width, CGRectGetMaxY(topImageView.frame), self.scrollView.bounds.size.width, self.scrollView.bounds.size.height * 2 / 5))];
        [backImageView sd_setImageWithURL:[NSURL URLWithString:[_movieDetailArray[i] coverBlurred]] placeholderImage:nil];
        
//        [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(changeAction:) userInfo:topImageView repeats:YES];
        
        
        UIButton *button = [UIButton buttonWithType:(UIButtonTypeCustom)];
        button.frame = CGRectMake((self.scrollView.bounds.size.width - self.scrollView.bounds.size.width / 14 - 20) + i * self.scrollView.bounds.size.width, self.scrollView.bounds.size.height * 3 / 5 + 20, self.scrollView.bounds.size.width / 14, self.scrollView.bounds.size.width / 14);
        
        if ([DataBaseHandle isFavoriteNotesWithID:[_movieDetailArray[i] movieID]] == YES) {
            [button setImage:[UIImage imageNamed:@"collection"] forState:(UIControlStateNormal)];
        }else{
        [button setImage:[UIImage imageNamed:@"non-collection"] forState:(UIControlStateNormal)];
        }
        button.tag = 2500 + i;
        
        [button addTarget:self action:@selector(collectAction:) forControlEvents:(UIControlEventTouchUpInside)];
        
        

        
        
        
        
        
        //实现毛玻璃效果
//        UIVisualEffectView *effectivew = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleLight]];
//        effectivew.frame = CGRectMake(0, 0, 100, 100);
//        effectivew.alpha = 1;
//        [topImageView addSubview:effectivew];
        
        [self.scrollView addSubview:backImageView];
        [self.scrollView addSubview:topImageView];
        [self.scrollView addSubview:button];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
        [topImageView addGestureRecognizer:tap];
        
    }
   
    
    self.nameLabel = [[UILabel alloc] initWithFrame:(CGRectMake(10, self.scrollView.bounds.size.height *3/5 + 10, self.scrollView.bounds.size.width - 20, 40))];
    self.nameLabel.textColor = [UIColor whiteColor];
    self.nameLabel.font = [UIFont systemFontOfSize:20 weight:1];
    [self.backView addSubview:self.nameLabel];
    self.nameLabel.text = [_movieDetailArray[_page] title];
    
    self.lineLabel = [[UILabel alloc] initWithFrame:(CGRectMake(self.nameLabel.frame.origin.x, CGRectGetMaxY(_nameLabel.frame), _nameLabel.bounds.size.width, 15))];
    self.lineLabel.textColor = [UIColor whiteColor];
    self.lineLabel.text = @"______________________";
    [self.backView addSubview:self.lineLabel];
    
    self.typeLabel = [[UILabel alloc] initWithFrame:(CGRectMake(self.lineLabel.frame.origin.x, CGRectGetMaxY(_lineLabel.frame), self.lineLabel.bounds.size.width, 40))];
    self.typeLabel.textColor = [UIColor whiteColor];
    
    Movie *movie = [[Movie alloc] init];
    movie = _movieDetailArray[_page];
    NSInteger min = [movie.duration intValue] / 60;
    NSInteger sec = [movie.duration intValue] % 60;
    
    self.typeLabel.text = [NSString stringWithFormat:@"#%@  /  %0.2ld'%0.2ld''",[_movieDetailArray[_page] category], (long)min, (long)sec];
    [self.backView addSubview:self.typeLabel];
    
    self.desLabel = [[UILabel alloc] initWithFrame:(CGRectMake(self.typeLabel.frame.origin.x, CGRectGetMaxY(_typeLabel.frame), self.typeLabel.bounds.size.width, 60))];
    self.desLabel.numberOfLines = 0;
    self.desLabel.textColor = [UIColor whiteColor];
    self.desLabel.text = [_movieDetailArray[_page] movieDes];
    [self.desLabel sizeToFit];
    [self.backView addSubview:self.desLabel];
    
    self.countLabel = [[UILabel alloc] initWithFrame:(CGRectMake(_page * self.scrollView.bounds.size.width / [_movieDetailArray count], self.scrollView.bounds.size.height - 30, self.typeLabel.bounds.size.width / [_movieDetailArray count], 30))];
    self.countLabel.textColor = [UIColor whiteColor];
    self.countLabel.font = [UIFont systemFontOfSize:15];
    self.countLabel.text = [NSString stringWithFormat:@"%ld-%ld",_page + 1,(unsigned long)[_movieDetailArray count]];
    self.countLabel.textAlignment = NSTextAlignmentCenter;
    [self.backView addSubview:self.countLabel];
    
    self.sliderLabel = [[UILabel alloc] initWithFrame:(CGRectMake(_page * self.scrollView.bounds.size.width /[_movieDetailArray count], self.scrollView.bounds.size.height - 2, self.scrollView.bounds.size.width / [_movieDetailArray count], 2))];
    self.sliderLabel.backgroundColor = [UIColor whiteColor];
    [self.backView addSubview:self.sliderLabel];
    
    
    
}

- (void)collectAction:(UIButton *)button{
    
    NSInteger tag = button.tag;
    
    Movie *movie = _movieDetailArray[tag - 2500];
    
    if ([DataBaseHandle isFavoriteNotesWithID:movie.movieID] == YES) {
        [DataBaseHandle deleteMovie:movie];
        [button setImage:[UIImage imageNamed:@"non-collection"] forState:(UIControlStateNormal)];
        UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"提示" message:@"亲,视频已经取消收藏" preferredStyle:(UIAlertControllerStyleAlert)];
        UIAlertAction *act = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:nil];
        [alertC addAction:act];
        [self presentViewController:alertC animated:YES completion:nil];
    }else{
        [DataBaseHandle insertNewMovies:movie];
        [button setImage:[UIImage imageNamed:@"collection"] forState:(UIControlStateNormal)];
        UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"提示" message:@"亲,视频已经被收藏~" preferredStyle:(UIAlertControllerStyleAlert)];
        UIAlertAction *act = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:nil];
        [alertC addAction:act];
        [self presentViewController:alertC animated:YES completion:nil];
    }
    
    
}


- (void)tapAction:(UITapGestureRecognizer *)tap{
    CGFloat x = tap.view.frame.origin.x;
    NSInteger page = x / self.scrollView.bounds.size.width;
//    MoviePlayViewController *moviePlayVC = [[MoviePlayViewController alloc] init];
//    
//    moviePlayVC.movie = _movieDetailArray[page];
//    NSLog(@"%@",moviePlayVC.movie);
//    [self presentViewController:moviePlayVC animated:YES completion:nil];
    
    MPMoviePlayerViewController *moviePVC = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL URLWithString:[_movieDetailArray[page] playUrl]]];
    [self presentViewController:moviePVC animated:YES completion:nil];
    

}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGFloat X = scrollView.contentOffset.x;
    NSInteger page = X / scrollView.bounds.size.width;
    _nameLabel.text = [_movieDetailArray[page] title];

    
    Movie *movie = [[Movie alloc] init];
    movie = _movieDetailArray[page];
    NSInteger min = [movie.duration intValue] / 60;
    NSInteger sec = [movie.duration intValue] % 60;
    self.typeLabel.text = [NSString stringWithFormat:@"#%@  /  %0.2ld'%0.2ld''",[_movieDetailArray[page] category], (long)min, (long)sec];
    
    self.desLabel.text = movie.movieDes;
    
    self.countLabel.text = [NSString stringWithFormat:@"%d-%ld",page + 1,(unsigned long)[_movieDetailArray count]];
    [UIView animateWithDuration:0.2 animations:^{
        if ([_movieDetailArray count] != 0) {
            
            self.countLabel.frame = CGRectMake(page * self.scrollView.bounds.size.width / [_movieDetailArray count], self.scrollView.bounds.size.height - 30, self.typeLabel.bounds.size.width / [_movieDetailArray count], 30);
            self.sliderLabel.frame = (CGRectMake(page * self.scrollView.bounds.size.width /[_movieDetailArray count], self.scrollView.bounds.size.height - 2, self.scrollView.bounds.size.width / [_movieDetailArray count], 2));
        }
    } completion:nil];

}

- (void)backAction:(UIButton *)button{
    
    //刷新
    if ([self.isCollectionV isEqualToString:@"collect"]) {
        self.reload();
    }
    
    [self.navigationController popViewControllerAnimated:YES];
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
