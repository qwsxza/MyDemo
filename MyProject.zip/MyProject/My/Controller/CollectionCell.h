//
//  CollectionCell.h
//  MyProject
//
//  Created by gp on 15/11/14.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Movie;
@interface CollectionCell : UITableViewCell
@property (nonatomic ,strong) Movie *movie;
@end
