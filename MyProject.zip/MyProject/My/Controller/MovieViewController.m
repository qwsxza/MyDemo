//
//  MovieViewController.m
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "MovieViewController.h"
#import "AFNetworking.h"
#import "Movie.h"
#import "MovieViewCell.h"
#import "MovieDetailViewController.h"
#import "MJRefresh.h"
#import "MBProgressHUD.h"

@interface MovieViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableDictionary *movieDic;
@property (nonatomic, strong) NSMutableArray *keyArray;
@property (nonatomic, strong) MBProgressHUD *hud;
@end

@implementation MovieViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.topView.backgroundColor = [UIColor blackColor];
    self.titleLabel.text = @"精选 · 短视频 · Video";
    self.titleLabel.textColor = [UIColor whiteColor];
    self.titleLabel.font = [UIFont fontWithName:@"SnellRoundhand-Black" size:20];
    
    self.tableView = [[UITableView alloc] initWithFrame:(CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height)) style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.rowHeight = 250;
    [self.backView addSubview:self.tableView];
    self.keyArray = [NSMutableArray array];
    self.movieDic = [NSMutableDictionary dictionary];

    
    [self p_setupProgressHud];
   
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyymmdd"];
    formatter.timeZone = [NSTimeZone systemTimeZone];
    NSString *date = [formatter stringFromDate:[NSDate date]];
    NSInteger date1 = [date intValue];
//    NSLog(@"%ld",date1);
    [self handleByDate:date1];
    
    
    
    static NSInteger Day = 20151025;
    self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        Day -= 10;
        [self handleByDate:Day];
    }];
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self handleByDate:20151025];
    }];
    
}

- (void)p_setupProgressHud
{
    self.hud = [[MBProgressHUD alloc]initWithView:self.view];
    self.hud.frame = self.view.bounds;
    self.hud.minSize = CGSizeMake(100, 100);
    self.hud.mode = MBProgressHUDModeIndeterminate;
    [self.view addSubview:self.hud];
    
    [self.hud show:YES];
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 40;
}
- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view = [[UIView alloc] initWithFrame:(CGRectMake(0, 0, self.backView.bounds.size.width, 40))];
    view.backgroundColor = [UIColor whiteColor];
    UILabel *label = [[UILabel alloc] initWithFrame:(CGRectMake(0, 0, view.bounds.size.width, view.bounds.size.height))];

    
   
    //将字体转化为个性样式
    label.font = [UIFont fontWithName:@"SnellRoundhand-Black" size:20];
    
    label.textAlignment = NSTextAlignmentCenter;
    //将时间戳转化为时间
    //根据时间戳求出时间
    NSInteger begin = [[self.keyArray objectAtIndex:0] integerValue];
//    NSLog(@"%@******",self.keyArray);
//    NSLog(@"%d ------- %ld",86400 * section,(long)begin);
    NSDate *dateNow = [NSDate dateWithTimeIntervalSince1970:(begin - section * 86400000) / 1000];
    
    //设置date样式
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    //formatter样式 MM是阿拉伯数字 MMM英文简写 MMMM是英文全拼
    formatter.dateFormat = @"-MMM.dd-";
    //输出格式为英文
    formatter.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en-us"];
    //所在时区，使用系统所在的时区
    formatter.timeZone = [NSTimeZone systemTimeZone];
    
    NSString *dateStr = [formatter stringFromDate:dateNow];
    
    NSLog(@"%@",dateStr);
    label.text = dateStr;
    [view addSubview:label];
    
    return view;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
   

    MovieDetailViewController *movieDetailVC = [[MovieDetailViewController alloc] init];
    movieDetailVC.movieDetailArray = _movieDic[_keyArray[indexPath.section]];
    movieDetailVC.page = indexPath.row;
    

    [self.navigationController pushViewController:movieDetailVC animated:YES];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
   
    return [_movieDic[_keyArray[section]] count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return [_keyArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuseIdentifer = @"cell";
    MovieViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifer];
    if (!cell) {
        cell = [[MovieViewCell alloc] initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:reuseIdentifer];
    }
    cell.movie = _movieDic[_keyArray[indexPath.section]][indexPath.row];
    
    
    return cell;
}

- (void)handleByDate:(NSInteger)date{
    
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] init];
    [manager GET:[NSString stringWithFormat:@"http://baobab.wandoujia.com/api/v1/feed?num=10&date=%ld&vc=125&u=3596fd2556b48134e5568f0728dacb1d9a7cd87d&v=1.8.1&f=iphone",(long)date] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [self.tableView.footer endRefreshing];
        [self.tableView.header endRefreshing];
        NSArray *dailyListArray = [responseObject objectForKey:@"dailyList"];
        for (NSDictionary *dic in dailyListArray) {
            NSArray *videoListArray = [dic objectForKey:@"videoList"];
            NSString *date = [dic objectForKey:@"date"];
            NSMutableArray *movieArray = [NSMutableArray array];
            [self.keyArray addObject:date];
            for (NSDictionary *dic in videoListArray) {
                Movie *movie = [[Movie alloc] init];
                [movie setValuesForKeysWithDictionary:dic];
                [movieArray addObject:movie];
            }
            [self.movieDic setValue:movieArray forKey:date];
        }

        [self.tableView reloadData];
        [self.hud hide:YES];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [self.hud removeFromSuperview];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
