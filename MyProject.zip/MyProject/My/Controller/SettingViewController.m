//
//  SettingViewController.m
//  MyProject
//
//  Created by gp on 15/11/13.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "SettingViewController.h"
#import "collectionViewController.h"
#import "MyCollectViewController.h"
#import "FavoriteDataHandle.h"
#import "FavouriteDataHandle.h"

@interface SettingViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView;
@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tableView = [[UITableView alloc] initWithFrame:(CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height)) style:(UITableViewStylePlain)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.backView addSubview:self.tableView];
    
    self.tableView.tableFooterView = [[UIView alloc] init];
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 3;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *reuseIdentifer = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifer];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleValue1) reuseIdentifier:reuseIdentifer];
    }
    switch (indexPath.row) {
        case 0:
            cell.textLabel.text = @"清除缓存";
            cell.detailTextLabel.text = [NSString stringWithFormat:@"缓存%0.2fM", [self cacheSize]];
            break;
         case 1:
            cell.textLabel.text = @"我的视频";
            cell.detailTextLabel.text = [NSString stringWithFormat:@"视频%ld个",[[FavoriteDataHandle shareInstance] countOfMovie]];
            break;
        case 2:
            cell.textLabel.text = @"我的礼物";
            cell.detailTextLabel.text = [NSString stringWithFormat:@"礼物%ld个",[[FavouriteDataHandle shareInstance] countOfGifts]];
            break;
        default:
            break;
    }
    return cell;
}
-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.tableView reloadData];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 0) {
        
        UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"提示" message:@"是否清除缓存" preferredStyle:(UIAlertControllerStyleAlert)];
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            [self clearCache];
        }];
        UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"取消" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
        }];
        
        [alertC addAction:action];
        [alertC addAction:action1];
        [self presentViewController:alertC animated:YES completion:nil];
        
        
    }
    if (indexPath.row == 1) {
        collectionViewController *collectionVC = [[collectionViewController alloc] init];
        [self.navigationController pushViewController:collectionVC animated:YES];
    }
    if (indexPath.row == 2) {
        MyCollectViewController *myCollectVC = [[MyCollectViewController alloc]init];
        [self.navigationController pushViewController:myCollectVC animated:YES];
        
    }
}



//清除缓存
- (void)clearCache{
    NSLog(@"%@",NSHomeDirectory());
    
    //文件路径
    NSArray *cachesArr = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    //文件管理类
    NSFileManager *cachesManager = [NSFileManager defaultManager];
    
    //文件夹路径
    NSString *filePath = [cachesArr[0] stringByAppendingPathComponent:@"com.hackemist.SDWebImageCache.default"];
//    long long size = 0;
    
    if ([cachesManager fileExistsAtPath:filePath]) {
        //获取文件夹下所有文件
        NSArray *files = [cachesManager subpathsAtPath:filePath];
        for (NSString *str in files) {
            //文件夹名的完整路径
            NSString *file = [filePath stringByAppendingPathComponent:str];
            //计算文件字节大小
            //size += [cachesManager attributesOfItemAtPath:file error:nil].fileSize;
            //删除文件
            [cachesManager removeItemAtPath:file error:nil];
            
        }
    }
    [self.tableView reloadData];
    //[self countSize:size / (1024 * 1024.0)];
}
- (CGFloat)cacheSize {
    //文件路径
    NSArray *cachesArr = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    //文件管理类
    NSFileManager *cachesManager = [NSFileManager defaultManager];
    
    //文件夹路径
    NSString *filePath = [cachesArr[0] stringByAppendingPathComponent:@"com.hackemist.SDWebImageCache.default"];
    long long size = 0;
    
    if ([cachesManager fileExistsAtPath:filePath]) {
        //获取文件夹下所有文件
        NSArray *files = [cachesManager subpathsAtPath:filePath];
        for (NSString *str in files) {
            //文件夹名的完整路径
            NSString *file = [filePath stringByAppendingPathComponent:str];
            //计算文件字节大小
            size += [cachesManager attributesOfItemAtPath:file error:nil].fileSize;
            //删除文件
            //[cachesManager removeItemAtPath:file error:nil];
            
        }
    }
    return size / (1024 * 1024.0);
}
//- (void)countSize:(float)size{
//    UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"提示" message:[NSString stringWithFormat:@"共有%0.2fM缓存,是否清除",size] preferredStyle:(UIAlertControllerStyleAlert)];
//    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
//    }];
//    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"取消" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
//    }];
//    
//    [alertC addAction:action];
//    [alertC addAction:action1];
//    [self presentViewController:alertC animated:YES completion:nil];
//    
//    UIAlertAction *action2 = [UIAlertAction actionWithTitle:@"否" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
//        [alertC addAction:action2];
//    }];
//}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
