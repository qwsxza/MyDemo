//
//  PicViewController.h
//  MyProject
//
//  Created by gp on 15/11/6.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "ViewController.h"
@class TopPic;
@interface PicViewController : ViewController
@property (nonatomic, strong) TopPic *topPic;
@end
