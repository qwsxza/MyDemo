//
//  PicViewController.m
//  MyProject
//
//  Created by gp on 15/11/6.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "PicViewController.h"
#import "TopPic.h"
@interface PicViewController ()
@property (nonatomic, strong)UIView *view1;

@end

@implementation PicViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.topView.backgroundColor = [UIColor blackColor];
    self.view1 = [[UIView alloc]initWithFrame:CGRectMake(0, self.view1.frame.size.height / 18 * 17, self.view.frame.size.width, self.view1.frame.size.height / 18)];
    
    // Do any additional setup after loading the view.
    UIWebView *webView = [[UIWebView alloc] initWithFrame:(CGRectMake(0, 0, self.backView.bounds.size.width , self.backView.bounds.size.height))];
    NSURL *url = [NSURL URLWithString:_topPic.html_url];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [webView loadRequest:request];
    [self.backView addSubview:webView];
    self.view1.backgroundColor = [UIColor blackColor];
    [self.backView addSubview:self.view1];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
