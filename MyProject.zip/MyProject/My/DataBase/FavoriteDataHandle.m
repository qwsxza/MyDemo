//
//  FavoriteDataHandle.m
//  MyProject
//
//  Created by gp on 15/11/13.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "FavoriteDataHandle.h"
#import "Notes.h"
#import "DataBaseHandle.h"
#import "Movie.h"

@interface FavoriteDataHandle ()
@property (nonatomic, strong) NSMutableArray *movieArray;
@end

@implementation FavoriteDataHandle

static FavoriteDataHandle *handle = nil;
+ (FavoriteDataHandle *)shareInstance{
    if (handle == nil) {
        handle = [[FavoriteDataHandle alloc] init];
    }
    return handle;
}

//读取数据
- (void)setupMovieDataSource{
    _movieArray = [[DataBaseHandle selectAllMovie] mutableCopy];
}

- (NSInteger)countOfMovie{
    [self setupMovieDataSource];
    return [_movieArray count];
}

//获取某个游记
- (Movie *)movieForRow:(NSInteger)row;{
    return _movieArray[row];
}

//删除某个游记
- (void)deleteMovieForRow:(NSInteger)row{
    [DataBaseHandle deleteMovie:self.movieArray[row]];
    [_movieArray removeObjectAtIndex:row];
}
@end
