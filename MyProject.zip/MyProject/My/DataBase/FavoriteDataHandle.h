//
//  FavoriteDataHandle.h
//  MyProject
//
//  Created by gp on 15/11/13.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Notes;
@class Movie;
@interface FavoriteDataHandle : NSObject

+ (FavoriteDataHandle *)shareInstance;

//读取数据
- (void)setupMovieDataSource;

//获取游记个数
- (NSInteger)countOfMovie;

//获取某个游记
- (Movie *)movieForRow:(NSInteger)row;

//删除某个游记
- (void)deleteMovieForRow:(NSInteger)row;

@end
