//
//  DataBaseHandle.h
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
@class Notes;
@class Movie;
@class DesModel;
@interface DataBaseHandle : NSObject

@property (nonatomic, assign) BOOL isFavourite;

#pragma mark - 打开数据库
+ (sqlite3 *)openDB;

#pragma mark - 反归档
+ (id)unarchiVierObjectWithData:(NSData *)data forKey:(NSString *)key;

#pragma mark - 关闭数据库
+ (void)closeDB;


#pragma mark - 添加新的礼物页面
+ (BOOL)insertNewGift:(DesModel *)gift;
#pragma mark - 删除某个礼物页面
+ (BOOL)deleteGift:(DesModel *)gift;
#pragma mark - 获取所有的礼物
+ (NSArray *)selectAllGifts;
#pragma mark - 获取到某个礼物页面
+ (DesModel *)selectGiftID:(NSString *)ID;
#pragma mark - 判断是否收藏
+ (BOOL)isFavouriteGiftWith:(NSString *)ID;



//============================================================


//打开数据库
//+ (sqlite3 *)openDB;
////关闭数据库
//- (void)closeDB;

//犯归档
//+ (id)unarchiVierObjectWithData:(NSData *)data forKey:(NSString *)key;

#pragma mark ------ 游记
//添加新的电影
+ (BOOL)insertNewMovies:(Movie *)movie;

//删除某个游记
+ (BOOL)deleteMovie:(Movie *)movie;

//获取所有游记
+ (NSArray *)selectAllMovie;

//查询某个游记
+ (Movie *)selectMovieWithID:(NSString *)ID;

//判断游记是否被收藏
+ (BOOL)isFavoriteNotesWithID:(NSString *)ID;

@end
