//
//  DataBaseHandle.m
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "DataBaseHandle.h"
#import <sqlite3.h>
#import "Notes.h"
#import "Movie.h"
#import "DesModel.h"

#define KDataNameMovie @"Movie.sqlite"
@implementation DataBaseHandle

static sqlite3 *db = nil;

//打开数据库
+ (sqlite3 *)openDB{
    if (db != nil) {
        return db;
    }else{
        //数据库存储在沙盒中的caches文件夹下
        NSString *path = [[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject] stringByAppendingPathComponent:KDataNameMovie];
        //打开数据库,第一个参数是数据库存储的完整路径
        //如果数据库已经存在,直接打开,不存在则创建
        int result = sqlite3_open([path UTF8String], &db);
        if (result == SQLITE_OK) {
            
            //创建SQL语句
            NSString *creatSQL = @"CREATE TABLE 'Movie'(ID TEXT PRIMARY KEY NOT NULL, title TEXT, data BLOB);CREATE TABLE 'Gift' (ID TEXT KEY NOT NULL, name TEXT, data BLOB)";
            //执行sql语句qns
            sqlite3_exec(db, [creatSQL UTF8String], nil, nil, nil);
        }
        return db;
    }
}
// 关闭数据库
- (void)closeDB{
    int result = sqlite3_close(db);
    if (result == SQLITE_OK) {
        db = nil;
    }
}

////反归档
//+ (id)unarchiVierObjectWithData:(NSData *)data forKey:(NSString *)key{
//    NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
//    id object = [unarchiver decodeObjectForKey:key];
//    [unarchiver finishDecoding];
//    return object;
//}


//添加新的游记
+ (BOOL)insertNewMovies:(Movie *)movie{
    BOOL isSuccess = NO;
    sqlite3 *db = [self openDB];
    NSString *sql = [NSString stringWithFormat:@"INSERT INTO 'Movie' values('%@', '%@' ,?)",movie.movieID,movie.title];
    //stmt
    sqlite3_stmt *stmt = nil;
    //prepare
    int result = sqlite3_prepare_v2(db, sql.UTF8String, -1, &stmt, nil);
    //如果插入不进去数据,打断点产看result的值,为0的时候SQL语句正确
    if (result == SQLITE_OK){
        //归档标识
        NSString *movieKey = [NSString stringWithFormat:@"MovieKey"];
        //对对象进行归档,转化为data
        NSMutableData *data = [NSMutableData data];
        NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
        [archiver encodeObject:movie forKey:movieKey];
        [archiver finishEncoding];
        sqlite3_bind_blob(stmt, 1, [data bytes], (int)[data length], nil);
        sqlite3_step(stmt);
        isSuccess = YES;
    }
    sqlite3_finalize(stmt);
    return isSuccess;
}

//删除某个游记
+ (BOOL)deleteMovie:(Movie *)movie{
    BOOL isSucess = NO;
    sqlite3 *db = [self openDB];
    NSString *sql = [NSString stringWithFormat:@"DELETE FROM 'Movie' WHERE ID =%@",movie.movieID];
    int result = sqlite3_exec(db, sql.UTF8String, nil, nil, nil);
    if (result == SQLITE_OK) {
        isSucess = YES;
    }
    return isSucess;
}

//获取所有游记

+ (NSArray *)selectAllMovie{
    NSMutableArray *movieArr = [NSMutableArray array];
    sqlite3 *db = [self openDB];
    sqlite3_stmt *stmt = nil;
    NSString *sql = [NSString stringWithFormat:@"SELECT ID, DATA FROM 'Movie'"];
    int result = sqlite3_prepare_v2(db, sql.UTF8String, -1, &stmt, nil);
    if (result == SQLITE_OK) {
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            NSData *data = [NSData dataWithBytes:(const void *) sqlite3_column_blob(stmt, 1) length:sqlite3_column_bytes(stmt, 1)];
            //获取标识符
            NSString *archiverkey = [NSString stringWithFormat:@"MovieKey"];
            //得到反归档后的数据
           Movie *movie = [self unarchiVierObjectWithData:data forKey:archiverkey];
            [movieArr addObject:movie];
        }
    }
    sqlite3_finalize(stmt);
    return movieArr;
}

// 获取某个游记
+ (Movie *)selectMovieWithID:(NSString *)ID{
    Movie *movie = nil;
    sqlite3 *db = [self openDB];
    sqlite3_stmt *stmt = nil;
    NSString *sql = [NSString stringWithFormat:@"SELECT DATA FROM 'Movie' WHERE ID = '%@'",ID];
    int result = sqlite3_prepare_v2(db, sql.UTF8String, -1, &stmt, nil);
    if (result == SQLITE_OK) {
        int result2 = sqlite3_step(stmt);
        if (result2 == SQLITE_ROW){
            NSData *data = [NSData dataWithBytes:sqlite3_column_blob(stmt, 0) length:sqlite3_column_bytes(stmt, 0)];
            
            //反归档
            NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
            NSString *key = [NSString stringWithFormat:@"MovieKey"];
            movie = [unarchiver decodeObjectForKey:key];
            [unarchiver finishDecoding];
        }
    }
    sqlite3_finalize(stmt);
    if (movie != nil) {
        return movie;
    }else{
        return nil;
    }
}

//判断是否被收藏
+ (BOOL)isFavoriteNotesWithID:(NSString *)ID;{
    Movie *movie = [self selectMovieWithID:ID];
    if (movie != nil) {
        return YES;
    }else{
        return NO;
    }
}
//=================================
#pragma mark - 关闭数据库
+ (void)closeDB
{
    int result = sqlite3_close(db);
    if (result == SQLITE_OK) {
        NSLog(@"close");
        db = nil;
    }
}

#pragma mark - 反归档
+ (id)unarchiVierObjectWithData:(NSData *)data forKey:(NSString *)key
{
    NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc]initForReadingWithData:data];
    id object = [unarchiver decodeObjectForKey:key];
    [unarchiver finishDecoding];
    return object;
}



#pragma mark - 添加新的礼物页面
+ (BOOL)insertNewGift:(DesModel *)gift
{
    BOOL isSuccess = NO;
    // 打开数据库
    db = [self openDB];
    // 插入语句
    NSString *sql = [NSString stringWithFormat:@"INSERT INTO 'Gift' values('%ld', '%@', ?)", (long)gift.ID,gift.name];
    
    // stmt
    sqlite3_stmt *stmt = nil;
    // prepare
    int result = sqlite3_prepare_v2(db, sql.UTF8String, -1, &stmt, nil);
    // 如果插入不进去数据,打断点查看result值,为0的时候sql语句正确.
    if (result == SQLITE_OK) {
        // 归档标识
        NSString *giftKey = [NSString stringWithFormat:@"girtKey"];
        // 对对象进行归档,转化为data
        NSMutableData *data = [NSMutableData data];
        NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc]initForWritingWithMutableData:data];
        [archiver encodeObject:gift forKey:giftKey];
        [archiver finishEncoding];
        // 预编译
        sqlite3_bind_blob(stmt, 1, [data bytes], (int)[data length], nil);
        // 编译
        sqlite3_step(stmt);
        isSuccess = YES;
    }
    sqlite3_finalize(stmt);
    return isSuccess;
}

#pragma mark - 删除某个礼物页面
+ (BOOL)deleteGift:(DesModel *)gift
{
    BOOL isSuccess = NO;
    sqlite3 *db = [self openDB]; //打开数据库
    NSString *sql = [NSString stringWithFormat:@"DELETE FROM 'Gift'WHERE ID = %ld",(long)gift.ID]; // sql语句
    int result = sqlite3_exec(db, sql.UTF8String, nil, nil, nil);
    if (result == SQLITE_OK) {
        isSuccess = YES;
    }
    return isSuccess;
}

#pragma mark - 获取所有的礼物
+ (NSArray *)selectAllGifts
{
    NSMutableArray *giftArr = [NSMutableArray array];
    sqlite3 *db = [self openDB];
    sqlite3_stmt *stmt = nil;
    NSString *sql = [NSString stringWithFormat:@"SELECT ID,DATA FROM 'Gift'"]; // sql 语句
    int result = sqlite3_prepare_v2(db, sql.UTF8String, -1, &stmt, nil);
    if (result == SQLITE_OK) {
        while (sqlite3_step(stmt) == SQLITE_ROW) {
            NSData *data = [NSData dataWithBytes:(const void*)sqlite3_column_blob(stmt, 1) length:sqlite3_column_bytes(stmt, 1)];
            // 获取标识符
            NSString *archiverKey = [NSString stringWithFormat:@"girtKey"];
            // 得到反归档后的数据
            DesModel *desModel = (DesModel *)[self unarchiVierObjectWithData:data forKey:archiverKey];
            [giftArr addObject:desModel];
        }
    }
    sqlite3_finalize(stmt);
    return giftArr;
}

#pragma mark - 获取到某个礼物页面
+ (DesModel *)selectGiftID:(NSString *)ID
{
    DesModel *desModel = nil;
    sqlite3 *db = [self openDB];
    sqlite3_stmt *stmt = nil;
    //SELECT SNAME, AGE           FROM   STUDENTS            WHERE   BPLACE
    NSString *sql = [NSString stringWithFormat:@"SELECT DATA FROM 'Gift' WHERE ID = '%@'",ID];
    int result = sqlite3_prepare_v2(db, sql.UTF8String, -1, &stmt, nil); // 预编译
    if (result == SQLITE_OK) {
        int result1 = sqlite3_step(stmt);
        if (result1 == SQLITE_ROW) {
            NSData *data = [NSData dataWithBytes:sqlite3_column_blob(stmt, 0) length:sqlite3_column_bytes(stmt, 0)];
            // 反归档
            NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc]initForReadingWithData:data];
            NSString *key = [NSString stringWithFormat:@"girtKey"]; // 归档标识符
            desModel = [unarchiver decodeObjectForKey:key]; // 取出模型
            [unarchiver finishDecoding];
        }
    }
    sqlite3_finalize(stmt);
    if (desModel != nil) {
        return desModel;
    }else{
        return nil;
    }
}

#pragma mark -判断是否收藏
+ (BOOL)isFavouriteGiftWith:(NSString *)ID
{
    DesModel *model = [self selectGiftID:ID];
    if (model != nil) {
        return YES;
    }else{
        return NO;
        
    }
}

@end
