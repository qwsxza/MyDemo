//
//  UserDetail.m
//  MyProject
//
//  Created by 陆超 on 15/11/9.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "UserDetail.h"
#import "Trips.h"

@implementation UserDetail

- (void)setValue:(id)value forKey:(NSString *)key{
    [super setValue:value forKey:key];
    NSMutableArray *arr = [NSMutableArray array];
    if ([key isEqualToString:@"trips"]) {
        for (NSDictionary *dic in value) {
            Trips *trips = [[Trips alloc] initWithDictionary:dic];
            [arr addObject:trips];
        }
        self.trips = [NSMutableArray arrayWithArray:arr];
    }
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    if ([key isEqualToString:@"id"]) {
        self.userID = value;
    }
}

@end
