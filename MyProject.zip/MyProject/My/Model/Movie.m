//
//  Movie.m
//  MyProject
//
//  Created by 陆超 on 15/11/12.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "Movie.h"

@implementation Movie

- (void)setValue:(id)value forKey:(NSString *)key{
    [super setValue:value forKey:key];
    if ([key isEqualToString:@"playInfo"]) {
        self.playInfo = [NSArray arrayWithArray:value];
    }
    if ([key isEqualToString:@"consumption"]) {
        self.consumption = [NSDictionary dictionaryWithDictionary:value];
    }
    if ([key isEqualToString:@"provider"]) {
        self.provider = [NSDictionary dictionaryWithDictionary:value];
    }
    
  
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    if ([key isEqualToString:@"id"]) {
        self.movieID = value;
    }
    
    if ([key isEqualToString:@"description"]) {
        self.movieDes = value;
    }
}

- (void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:self.movieID forKey:@"movieID"];
    [aCoder encodeObject:self.date forKey:@"date"];
    [aCoder encodeObject:self.idx forKey:@"idx"];
    [aCoder encodeObject:self.title forKey:@"title"];
    [aCoder encodeObject:self.movieDes forKey:@"movieDes"];
    [aCoder encodeObject:self.category forKey:@"category"];
    [aCoder encodeObject:self.duration forKey:@"duration"];
    [aCoder encodeObject:self.playUrl forKey:@"playUrl"];
    [aCoder encodeObject:self.playInfo forKey:@"playInfo"];
    [aCoder encodeObject:self.consumption forKey:@"consumption"];
    [aCoder encodeObject:self.provider forKey:@"provider"];
    [aCoder encodeObject:self.author forKey:@"author"];
    [aCoder encodeObject:self.coverForFeed forKey:@"coverForFeed"];
    [aCoder encodeObject:self.coverForDeatil forKey:@"coverForDetail"];
    [aCoder encodeObject:self.coverBlurred forKey:@"coverBlurred"];
    [aCoder encodeObject:self.coverForSharing forKey:@"coverForSharing"];
    [aCoder encodeObject:self.webUrl forKey:@"webUrl"];
    [aCoder encodeObject:self.rawWebUrl forKey:@"rawWebUrl"];
}

- (id)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    if (self) {
        self.movieID = [aDecoder decodeObjectForKey:@"movieID"];
        self.date = [aDecoder decodeObjectForKey:@"date"];
        self.idx = [aDecoder decodeObjectForKey:@"idx"];
        self.title = [aDecoder decodeObjectForKey:@"title"];
        self.movieDes = [aDecoder decodeObjectForKey:@"movieDes"];
        self.category = [aDecoder decodeObjectForKey:@"category"];
        self.duration = [aDecoder decodeObjectForKey:@"duration"];
        self.playUrl = [aDecoder decodeObjectForKey:@"playUrl"];
        self.playInfo = [aDecoder decodeObjectForKey:@"playInfo"];
        self.consumption = [aDecoder decodeObjectForKey:@"consumption"];
        self.provider = [aDecoder decodeObjectForKey:@"provider"];
        self.author = [aDecoder decodeObjectForKey:@"author"];
        self.coverForFeed = [aDecoder decodeObjectForKey:@"coverForFeed"];
        self.coverForDeatil = [aDecoder decodeObjectForKey:@"coverForDetail"];
        self.coverBlurred = [aDecoder decodeObjectForKey:@"coverBlurred"];
        self.coverForSharing = [aDecoder decodeObjectForKey:@"coverForSharing"];
        self.webUrl = [aDecoder decodeObjectForKey:@"webUrl"];
        self.rawWebUrl = [aDecoder decodeObjectForKey:@"rawWebUrl"];
    }
    return self;
}


@end
