//
//  TripDetail.h
//  MyProject
//
//  Created by 陆超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <Foundation/Foundation.h>
@class User;
@interface TripDetail : NSObject
//"id": 305459,
//"name": "行走、建筑与美食",
//"photos_count": 133,
//"start_date": "2015-05-27",
//"end_date": "2015-06-17",
//"level": 4,
//"privacy": false,
//"front_cover_photo_id": 10452025,
//"views_count": 16341,
//"comments_count": 65,
//"likes_count": 468,
//"favorites_count": 252,
//"state": "publish",
//"source": "web",
//"serial_id": null,
//"serial_position": null,
//"serial_next_id": 0,
//"updated_at": 1446803077,
//"trip_days": [],
//"user": {},
//"upload_token": null,
//"current_user_favorite": false,
//"password": null,
//"front_cover_photo_url": "http://p.chanyouji.cn/305459/1438714619526p19rt13aneal9bqr1jqh17rh17iht.jpg",
//"notes_likes_comments": []
@property (nonatomic, strong)NSString *tripID;
@property (nonatomic, strong)NSString *name;
@property (nonatomic, strong)NSString *photos_count;
@property (nonatomic, strong)NSString *start_date;
@property (nonatomic, strong)NSString *end_date;
@property (nonatomic, strong)NSString *level;
@property (nonatomic, strong)NSString *privacy;
@property (nonatomic, strong)NSString *front_cover_photo_id;
@property (nonatomic, strong)NSString *views_count;
@property (nonatomic, strong)NSString *comments_count;
@property (nonatomic, strong)NSString *likes_count;
@property (nonatomic, strong)NSString *favorites_count;
@property (nonatomic, strong)NSString *state;
@property (nonatomic, strong)NSString *source;
@property (nonatomic, strong)NSString *serial_id;
@property (nonatomic, strong)NSString *serial_position;
@property (nonatomic, strong)NSString *serial_next_id;
@property (nonatomic, strong)NSString *updated_at;
@property (nonatomic, strong)NSArray *trip_days;
@property (nonatomic, strong)User *user;
@property (nonatomic, strong)NSString *upload_token;
@property (nonatomic, strong)NSString *current_user_favorite;
@property (nonatomic, strong)NSString *password;
@property (nonatomic, strong)NSString *front_cover_photo_url;
@property (nonatomic, strong)NSArray *notes_likes_comments;
@end
