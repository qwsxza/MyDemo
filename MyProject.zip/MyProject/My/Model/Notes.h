//
//  Notes.h
//  MyProject
//
//  Created by 陆超 on 15/11/7.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Notes : NSObject
@property (nonatomic, strong) NSString *des;
@property (nonatomic, strong) NSString *url;
@property (nonatomic, strong) NSString *name;
@end
