//
//  TripDetail.m
//  MyProject
//
//  Created by 陆超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "TripDetail.h"
#import "User.h"
@implementation TripDetail

- (void)setValue:(id)value forKey:(NSString *)key{
    [super setValue:value forKey:key];
    if ([key isEqualToString:@"user"]) {
        self.user = [[User alloc] initWithDictionary:value];
    }
    if ([key isEqualToString:@"trip_days"]) {
        self.trip_days = [NSArray arrayWithArray:value];
    }
    
    if ([key isEqualToString:@"notes_likes_comments"]) {
        self.notes_likes_comments = [NSArray arrayWithArray:value];
    }
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    if ([key isEqualToString:@"id"]) {
        self.tripID = value;
    }
    
    
}

@end
