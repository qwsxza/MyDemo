//
//  Movie.h
//  MyProject
//
//  Created by 陆超 on 15/11/12.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Movie : NSObject<NSCoding>
//"id": 3144,
//"date": 1447257600000,
//"idx": 1,
//"title": "一道走丨马达加斯加之旅",
//"description": "「一道走 」（微信：yidaozou001) 远赴马达加斯加，用镜头记录这片土地。从日出到日落，从一张张笑脸到狐猴的每一个跳跃，每个镜头都在传达着旅行的真正意义：拥抱自然，贴近纯真。摄影：张江、黄建栋；剪辑：黄建栋",
//"category": "旅行",
//"duration": 190,
//"playUrl": "http://baobab.cdn.wandoujia.com/1447057918122m_x264.mp4",
//"playInfo": [
//             {}
//             ],

//"consumption": {},
//"provider": {},
//"author": null,
//"coverForFeed": "http://img.wdjimg.com/image/video/1e4cf584b2df92cd7982884c61766a3a_0_0.jpeg",
//"coverForDetail": "http://img.wdjimg.com/image/video/1e4cf584b2df92cd7982884c61766a3a_0_0.jpeg",
//"coverBlurred": "http://img.wdjimg.com/image/video/b875fd161939571d296fa89b6c3a774c_0_0.jpeg",
//"coverForSharing": "http://img.wdjimg.com/image/video/1e4cf584b2df92cd7982884c61766a3a_0_0.jpeg",
//"webUrl": "http://wandou.im/umx80",
//"rawWebUrl": "http://www.wandoujia.com/eyepetizer/detail.html?vid=3144"

@property (nonatomic, strong) NSString *movieID;
@property (nonatomic, strong) NSString *date;
@property (nonatomic, strong) NSString *idx;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *movieDes;
@property (nonatomic, strong) NSString *category;
@property (nonatomic, strong) NSString *duration;
@property (nonatomic, strong) NSString *playUrl;
@property (nonatomic, strong) NSArray *playInfo;
@property (nonatomic, strong) NSDictionary *consumption;
@property (nonatomic, strong) NSDictionary *provider;
@property (nonatomic, strong) NSString *author;
@property (nonatomic, strong) NSString *coverForFeed;
@property (nonatomic, strong) NSString *coverForDeatil;
@property (nonatomic, strong) NSString *coverBlurred;
@property (nonatomic, strong) NSString *coverForSharing;
@property (nonatomic, strong) NSString *webUrl;
@property (nonatomic, strong) NSString *rawWebUrl;

@end
