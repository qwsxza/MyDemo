//
//  UserDetail.h
//  MyProject
//
//  Created by 陆超 on 15/11/9.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Trips.h"
@interface UserDetail : NSObject
//{
//    "id": 403951,
//    "name": "桨桅",
//    "gender": null,
//    "image": "http://tp1.sinaimg.cn/1863083524/180/5725531008/1",
//    "favorites_count": 4,
//    "likes_count": 158,
//    "attraction_favorites_count": 0,
//    "poi_favorites_count": 0,
//    "friends_count": 21,
//    "fans_count": 22,
//    "trips_count": 4,
//    "plans_count": 0,
//    "current_user_friend": false,
//    "trips":[]
//}
@property (nonatomic, strong) NSString *userID;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *gender;
@property (nonatomic, strong) NSString *image;
@property (nonatomic, strong) NSString *favorites_count;
@property (nonatomic, strong) NSString *likes_count;
@property (nonatomic, strong) NSString *attraction_favorites_count;
@property (nonatomic, strong) NSString *poi_favorites_count;
@property (nonatomic, strong) NSString *friends_count;
@property (nonatomic, strong) NSString *fans_count;
@property (nonatomic, strong) NSString *trips_count;
@property (nonatomic, strong) NSString *plans_count;
@property (nonatomic, strong) NSString *current_user_friend;
@property (nonatomic, strong) NSMutableArray *trips;
@end
