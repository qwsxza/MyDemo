//
//  TopPic.h
//  MyProject
//
//  Created by 陆超 on 15/11/5.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TopPic : NSObject
//"platform": "android",
//"image_url": "http://photos.breadtrip.com/covers_2015_11_04_493f5e32269aab10e28a719359dcb454.png",
//"html_url": "http://web.breadtrip.com/mobile/destination/topic/2387718679/"

@property (nonatomic, strong) NSString *platform;
@property (nonatomic, strong) NSString *image_url;
@property (nonatomic, strong) NSString *html_url;

@end
