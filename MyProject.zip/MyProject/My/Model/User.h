//
//  User.h
//  MyProject
//
//  Created by 陆超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSObject
//    "id": 313643,
//    "name": "huchichi",
//    "image": "http://tp2.sinaimg.cn/1549723705/180/40043528579/1"

@property (nonatomic, strong) NSString *userID;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *image;

- (instancetype)initWithDictionary:(NSDictionary *)dictionary;
@end
