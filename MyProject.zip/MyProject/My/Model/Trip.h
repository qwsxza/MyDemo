//
//  Trip.h
//  MyProject
//
//  Created by 陆超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <Foundation/Foundation.h>
@class User;
@interface Trip : NSObject
//"id": 297071,
//"name": "单车自驾：畅游张家界，凤凰古城",
//"photos_count": 128,
//"start_date": "2015-05-28",
//"end_date": "2015-06-01",
//"days": 5,
//"level": 4,
//"views_count": 11327,
//"comments_count": 26,
//"likes_count": 251,
//"source": "web",
//"front_cover_photo_url": "http://p.chanyouji.cn/297071/1435388436684p19opt2o5b16t7avpmgo1fdv1pgi2.jpg",
//"featured": true,
//"user": {
//    "id": 313643,
//    "name": "huchichi",
//    "image": "http://tp2.sinaimg.cn/1549723705/180/40043528579/1"
//}

@property (nonatomic, strong) NSString *tripID;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *photos_count;
@property (nonatomic, strong) NSString *start_date;
@property (nonatomic, strong) NSString *end_date;
@property (nonatomic, strong) NSString *days;
@property (nonatomic, strong) NSString *level;
@property (nonatomic, strong) NSString *views_count;
@property (nonatomic, strong) NSString *comments_count;
@property (nonatomic, strong) NSString *likes_count;
@property (nonatomic, strong) NSString *source;
@property (nonatomic, strong) NSString *front_cover_photo_url;
@property (nonatomic, strong) NSString *featured;
@property (nonatomic, strong) User *user;
@end
