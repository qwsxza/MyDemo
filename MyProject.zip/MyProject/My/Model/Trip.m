//
//  Trip.m
//  MyProject
//
//  Created by 陆超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "Trip.h"
#import "User.h"
@implementation Trip

- (void)setValue:(id)value forKey:(NSString *)key{
    [super setValue:value forKey:key];
    
    if ([key isEqualToString:@"photos_count"]) {
        self.photos_count = [NSString stringWithFormat:@"%@",value];
    }
    if ([key isEqualToString:@"user"]) {
        self.user = [[User alloc]initWithDictionary:value];
    }
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    if ([key isEqualToString:@"id"]) {
        self.tripID = [NSString stringWithFormat:@"%@",value];
    }
    
}
@end
