//
//  TripPicture.h
//  MyProject
//
//  Created by 陆超 on 15/11/9.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TripPicture : NSObject
//"id": 11706510,
//"description": "啊啊啊啊，又是好熟悉的场景",
//"width": 1600,
//"height": 1067,
//"photo_url": "http://p.chanyouji.cn/310917/1440519388660p19tipf6mm17ffp8lm3pdedh3c12.jpg",
//"trip_id": 310917

@property (nonatomic, strong) NSString *picID;
@property (nonatomic, strong) NSString *picDes;
@property (nonatomic, strong) NSString *width;
@property (nonatomic, strong) NSString *height;
@property (nonatomic, strong) NSString *photo_url;
@property (nonatomic, strong) NSString *trip_id;
@end
