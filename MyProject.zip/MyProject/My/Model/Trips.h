//
//  Trips.h
//  MyProject
//
//  Created by 陆超 on 15/11/9.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Trips : NSObject
//"id": 323867,
//"name": "用5天的时间讲一个只和台北有关的故事",
//"photos_count": 110,
//"start_date": "2015-10-15",
//"end_date": "2015-10-19",
//"days": 5,
//"level": 3,
//"privacy": false,
//"views_count": 2818,
//"comments_count": 22,
//"likes_count": 81,
//"source": "app",
//"password": null,
//"front_cover_photo_url": "http://p.chanyouji.cn/1445173796/FDE59832-F6EB-412D-B689-E388F5ED9F95.jpg"
@property (nonatomic, strong) NSString *tripsID;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *photos_count;
@property (nonatomic, strong) NSString *start_date;
@property (nonatomic, strong) NSString *end_date;
@property (nonatomic, strong) NSString *days;
@property (nonatomic, strong) NSString *level;
@property (nonatomic, strong) NSString *privacy;
@property (nonatomic, strong) NSString *views_count;
@property (nonatomic, strong) NSString *comments_count;
@property (nonatomic, strong) NSString *likes_count;
@property (nonatomic, strong) NSString *source;
@property (nonatomic, strong) NSString *password;
@property (nonatomic, strong) NSString *front_cover_photo_url;

- (instancetype)initWithDictionary:(NSDictionary *)dic;

@end
