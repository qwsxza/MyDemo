//
//  Notes.m
//  MyProject
//
//  Created by 陆超 on 15/11/7.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "Notes.h"

@implementation Notes

- (void)setValue:(id)value forKey:(NSString *)key{
    [super setValue:value forKey:key];
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    if ([key isEqualToString:@"description"]) {
        self.des = [NSString stringWithFormat:@"%@",value];
    }
}
-(void)setNilValueForKey:(NSString *)key {}
@end
