//
//  FavouriteDataHandle.m
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "FavouriteDataHandle.h"
#import "DesModel.h"
#import "DataBaseHandle.h"

@interface FavouriteDataHandle ()

@property (nonatomic, strong) NSMutableArray *giftArr; //礼物详情数组


@end

@implementation FavouriteDataHandle

static FavouriteDataHandle *handle = nil;

+ (FavouriteDataHandle *)shareInstance
{
    if (handle == nil) {
        handle = [[FavouriteDataHandle alloc]init];
    }
    return handle;
}

#pragma mark - 礼物数据源
// 读取数据
- (void)setupGiftDataSource
{
    _giftArr = [[DataBaseHandle selectAllGifts] mutableCopy];
}

// 读取礼物个数
- (NSInteger)countOfGifts
{
    [self setupGiftDataSource];
    return [_giftArr count];
}

// 获取某个礼物
- (DesModel *)giftForRow:(NSInteger)row
{
    return _giftArr[row];
}

// 删除某个礼物
- (void)deleteGiftForRow:(NSInteger)row
{
    [DataBaseHandle deleteGift:self.giftArr[row]];
    [_giftArr removeObjectAtIndex:row];
}

@end
