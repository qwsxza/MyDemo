//
//  FavouriteDataHandle.h
//  MyProject
//
//  Created by gp on 15/11/12.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <Foundation/Foundation.h>
@class DesModel;

@interface FavouriteDataHandle : NSObject

+ (FavouriteDataHandle *)shareInstance;

#pragma mark - 礼物详情数据源

// 读取数据
- (void)setupGiftDataSource;
// 读取礼物个数
- (NSInteger)countOfGifts;
// 获取某个礼物
- (DesModel *)giftForRow:(NSInteger)row;
// 删除某个礼物
- (void)deleteGiftForRow:(NSInteger)row;

@end
