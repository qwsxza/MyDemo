//
//  CommentsCell.m
//  MyProject
//
//  Created by 伍维超 on 15/11/7.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "CommentsCell.h"
#import "Header.h"
#import "UIImageView+WebCache.h"
#import "Comments.h"

@interface CommentsCell ()



@end

@implementation CommentsCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.imageV = [[UIImageView alloc]init];
        [self.contentView addSubview:self.imageV];
        
        self.nameLabel = [[UILabel alloc]init];
        [self.contentView addSubview:self.nameLabel];
        
        self.commentsLabel = [[UILabel alloc]init];
        [self.contentView addSubview:self.commentsLabel];
        
        self.timeLabel = [[UILabel alloc]init];
        [self.contentView addSubview:self.timeLabel];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    
    self.imageV.frame = CGRectMake(kContentWidth/20, kContentHeight/6, kContentWidth/9, kContentWidth/9);
    self.imageV.layer.cornerRadius = kContentWidth/18;
    self.imageV.layer.masksToBounds = YES;
    
    
    self.nameLabel.frame = CGRectMake(self.imageV.frame.origin.x + self.imageV.bounds.size.width + kContentWidth/20, 0, kContentWidth/2.3, kContentHeight/2);
    
    self.timeLabel.frame = CGRectMake(self.nameLabel.frame.origin.x  + self.nameLabel.bounds.size.width + kContentWidth/15, kContentHeight/10,kContentWidth/3, kContentHeight/4);
    self.timeLabel.alpha = 0.5;
    
    self.commentsLabel.frame = CGRectMake(self.nameLabel.frame.origin.x, kContentHeight/2, self.contentView.bounds.size.width - kContentWidth/9 - kContentWidth/20 - kContentWidth/20 - 30 ,1000);
    [self.commentsLabel sizeToFit];
    self.commentsLabel.numberOfLines = 0;
    
}


 - (void)setComment:(Comments *)comment
{
    _comment = comment;
    [self.imageV sd_setImageWithURL:[NSURL URLWithString:[_comment.user objectForKey:@"avatar_url"]] placeholderImage:[UIImage imageNamed:@"placeholder"]];
    self.nameLabel.text = [_comment.user objectForKey:@"nickname"];
    self.commentsLabel.text = _comment.content;
    self.nameLabel.textColor = [UIColor blackColor];
    
    //时间戳转时间
//    NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
//    [formatter setDateStyle:NSDateFormatterMediumStyle];
//    [formatter setTimeStyle:NSDateFormatterShortStyle];
//    [formatter setDateFormat:@"MM-dd H:mm"];
//    NSLog(@"11111%@", [comment.created_at class]);
//    NSDate *confromTimesp = [NSDate dateWithTimeIntervalSince1970:[comment.created_at longLongValue]];
//    NSString *dateString = [formatter stringFromDate:confromTimesp];
//    self.timeLabel.text = dateString;
    //[self.commentsLabel sizeToFit];
   // self.commentsLabel.numberOfLines = 0;
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
