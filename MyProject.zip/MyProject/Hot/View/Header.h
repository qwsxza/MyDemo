//
//  Header.h
//  MyProject
//
//  Created by 伍维超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//

#ifndef Header_h
#define Header_h

#define kScreenWidth self.view.bounds.size.width
#define kScreenHeight self.view.bounds.size.height

#define kContentWidth self.contentView.bounds.size.width
#define kContentHeight self.contentView.bounds.size.height

#define kModelCell @"modelCell"


#endif /* Header_h */
