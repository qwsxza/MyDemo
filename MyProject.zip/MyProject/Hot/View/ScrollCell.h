//
//  ScrollCell.h
//  MyProject
//
//  Created by 伍维超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScrollCell : UITableViewCell

@property (nonatomic, strong)NSArray *image_urls;
@property (nonatomic, strong)UIScrollView *scrollV;

@property (nonatomic, strong)UIPageControl *pageControl;


//- (void)setValueWithModel:(Model *)model;

@end
