//
//  HotWebCell.m
//  MyProject
//
//  Created by 伍维超 on 15/11/7.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "HotWebCell.h"
#import "CommentsCell.h"
#import "Comments.h"
#import "UIImageView+WebCache.h"
#import "Header.h"


@interface HotWebCell ()<UITableViewDataSource,UITableViewDelegate>


@end

@implementation HotWebCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.tableV = [[UITableView alloc]init];
        self.tableV.delegate = self;
        self.tableV.dataSource = self;
        self.tableV.rowHeight = [UIScreen mainScreen].bounds.size.height/8;
        self.tableV.scrollEnabled = NO;
        self.tableV.tag = 100;
        [self.contentView addSubview:self.tableV];
        self.tableV.hidden = YES;
        
        self.hotWebV = [[UIWebView alloc]init];
        [self addSubview:self.hotWebV];
     //   self.hotWebV.userInteractionEnabled = YES;

       // self.hotWebV.scalesPageToFit = YES;
//
        self.hotWebV.backgroundColor = [UIColor whiteColor];
        self.hotWebV.backgroundColor = [UIColor clearColor];
//        self.hotWebV.opaque = YES;
        self.hotWebV.tag = 101;



    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    self.tableV.frame = CGRectMake(0, 0, self.contentView.bounds.size.width, self.contentView.bounds.size.height);
    self.hotWebV.frame = CGRectMake(0, 0, self.contentView.bounds.size.width, self.contentView.bounds.size.height);
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.arr.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    Comments *comment = self.arr[indexPath.row];
    
    static NSString *inderifier = @"commentsCell";
    
    CommentsCell *cell = [tableView dequeueReusableCellWithIdentifier:inderifier];
    
    if (!cell) {
        cell = [[CommentsCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:inderifier];

    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.comment = comment;
    
 
    return cell;
}


- (void)setStr:(NSString *)str
{
    _str = str;
    NSString *str1 = [NSString stringWithFormat:@"<head><style>img{width:%fpx !important;}</style></head>%@",self.bounds.size.width,str];
    [self.hotWebV loadHTMLString:str1 baseURL:nil];
    
}

- (void)setArr:(NSArray *)arr
{
    _arr = arr;
    
    [self.tableV reloadData];
    
}






- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
