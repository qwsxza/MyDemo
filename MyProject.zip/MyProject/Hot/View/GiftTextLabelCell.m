//
//  GiftTextLabelCell.m
//  MyProject
//
//  Created by 伍维超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "GiftTextLabelCell.h"
#import "Header.h"

#define kScreenWidthC [UIScreen mainScreen].bounds.size.width
#define kScreenHeightC [UIScreen mainScreen].bounds.size.height
@interface GiftTextLabelCell ()



@end

@implementation GiftTextLabelCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.nameLabel = [[UILabel alloc]init];
        [self.contentView addSubview:self.nameLabel];
        
        self.priceLabel = [[UILabel alloc]init];
        [self.contentView addSubview:self.priceLabel];
        
        self.desLabel = [[UILabel alloc]init];
        [self.contentView addSubview:self.desLabel];
        
        self.likeBtn = [UIButton buttonWithType:(UIButtonTypeCustom)];
        [self.contentView addSubview:self.likeBtn];
    }
    return self;
}

- (void)layoutSubviews
{
    self.nameLabel.frame = CGRectMake(kScreenWidthC/30, kScreenHeightC/80, kScreenWidthC/30 *20, kScreenHeightC/80 *4);
    self.nameLabel.font = [UIFont systemFontOfSize:18];

    self.priceLabel.frame = CGRectMake(self.nameLabel.frame.origin.x, self.nameLabel.frame.origin.y + self.nameLabel.bounds.size.height + kScreenHeightC/80, self.nameLabel.bounds.size.width, kScreenHeightC/80*2);
    self.priceLabel.textColor = [UIColor redColor];

    self.likeBtn.frame = CGRectMake(kScreenWidthC/30 *25, kScreenHeightC/50, kScreenWidthC/30 *3, self.nameLabel.bounds.size.height);
    
    self.desLabel.frame = CGRectMake(self.priceLabel.frame.origin.x, self.priceLabel.frame.origin.y + self.priceLabel.bounds.size.height + kScreenHeightC/80, kScreenWidthC/30 *28, kScreenHeightC);
    self.desLabel.numberOfLines = 0;
    [self.desLabel sizeToFit];
}








- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
