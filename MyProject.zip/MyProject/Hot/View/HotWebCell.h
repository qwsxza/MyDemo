//
//  HotWebCell.h
//  MyProject
//
//  Created by 伍维超 on 15/11/7.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HotWebCell : UITableViewCell

@property (nonatomic, strong)UIWebView *hotWebV;

@property (nonatomic, strong)UITableView *tableV;

@property (nonatomic, strong)NSArray *arr;

@property (nonatomic, strong)NSString *str;

@end
