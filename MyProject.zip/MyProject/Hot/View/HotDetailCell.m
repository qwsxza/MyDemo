//
//  HotDetailCell.m
//  MyProject
//
//  Created by 伍维超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//



#import "HotDetailCell.h"
#import "Header.h"
#import "UIColor+AddColor.h"
#import "HotModelDetail.h"
#import "UIImageView+WebCache.h"

@interface HotDetailCell ()
@property (nonatomic, strong)UIImageView *imageV;
@property (nonatomic, strong)UILabel     *nameLabel;
@property (nonatomic, strong)UILabel     *priceLabel;
@property (nonatomic, strong)UILabel     *favorites_counts_label;
@end

@implementation HotDetailCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
    
        self.imageV = [[UIImageView alloc]init];
        [self.contentView addSubview:self.imageV];
        
        self.nameLabel = [[UILabel alloc]init];
        [self.contentView addSubview:self.nameLabel];
        
        self.priceLabel = [[UILabel alloc]init];
        [self.contentView addSubview:self.priceLabel];
        
        self.favorites_counts_label = [[UILabel alloc]init];
        [self.contentView addSubview:self.favorites_counts_label];
    }
    return self;
}


- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.imageV.frame = CGRectMake(0, 0, self.contentView.bounds.size.width, self.contentView.bounds.size.width);
    
    self.nameLabel.frame = CGRectMake(self.imageV.frame.origin.x + kContentWidth/20, self.imageV.frame.origin.y + self.imageV.bounds.size.height +kContentHeight/20, kContentWidth - kContentWidth/10, kContentHeight/7);
    
    self.priceLabel.frame = CGRectMake(self.nameLabel.frame.origin.x, kContentHeight/10*8.7, kContentWidth/10 *4, kContentHeight/10);
    
    self.favorites_counts_label.frame = CGRectMake(kContentWidth/10*6, self.priceLabel.frame.origin.y, self.priceLabel.bounds.size.width, self.priceLabel.bounds.size.height);
    
}

- (void)setHotModeDetail:(HotModelDetail *)hotModeDetail
{
    _hotModeDetail = hotModeDetail;
    
    [self.imageV sd_setImageWithURL:[NSURL URLWithString:_hotModeDetail.cover_image_url] placeholderImage:[UIImage imageNamed:@"placeholder"]];
    self.imageV.layer.masksToBounds = YES; // 必须打开
    self.imageV.layer.cornerRadius = kContentWidth/80;
    
    self.nameLabel.text = hotModeDetail.name;
    self.nameLabel.numberOfLines = 2;
    self.nameLabel.font = [UIFont systemFontOfSize:14];
    self.nameLabel.textAlignment = NSTextAlignmentNatural;
    
    self.priceLabel.text = [NSString stringWithFormat:@"￥%@",hotModeDetail.price];
    self.priceLabel.textColor = [UIColor redColor];
    self.priceLabel.font = [UIFont systemFontOfSize:14];
    
    self.favorites_counts_label.text = [NSString stringWithFormat:@"💗%ld",(long)hotModeDetail.favorites_count];
    self.favorites_counts_label.font  =[UIFont systemFontOfSize:14];
}



@end
