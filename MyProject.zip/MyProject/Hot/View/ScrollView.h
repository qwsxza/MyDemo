//
//  ScrollView.h
//  MyProject
//
//  Created by 伍维超 on 15/11/11.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScrollView : UIView

@property(nonatomic, strong)NSArray *image_urls;

@end
