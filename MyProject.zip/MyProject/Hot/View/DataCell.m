//
//  DataCell.m
//  MyProject
//
//  Created by 伍维超 on 15/11/14.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "DataCell.h"
#import "UIImageView+WebCache.h"
#import "UIColor+AddColor.h"
#import "Header.h"

@interface DataCell ()<UIScrollViewDelegate>

@property (nonatomic, strong)UIScrollView *scrollV;
@property (nonatomic, strong)UIPageControl *pageControl;

@end

@implementation DataCell

#pragma mark - 初始化方法
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.scrollV = [[UIScrollView alloc]init];
        [self.contentView addSubview:self.scrollV];
        
        self.pageControl = [[UIPageControl alloc]init];
        [self.contentView addSubview:self.pageControl];
    }
    return self;
}

#pragma mark - 布局子视图
- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.scrollV.frame = CGRectMake(0, 0, kContentWidth, kContentHeight);
    self.scrollV.contentSize = CGSizeMake(kContentWidth *(_image_urls.count + 1), 0);
    self.scrollV.contentOffset = CGPointMake(kContentWidth, 0);

    self.pageControl.frame = CGRectMake(0, kContentHeight/5 *4, kContentWidth, kContentHeight/6);
    
    for (int i = 0; i < self.image_urls.count + 1; i++) {
         UIImageView *imageV =   (UIImageView *)[self.scrollV viewWithTag:4200 + i];
        imageV.frame = CGRectMake(kContentWidth * i, 0, kContentWidth, kContentHeight);
    }
    
}

#pragma mark - set方法
- (void)setImage_urls:(NSArray *)image_urls
{

    _image_urls = image_urls;

    self.scrollV.pagingEnabled = YES;
    self.scrollV.showsHorizontalScrollIndicator = NO;
    self.scrollV.delegate = self;
    for (int i  = 0; i < _image_urls.count +1 ; i++) {
        UIImageView *imageV = [[UIImageView alloc]init];

        imageV.tag = i + 4200;
        [self.scrollV addSubview:imageV];
    }
    
    self.pageControl.numberOfPages = self.image_urls.count;
    // 选中的颜色
    self.pageControl.currentPageIndicatorTintColor = [UIColor whiteColor];
    // 未选中的颜色
    self.pageControl.pageIndicatorTintColor = [UIColor silverColor];
    
    if (self.image_urls.count > 1)
    {
        [(UIImageView *)[self.scrollV viewWithTag:4200 ] sd_setImageWithURL:[NSURL URLWithString:self.image_urls[self.image_urls.count - 1] ] placeholderImage:[UIImage imageNamed:@"placeholder"]];
        for (int i = 1; i < self.image_urls.count + 1; i++) {
            [(UIImageView *)[self.scrollV viewWithTag:4200 + i] sd_setImageWithURL:[NSURL URLWithString:self.image_urls[i -1] ] placeholderImage:[UIImage imageNamed:@"placeholder"]];
        }
    }
    
    if (self.image_urls.count == 1)
    {
        [(UIImageView *)[self.scrollV viewWithTag:4201 ] sd_setImageWithURL:[NSURL URLWithString:self.image_urls[self.image_urls.count - 1]] placeholderImage:[UIImage imageNamed:@"placeholder"]];
        self.pageControl.hidden = YES;
        self.scrollV.userInteractionEnabled = NO;
    }
}

#pragma mark - scorll的代理方法
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGPoint offset = scrollView.contentOffset;
    
    if (offset.x > self.image_urls.count *scrollView.frame.size.width) {
        [scrollView setContentOffset:CGPointZero animated:NO];
    }
    if (offset.x < 0) {
        [scrollView setContentOffset:CGPointMake(scrollView.bounds.size.width *self.image_urls.count, 0) animated:NO];
    }
    
    NSInteger page = scrollView.contentOffset.x/self.scrollV.bounds.size.width;
    
    if (page == 0) {
        self.pageControl.currentPage = self.pageControl.numberOfPages - 1;
    }else{
        self.pageControl.currentPage = page - 1;
    }
}






- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
