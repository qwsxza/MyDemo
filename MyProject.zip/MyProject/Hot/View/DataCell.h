//
//  DataCell.h
//  MyProject
//
//  Created by 伍维超 on 15/11/14.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DataCell : UITableViewCell

@property (nonatomic, strong) NSArray *image_urls;

@end
