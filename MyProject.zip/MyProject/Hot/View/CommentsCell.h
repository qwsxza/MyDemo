//
//  CommentsCell.h
//  MyProject
//
//  Created by 伍维超 on 15/11/7.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Comments;

@interface CommentsCell : UITableViewCell

@property (nonatomic, strong)Comments *comment;
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong)UIImageView *imageV;
@property (nonatomic, strong)UILabel     *nameLabel;
@property (nonatomic, strong)UILabel     *commentsLabel;

@end
