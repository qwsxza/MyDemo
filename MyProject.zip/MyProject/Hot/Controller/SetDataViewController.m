//
//  SetDataViewController.m
//  MyProject
//
//  Created by gp on 15/11/11.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "SetDataViewController.h"
#import "DataBaseHandle.h"
#import "DesModel.h"
#import "MyCollectViewController.h"

@interface SetDataViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableV;

@end

@implementation SetDataViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableV = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height) style:(UITableViewStylePlain)];
    self.tableV.rowHeight = self.backView.bounds.size.height/8;
    self.tableV.delegate = self;
    self.tableV.dataSource = self;
    [self.backView addSubview:self.tableV];
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"CollectCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:identifier];
    }
    if (indexPath.row == 0) {
        cell.textLabel.text = @"清除缓存";
    }
    if (indexPath.row == 1) {
        cell.textLabel.text = @"我的收藏";
    }
    
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"提示" message:@"是否清除缓存" preferredStyle:(UIAlertControllerStyleAlert)];
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            [self clearCache];
        }];
        UIAlertAction *artion1  = [UIAlertAction actionWithTitle:@"取消" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            
        }];
        [alertC addAction:action];
        [alertC addAction:artion1];
        [self presentViewController:alertC animated:YES completion:nil];
    }
    if (indexPath.row == 1) {
        MyCollectViewController *myCollectVC = [[MyCollectViewController alloc]init];
        [self.navigationController pushViewController:myCollectVC animated:YES];
    }
}
// Do any additional setup after loading the view.

// 清除缓存的方法
- (void)clearCache
{
    // NSLog(@"%@", NSHomeDirectory());
    // 文件路径
    NSArray *cachesArr = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    // 文件管理类
    NSFileManager *cachesManager = [NSFileManager defaultManager];
    // 文件夹路径
    NSString *filePath = [[cachesArr objectAtIndex:0] stringByAppendingPathComponent:@"com.hackemist.SDWebImageCache.default"];
    
    long long size = 0;
    
    if ([cachesManager fileExistsAtPath:filePath]) {
    // 获取文件夹下所有文件
        NSArray *files = [cachesManager subpathsAtPath:filePath];
        for (NSString *str in files) {
            // 文件名的完整路径
            NSString *file = [filePath stringByAppendingPathComponent:str];
            // 计算文件字节大小
            size += [cachesManager attributesOfItemAtPath:file error:nil].fileSize;
            // 删除文件
            [cachesManager removeItemAtPath:file error:nil];
        }
    }
    [self countSize:size/(1024*1024.0)];
}


- (void)countSize:(float)size
{
    UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"提示" message:[NSString stringWithFormat:@"已清除%.2fM",size] preferredStyle:(UIAlertControllerStyleAlert)];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
    }];
    [alertC addAction:action];
    [self presentViewController:alertC animated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
