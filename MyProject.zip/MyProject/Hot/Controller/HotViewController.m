//
//  HotViewController.m
//  MyProject
//
//  Created by gp on 15/11/6.
//  Copyright © 2015年 gp. All rights reserved.
//


#import "HotViewController.h"
#import "AFNetworking.h"
#import "HotModelDetail.h"
#import "Header.h"
#import "HotDetailCell.h"
#import "UIImageView+WebCache.h"
#import "UIColor+AddColor.h"
#import "HotDetailController.h"
#import "MBProgressHUD.h"
#import "MJRefresh.h"
#import "SetDataViewController.h"
#import "SubCategory.h"  //model


@interface HotViewController ()<UICollectionViewDataSource,UICollectionViewDelegate>

@property (nonatomic, strong)UICollectionView *hotCollectionV;
@property (nonatomic, strong)NSMutableArray *modelArr;
@property (nonatomic, strong)MBProgressHUD *hud;

@end

@implementation HotViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    NSLog(@"%@", NSHomeDirectory());
    
    if (self.subCategory == nil) {
        self.titleLabel.text = @"热门";
    } else {
        self.titleLabel.text = self.subCategory.name;
    }
    
    self.titleLabel.font = [UIFont systemFontOfSize:17];
    self.titleLabel.textColor = [UIColor whiteColor];
    
    UICollectionViewFlowLayout *hotFlowLayout = [[UICollectionViewFlowLayout alloc]init];

    hotFlowLayout.minimumLineSpacing = kScreenWidth/30;
    hotFlowLayout.sectionInset = UIEdgeInsetsMake(kScreenWidth/30, kScreenWidth/30, kScreenWidth/30, kScreenWidth/30);
    hotFlowLayout.itemSize = CGSizeMake((kScreenWidth - kScreenWidth/30*3) / 2, kScreenHeight/2.6);
    
    self.hotCollectionV = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height) collectionViewLayout:hotFlowLayout];
    self.hotCollectionV.backgroundColor = [UIColor silverColor];
    
    self.hotCollectionV.delegate = self;
    self.hotCollectionV.dataSource = self;
    
    [self.hotCollectionV registerClass:[HotDetailCell class] forCellWithReuseIdentifier:kModelCell];
    
    [self.backView addSubview:self.hotCollectionV];
    
    // 下拉刷新的时候需要在这里出初始化 不然每次刷新都会初始化
    self.modelArr = [NSMutableArray array];

    // 菊花转
    [self p_setupProgressHud];
    
    //判断是热门还是分类
    self.subCategory == nil ? [self handleWith:0] : [self handleSubCategoryDataWith:0];

    
     // 上拉加载
    self.hotCollectionV.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
//        [self handleWith:self.modelArr.count];
        [self p_setupProgressHud];
        self.subCategory == nil ? [self handleWith:self.modelArr.count] : [self handleSubCategoryDataWith:self.modelArr.count];
    }];
    
    // 下拉刷新
    self.hotCollectionV.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        // 下拉的时候需要重新初始化数组
        self.modelArr = [NSMutableArray array];
        if (self.subCategory == nil) {
            [self p_setupProgressHud];
            [self handleWith:0];
        } else {
            [self p_setupProgressHud];
            [self handleSubCategoryDataWith:0];
        }
    }];
    

    UIButton *setBtn = [UIButton buttonWithType:(UIButtonTypeSystem)];
    setBtn.frame = CGRectMake(self.topView.bounds.size.width/10 *9, self.topView.bounds.size.height/2, 30, 30);
    [setBtn setTitle:@"设置" forState:(UIControlStateNormal)];
    [setBtn addTarget:self action:@selector(setBtn:) forControlEvents:(UIControlEventTouchUpInside)];
   //® [self.topView addSubview:setBtn];
    
}

- (void)setBtn:(UIBarButtonItem *)btn
{
    SetDataViewController *setDataVC = [[SetDataViewController alloc]init];
    [self.navigationController pushViewController:setDataVC animated:YES];
}

- (void)p_setupProgressHud
{
    self.hud = [[MBProgressHUD alloc]initWithView:self.view];
    self.hud.frame = self.view.bounds;
    self.hud.minSize = CGSizeMake(100, 100);
    self.hud.mode = MBProgressHUDModeIndeterminate;
    [self.view addSubview:self.hud];
    
    [self.hud show:YES];
    
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.modelArr.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HotModelDetail *hotModel = self.modelArr[indexPath.row];
    
    HotDetailCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kModelCell forIndexPath:indexPath];
    
    cell.hotModeDetail = hotModel;
    cell.layer.cornerRadius = kScreenWidth/80;
    cell.backgroundColor = [UIColor whiteColor];

    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    HotModelDetail *hotModel = self.modelArr[indexPath.row];
    
    HotDetailController *hotDC = [[HotDetailController alloc]init];
    // 传递到下个页面的字典
    NSString *str = [NSString stringWithFormat:@"%ld",(long)hotModel.ID];
    hotDC.IDstr = str;
    
    [self.navigationController pushViewController:hotDC animated:YES];
}
//获取分类数据
- (void)handleSubCategoryDataWith:(NSInteger)i {

    //分类:http://api.liwushuo.com/v2/item_subcategories/7/items?limit=20&offset=0
    AFHTTPRequestOperationManager *manage = [[AFHTTPRequestOperationManager alloc]init];
    [manage GET:[NSString stringWithFormat:@"http://api.liwushuo.com/v2/item_subcategories/%@/items?limit=20&offset=%ld",self.subCategory.subCategoryId, i] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [self.hotCollectionV.footer endRefreshing];
        [self.hotCollectionV.header endRefreshing];
        NSDictionary *dic = [responseObject objectForKey:@"data"];
        NSArray *arr = [dic objectForKey:@"items"];
        
        for (NSDictionary *modelDic in arr) {
            HotModelDetail *hotModel = [[HotModelDetail alloc]init];
            [hotModel setValuesForKeysWithDictionary:modelDic];
           
            [self.modelArr addObject:hotModel];
        }
  
        [self.hotCollectionV reloadData];
        [self.hud removeFromSuperview];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        self.hud.labelText = @"加载网络失败,请检查网络重试";
        
        //延时消失
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.hud hide:YES];
        });
    }];
}
- (void)handleWith:(NSInteger)i
{
    
    
    //热门 http://api.liwushuo.com/v2/items?gender=1&generation=1&limit=50&offset=0
    AFHTTPRequestOperationManager *manage = [[AFHTTPRequestOperationManager alloc]init];
    [manage GET:[NSString stringWithFormat:@"http://api.liwushuo.com/v2/items?gender=1&generation=1&limit=50&offset=%ld",i] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [self.hotCollectionV.footer endRefreshing];
        [self.hotCollectionV.header endRefreshing];
        NSDictionary *dic = [responseObject objectForKey:@"data"];
        NSArray *arr = [dic objectForKey:@"items"];
        
        for (NSDictionary *modelDic in arr) {
            HotModelDetail *hotModel = [[HotModelDetail alloc]init];
            [hotModel setValuesForKeysWithDictionary:[modelDic  objectForKey:@"data"]];
            [self.modelArr addObject:hotModel];
           
        
        }
        [self.hotCollectionV reloadData];
        [self.hud removeFromSuperview];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        self.hud.labelText = @"加载网络失败,请检查网络重试";
        
        //延时消失
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.hud hide:YES];
        });
    }];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
