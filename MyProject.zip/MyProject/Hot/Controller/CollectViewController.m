//
//  CollectViewController.m
//  MyProject
//
//  Created by gp on 15/11/13.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "CollectViewController.h"
#import "DataCell.h"
#import "GiftTextLabelCell.h"
#import "DesModel.h"
#import "UIColor+AddColor.h"
#import "DataBaseHandle.h"

@interface CollectViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic, strong)UITableView *tabelV;


@end

@implementation CollectViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tabelV = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height) style:(UITableViewStylePlain)];
    self.tabelV.delegate = self;
    self.tabelV.dataSource = self;
    self.tabelV.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.backView addSubview:self.tabelV];
}

#pragma mark - 加载单元格
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ( indexPath.row == 0) {
        return self.view.bounds.size.height/5*3;
    }
    if (indexPath.row == 1) {
        NSDictionary *dic  = @{NSFontAttributeName :[UIFont systemFontOfSize:17]};
        CGRect rect = [self.desModel.des boundingRectWithSize:CGSizeMake(self.view.bounds.size.width/40 *38, NSIntegerMax) options:(NSStringDrawingUsesLineFragmentOrigin) attributes:dic context:nil];
        CGFloat rectHeight = rect.size.height;
        return self.view.bounds.size.height/80 *11 + rectHeight;
    }
    
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ( indexPath.row == 0) {
        static NSString *ID = @"cell9";
        DataCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
        if (!cell) {
            
            cell = [[DataCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
        }
        cell.image_urls = self.desModel.image_urls ;

        return cell;
    }
    if ( indexPath.row == 1) {
        static NSString *ID1 = @"cell1";
        GiftTextLabelCell *cell = [tableView dequeueReusableCellWithIdentifier:ID1];
        if (!cell) {
            cell = [[GiftTextLabelCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:ID1];
        }
        cell.nameLabel.text = self.desModel.name;
        cell.priceLabel.text = [NSString stringWithFormat:@"￥%@",self.desModel.price];
        cell.desLabel.text = self.desModel.des;

        [cell.likeBtn setImage:[UIImage imageNamed:@"love"] forState:(UIControlStateNormal)];
        [cell.likeBtn addTarget:self action:@selector(btnClick:) forControlEvents:(UIControlEventTouchUpInside)];
        cell.desLabel.textColor = [UIColor silverColor];
        return cell;
    }
    UITableViewCell *cell = [[UITableViewCell alloc]init];
    return cell;
}

- (void)btnClick:(UIButton *)btn
{
    [DataBaseHandle deleteGift:self.desModel];
    [btn setBackgroundImage:[UIImage imageNamed:@"unlike"] forState:(UIControlStateNormal)];

    UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"提示" message:@"亲,你已经取消收藏啦~" preferredStyle:(UIAlertControllerStyleAlert)];
            UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
                //前一页面重新刷新
                self.deleteGift();
                [self.navigationController popViewControllerAnimated:YES];
            }];
    [alertC addAction:action];
    [self presentViewController:alertC animated:YES completion:nil];
    [self.tabelV reloadData];
    
}



//- (void)setDesModel:(DesModel *)desModel
//{
//    _desModel = desModel;
//
//}







- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
