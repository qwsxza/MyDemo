//
//  HotDetailController.m
//  MyProject
//
//  Created by gp on 15/11/6.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "HotDetailController.h"
#import "ScrollCell.h"
#import "Header.h"
#import "GiftTextLabelCell.h"
#import "AFNetworking.h"
#import "Comments.h"
#import "DesModel.h"
#import "UIColor+AddColor.h"
#import "HotWebCell.h"
#import "MBProgressHUD.h"
#import "MJRefresh.h"
#import "UMSocial.h"
#import "DataBaseHandle.h"
#import "FavouriteDataHandle.h"

@interface HotDetailController ()<UITableViewDataSource,UITableViewDelegate,UIWebViewDelegate>

@property (nonatomic, strong) UITableView *tabelV;
@property (nonatomic, strong) NSMutableArray *commentArray;
@property (nonatomic, strong) NSMutableArray *desArray;
@property (nonatomic, strong) DesModel *desModel;
@property (nonatomic, assign) CGFloat webHeight;
@property (nonatomic, assign) BOOL isFavourite;
@property (nonatomic, assign) BOOL isSubView;
@property (nonatomic, strong) UIView *headV;
@property (nonatomic, strong) UIButton *imageTFBtn;
@property (nonatomic, strong) UIButton *commentsBtn;
@property (nonatomic, strong) UILabel *sliderLabel;

@end

@implementation HotDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.titleLabel.text = @"礼物详情";
    self.titleLabel.font = [UIFont systemFontOfSize:17];
    self.titleLabel.textColor = [UIColor whiteColor];
    
    self.tabelV = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height) style:(UITableViewStylePlain)];
    self.tabelV.delegate = self;
    self.tabelV.dataSource = self;
    self.tabelV.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    [self.backView addSubview:self.tabelV];
    
    [self handle];
    [self desHandle];
    
    self.isSubView = YES;
    // 分享Btn
    UIButton *showBtn = [UIButton buttonWithType:(UIButtonTypeSystem)];
    showBtn.frame = CGRectMake(self.view.bounds.size.width - self.view.bounds.size.width/8 -10, self.view.bounds.size.height / 23, self.view.bounds.size.width / 11, self.view.bounds.size.height / 22);
    [showBtn setBackgroundImage:[UIImage imageNamed:@"show"] forState:(UIControlStateNormal)];
    [self.topView addSubview:showBtn];
    [showBtn addTarget:self action:@selector(showBtn:) forControlEvents:(UIControlEventTouchUpInside)];
    
}

#pragma mark - 收藏按钮方法
- (void)btnClick:(UIButton *)btn
{
    if (_isFavourite == YES) {
        [DataBaseHandle deleteGift:self.desModel];
        [btn setBackgroundImage:[UIImage imageNamed:@"unlike"] forState:(UIControlStateNormal)];
        _isFavourite = NO;
    }else{
        //在数据库中添加数据
        [DataBaseHandle insertNewGift:self.desModel];
        UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"提示" message:@"收藏成功" preferredStyle:(UIAlertControllerStyleAlert)];
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:(UIAlertActionStyleDefault) handler:^(UIAlertAction * _Nonnull action) {
            [btn setBackgroundImage:[UIImage imageNamed:@"love"] forState:(UIControlStateNormal)];
        }];
        [alertC addAction:action];
        [self presentViewController:alertC animated:YES completion:nil];
        _isFavourite = YES;
    }
}

#pragma mark - 加载单元格
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ( indexPath.row == 0 && indexPath.section == 0) {
        return kScreenHeight/5*3;
    }
    if (indexPath.row == 1 && indexPath.section == 0) {
        NSDictionary *dic  = @{NSFontAttributeName :[UIFont systemFontOfSize:17]};
        CGRect rect = [self.desModel.des boundingRectWithSize:CGSizeMake(kScreenWidth /40 *38, NSIntegerMax) options:(NSStringDrawingUsesLineFragmentOrigin) attributes:dic context:nil];
        CGFloat rectHeight = rect.size.height;
        return kScreenHeight/80 *11 + rectHeight;
    }if (indexPath.row == 0 && indexPath.section == 1) {
        if (self.isSubView == YES) {
//  return self.webHeight;
          return 400;
        }else{
            return self.commentArray.count * self.backView.bounds.size.height/8;
        }
    }

    return 0;
}

#pragma mark - 区头
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 1) {
        self.headV = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height/13)];
        self.headV.backgroundColor = [UIColor whiteColor];
         self.imageTFBtn = [UIButton buttonWithType:(UIButtonTypeSystem)];
        self.imageTFBtn.frame = CGRectMake(0, 0, self.headV.bounds.size.width/2, self.headV.bounds.size.height);
        [self.imageTFBtn setTitle:@"图文介绍" forState:(UIControlStateNormal)];
        [self.imageTFBtn setTitleColor:[UIColor blackColor] forState:(UIControlStateNormal)];
        self.imageTFBtn.layer.borderWidth = 1;
        CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
        // 新建一个红色的ColorRef，用于设置边框（四个数字分别是 r, g, b, alpha）
        CGColorRef borderColorRef = CGColorCreate(colorSpace,(CGFloat[]){ 0, 0, 0, 0.3 });
        self.imageTFBtn.layer.borderColor = borderColorRef;
        self.imageTFBtn.tag = 3000;
        [self.headV addSubview:self.imageTFBtn];
        
         self.sliderLabel = [[UILabel alloc]init];
        self.sliderLabel.frame =CGRectMake(0, self.imageTFBtn.bounds.size.height/15*14, self.imageTFBtn.bounds.size.width, self.imageTFBtn.bounds.size.height/15);
        self.sliderLabel.backgroundColor = [UIColor redColor];
        [self.imageTFBtn addSubview:self.sliderLabel];
            if (self.isSubView == YES) {
                [UIView animateWithDuration:0.3 animations:^{
                    self.sliderLabel.frame =CGRectMake(0, self.imageTFBtn.bounds.size.height/15*14, self.imageTFBtn.bounds.size.width, self.imageTFBtn.bounds.size.height/15);
                } completion:nil];
            }else{
                [UIView animateWithDuration:0.3 animations:^{
                    self.sliderLabel.frame =CGRectMake(self.headV.bounds.size.width/2, self.imageTFBtn.bounds.size.height/15*14, self.imageTFBtn.bounds.size.width, self.imageTFBtn.bounds.size.height/15);
                } completion:nil];
            }
      
         self.commentsBtn = [UIButton buttonWithType:(UIButtonTypeSystem)];
       self.commentsBtn.frame = CGRectMake(self.headV.bounds.size.width/2, 0, self.headV.bounds.size.width/2, self.headV.bounds.size.height);
        [self.commentsBtn setTitle:@"评论" forState:(UIControlStateNormal)];
        [self.commentsBtn setTitleColor:[UIColor blackColor] forState:(UIControlStateNormal)];
        self.commentsBtn.layer.borderWidth = 1;
        self.commentsBtn.layer.borderColor = borderColorRef;
        self.commentsBtn.tag = 3001;
        
        [self.headV addSubview:self.commentsBtn];
        [ self.imageTFBtn addTarget:self action:@selector(imageTFClick:) forControlEvents:(UIControlEventTouchUpInside)];
        [self.commentsBtn addTarget:self action:@selector(commentsClick:) forControlEvents:(UIControlEventTouchUpInside)];

        return self.headV;
    }
        return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 1) {
        return self.backView.bounds.size.height/13;
    }else{
        return 0;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0 && indexPath.row == 0) {
        static NSString *ID = @"cell";
        ScrollCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
        if (!cell) {
            
            cell = [[ScrollCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
        }
        cell.image_urls = self.desModel.image_urls;
        return cell;
    }
    if (indexPath.section == 0 && indexPath.row == 1) {
        static NSString *ID1 = @"cell1";
        GiftTextLabelCell *cell = [tableView dequeueReusableCellWithIdentifier:ID1];
        if (!cell) {
            cell = [[GiftTextLabelCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:ID1];
        }
        cell.nameLabel.text = self.desModel.name;
        cell.priceLabel.text = [NSString stringWithFormat:@"￥%@",self.desModel.price];
        cell.desLabel.text = self.desModel.des;
        self.isFavourite = [DataBaseHandle isFavouriteGiftWith:self.IDstr];
        if (_isFavourite) {
            [cell.likeBtn setImage:[UIImage imageNamed:@"love"] forState:(UIControlStateNormal)];
        }else{
            [cell.likeBtn setImage:[UIImage imageNamed:@"unlike"] forState:(UIControlStateNormal)];
        }
        
        [cell.likeBtn addTarget:self action:@selector(btnClick:) forControlEvents:(UIControlEventTouchUpInside)];
        cell.desLabel.textColor = [UIColor silverColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    if (indexPath.section == 1 && indexPath.row == 0) {
        static NSString *identifier = @"cell3";
        HotWebCell *cell5 = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (!cell5) {
            cell5 = [[HotWebCell alloc]initWithStyle:(UITableViewCellStyleValue1) reuseIdentifier:identifier];
        }
        cell5.arr = self.commentArray;
        cell5.str = self.desModel.detail_html;
     //   cell5.hotWebV.delegate = self;
        return cell5;
    }
    UITableViewCell *cell = [[UITableViewCell alloc]init];
    return cell;
}

#pragma mark - 解析
- (void)handle
{
    self.commentArray = [NSMutableArray array];
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc]init];
    [manager GET:[NSString stringWithFormat:@"http://api.liwushuo.com/v2/items/%@/comments?limit=20&offset=0",self.IDstr] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        NSLog(@"%@", [NSString stringWithFormat:@"http://api.liwushuo.com/v2/items/%@/comments?limit=20&offset=0",self.IDstr]);
        NSDictionary *dic = [responseObject objectForKey:@"data"];
        
        NSArray *arr = [dic objectForKey:@"comments"];
        for (NSDictionary *dic1 in arr) {
            Comments *comment = [[Comments alloc]init];
            [comment setValuesForKeysWithDictionary:dic1 ];
            [self.commentArray addObject:comment];
            
        }
        [self.tabelV reloadData];
       
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}

- (void)desHandle
{
    
    self.desArray = [NSMutableArray array];
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc]init];
    [manager GET:[NSString stringWithFormat:@"http://api.liwushuo.com/v2/items/%@",self.IDstr] parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSDictionary * dic = [responseObject objectForKey:@"data"];
        
        self.desModel = [[DesModel alloc]init];
        
        [_desModel setValuesForKeysWithDictionary:dic];
        
        [self.tabelV reloadData];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
}

#pragma mark - 微博分享
- (void)showBtn:(UIButton *)btn
{
    //注意：分享到微信好友、微信朋友圈、微信收藏、QQ空间、QQ好友、来往好友、来往朋友圈、易信好友、易信朋友圈、Facebook、Twitter、Instagram等平台需要参考各自的集成方法
    [UMSocialSnsService presentSnsIconSheetView:self
                                         appKey:@"564afa5267e58e6a53001c0c"
                                      shareText:@"你要分享的文字"
                                     shareImage:[UIImage imageNamed:@"icon.png"]
                                shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToDouban, UMShareToEmail, UMShareToSms,nil]
                                       delegate:nil];
}

#pragma mark - button点击事件
- (void)imageTFClick:(UIButton *)button
{
    if (self.isSubView == NO) {
       HotWebCell *cell = (HotWebCell*) [self.tabelV cellForRowAtIndexPath:[NSIndexPath indexPathForItem:0 inSection:1]];
        [cell viewWithTag:101].hidden = NO;
        [cell viewWithTag:100].hidden = YES;

        self.isSubView = YES;
     
      self.sliderLabel.frame =CGRectMake(0, self.imageTFBtn.bounds.size.height/15*14, self.imageTFBtn.bounds.size.width, self.imageTFBtn.bounds.size.height/15);

    }
    [self.tabelV reloadData];

    
}

- (void)commentsClick:(UIButton *)button
{
    if (self.isSubView == YES) {
        UITableViewCell *cell = (UITableViewCell*) [self.tabelV cellForRowAtIndexPath:[NSIndexPath indexPathForItem:0 inSection:1]];
        [cell viewWithTag:101].hidden = YES;
        [cell viewWithTag:100].hidden = NO;
        self.isSubView = NO;
 

    }
    [self.tabelV reloadData];
}

#pragma mark - webView的代理方法这里面可以求出webview 的高度
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
   //  webView 的自适应宽度
    CGSize contentSize = webView.scrollView.contentSize;
    CGSize viewSize = self.view.bounds.size;
    float rw = viewSize.width / contentSize.width;
    webView.scrollView.minimumZoomScale = rw;
    webView.scrollView.maximumZoomScale = rw;
    webView.scrollView.zoomScale = rw;
    // webView 的自适应高度
  //    NSString *height = [webView stringByEvaluatingJavaScriptFromString:@"document.body.offsetHeight;"];
 //    CGFloat webViewHeight = [height floatValue] + 15;
 //    self.webHeight = webViewHeight;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
