//
//  MyCollectViewController.m
//  MyProject
//
//  Created by gp on 15/11/13.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "MyCollectViewController.h"
#import "DataBaseHandle.h"
#import "DesModel.h"
#import "UIColor+AddColor.h"
#import "CollectViewController.h"

@interface MyCollectViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong)UIImageView *imageV1;
@property (nonatomic, strong)UIImageView *imageV2;
@property (nonatomic, strong)UIImageView *imageV3;
@property (nonatomic, strong)UIImageView *ImageV4;
@property (nonatomic, strong)UITableView *tableV;
@property (nonatomic, strong)NSArray *listArray;
@end

@implementation MyCollectViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationController.navigationBar.hidden = YES;
    self.imageV1 = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height)];
    self.imageV1.image = [UIImage imageNamed:@"3.jpg"];
    [self.backView addSubview:self.imageV1];
    
    self.imageV2 = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height)];
    self.imageV2.image = [UIImage imageNamed:@"4.jpg"];
    [self.backView addSubview:self.imageV2];
    
    self.imageV3 = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height)];
    self.imageV3.image = [UIImage imageNamed:@"1.jpg"];
    [self.backView addSubview:self.imageV3];
    
    self.ImageV4 = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.backView.bounds.size.width, self.backView.bounds.size.height)];
    self.ImageV4.image = [UIImage imageNamed:@"2.jpg"];
    [self.backView addSubview:self.ImageV4];
    
    
    [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(imageChange) userInfo:nil repeats:YES];
    
    self.tableV = [[UITableView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    self.tableV.delegate = self;
    self.tableV.dataSource = self;
    self.tableV.rowHeight = self.backView.bounds.size.height/15;
    [self.backView addSubview:self.tableV];
    self.tableV.backgroundColor  = [UIColor clearColor];
    self.tableV.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.listArray = [NSArray array];
    self.listArray =  [DataBaseHandle selectAllGifts];

}

- (void)imageChange
{
    [UIView animateWithDuration:3 animations:^{
        self.ImageV4.alpha = 0;
        self.imageV3.alpha = 1;
    } completion:^(BOOL finished) {
     [UIView animateWithDuration:3 animations:^{
         self.imageV3.alpha = 0;
         self.imageV2.alpha = 1;
     } completion:^(BOOL finished) {
         [UIView animateWithDuration:3 animations:^{
             self.imageV1.alpha = 1;
             self.imageV2.alpha = 0;
         } completion:^(BOOL finished) {
             [UIView animateWithDuration:3 animations:^{
                 self.imageV1.alpha = 0;
                 self.ImageV4.alpha = 1;
             } completion:nil];
         }];
     }];
    }];
     }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.listArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DesModel *desModel = _listArray[indexPath.row];
    static NSString *idenitifer = @"listCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:idenitifer];
    if (cell==nil) {
        cell = [[UITableViewCell alloc]initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:idenitifer];
    }
    cell.backgroundColor = [UIColor clearColor];
    cell.textLabel.text = desModel.name;
    cell.textLabel.textColor = [UIColor jinjuse];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DesModel *desModel = self.listArray[indexPath.row];
    CollectViewController *collectVC = [[CollectViewController alloc]init];
    [collectVC setDeleteGift:^{
        self.listArray =  [DataBaseHandle selectAllGifts];
        [self.tableV reloadData];
    }];
    
    collectVC.desModel = desModel;
    [self.navigationController pushViewController:collectVC animated:YES];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
