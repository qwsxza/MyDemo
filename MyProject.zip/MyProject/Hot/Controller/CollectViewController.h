//
//  CollectViewController.h
//  MyProject
//
//  Created by gp on 15/11/13.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "ViewController.h"
@class DesModel;
@interface CollectViewController : ViewController

@property (nonatomic, strong)DesModel *desModel;

@property (nonatomic, copy)void (^deleteGift)();
@end
