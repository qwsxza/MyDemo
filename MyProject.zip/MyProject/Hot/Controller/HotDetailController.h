//
//  HotDetailController.h
//  MyProject
//
//  Created by gp on 15/11/6.
//  Copyright © 2015年 gp. All rights reserved.
//

#import "ViewController.h"

@interface HotDetailController : ViewController

@property (nonatomic, strong)NSString *IDstr;

@end
