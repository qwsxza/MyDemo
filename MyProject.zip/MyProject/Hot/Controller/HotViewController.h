//
//  HotViewController.h
//  MyProject
//
//  Created by gp on 15/11/6.
//  Copyright © 2015年 gp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import "Header.h"
@class SubCategory;
@interface HotViewController : ViewController


//分类跳转
@property (nonatomic, strong)SubCategory *subCategory;

@end
