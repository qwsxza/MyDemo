//
//  HotModelDetail.m
//  MyProject
//
//  Created by 伍维超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "HotModelDetail.h"

@implementation HotModelDetail

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if ([key isEqualToString:@"id"]) {
        self.ID = [value integerValue];
    }
    if ([key isEqualToString:@"description"]) {
        self.des = value;
    }
}


@end
