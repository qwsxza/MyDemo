//
//  Comments.m
//  MyProject
//
//  Created by 伍维超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "Comments.h"

@implementation Comments

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if ([key isEqualToString:@"id"]) {
        self.ID = [value integerValue];
    }
}
-(void)setValue:(id)value forKey:(NSString *)key {
    [super setValue:value forKey:key];
    if ([key isEqualToString:@"created_at"]) {
        self.created_at = [NSString stringWithFormat:@"%@", value];
    }
}
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.replied_comment = [NSDictionary dictionary];
        self.user = [NSDictionary dictionary];
        self.replied_user = [NSDictionary dictionary];
    }
    return self;
}

//- (void)setValue:(id)value forKey:(NSString *)key
//{
//    if ([key isEqualToString:@"userModel"]) {
//        [self.userModel setValuesForKeysWithDictionary:value];
//    }
//    if ([key isEqualToString:@"replied_user"]) {
//        [self.replied_user setValuesForKeysWithDictionary:value];
//    }
//    if ([key isEqualToString:@"replier_comment"]) {
//        [self.replied_comment setValuesForKeysWithDictionary:value];
//    }
//}
-(void)setNilValueForKey:(NSString *)key
{
    
}

@end
