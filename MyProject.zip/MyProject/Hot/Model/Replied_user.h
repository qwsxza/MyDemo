//
//  Replied_user.h
//  MyProject
//
//  Created by 伍维超 on 15/11/7.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Replied_user : NSObject

@property (nonatomic, strong)NSString  *avatar_url;
@property (nonatomic, assign)BOOL      can_mobile_login;
@property (nonatomic, strong)NSString  *guest_uuid;
@property (nonatomic, assign)NSInteger ID;
@property (nonatomic, strong)NSString  *nickname;
@property (nonatomic, assign)NSInteger role;

- (instancetype)initWithDictionary:(NSDictionary *)dic;


@end
