//
//  Comments.h
//  MyProject
//
//  Created by 伍维超 on 15/11/6.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Replied_comment.h"
#import "Replied_user.h"

@interface Comments : NSObject

@property (nonatomic, strong)NSString        *content;
@property (nonatomic, assign)NSString       *created_at;
@property (nonatomic, assign)NSInteger       ID;
@property (nonatomic, assign)NSInteger       item_id;
@property (nonatomic, strong)NSDictionary *replied_comment;
@property (nonatomic, strong)NSDictionary    *replied_user;
@property (nonatomic, strong)NSString        *reply_to_id;
@property (nonatomic, assign)BOOL            show;
@property (nonatomic, strong)NSDictionary       *user;

@end
