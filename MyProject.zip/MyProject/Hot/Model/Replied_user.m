//
//  Replied_user.m
//  MyProject
//
//  Created by 伍维超 on 15/11/7.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "Replied_user.h"

@implementation Replied_user


- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if ([key isEqualToString:@"id"]) {
        self.ID = [value integerValue];
    }
}

- (instancetype)initWithDictionary:(NSDictionary *)dic
{
    self = [super init];
    if (self) {
        [self setValuesForKeysWithDictionary:dic];
    }
    return self;
}

@end
