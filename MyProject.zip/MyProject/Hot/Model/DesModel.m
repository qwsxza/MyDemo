//
//  DesModel.m
//  MyProject
//
//  Created by 伍维超 on 15/11/7.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import "DesModel.h"

#define kName @"name"
#define kId @"id"
#define kImage_urls  @"image_urls"
#define kDetail_html @"detail_html"
#define kPrice @"price"
#define kDes @"des"
@implementation DesModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if ([key isEqualToString:@"id"]) {
        self.ID = [value integerValue];
    }
    if ([key isEqualToString:@"description"]) {
        self.des = value;
    }
}

- (void)setNilValueForKey:(NSString *)key
{
    
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    //当被编码的对象为 string, dic, array 的时候
    [aCoder encodeObject:self.name forKey:kName];
    [aCoder encodeInteger:self.ID forKey:kId];
    [aCoder encodeObject:self.image_urls forKey:kImage_urls];
    [aCoder encodeObject:self.des forKey:kDes];
    [aCoder encodeObject:self.price forKey:kPrice];
    [aCoder encodeObject:self.detail_html forKey:kDetail_html];
}

//  解码
- (id)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    if (self) {
        self.name = [aDecoder decodeObjectForKey:kName];
        self.ID = [aDecoder decodeIntegerForKey:kId];
        //self.image = [UIImage imageWithData:[aDecoder decodeDataObject]];
        self.price = [aDecoder decodeObjectForKey:kPrice];
        self.image_urls = [aDecoder decodeObjectForKey:kImage_urls];
        self.des = [aDecoder decodeObjectForKey:kDes];
        self.detail_html = [aDecoder decodeObjectForKey:kDetail_html];
    }
    return self;
}


@end
