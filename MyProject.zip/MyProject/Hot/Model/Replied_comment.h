//
//  Replied_comment.h
//  MyProject
//
//  Created by 伍维超 on 15/11/7.
//  Copyright © 2015年 陆超. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Replied_comment : NSObject

@property (nonatomic, strong)NSString  *content;
@property (nonatomic, assign)NSInteger created_at;
@property (nonatomic, assign)NSInteger ID;
@property (nonatomic, assign)NSInteger item_id;
@property (nonatomic, strong)NSString  *reply_to_id;
@property (nonatomic, assign)BOOL      show;
@property (nonatomic, assign)NSInteger user_id;

- (instancetype)initWithDictionary:(NSDictionary *)dic;


@end
